package com.efir.iptv.ui

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusDirection
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onKeyEvent
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.efir.iptv.AppViewModel
import com.efir.iptv.data.Channel
import com.efir.iptv.data.Programme
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Рамка й легке збільшення для елемента у фокусі (керування пультом). */
fun Modifier.focusHighlight(shape: Shape? = null): Modifier = composed {
    val skin = LocalSkin.current
    val sh = shape ?: RoundedCornerShape(skin.cornerL)
    var focused by remember { mutableStateOf(false) }
    val scale by animateFloatAsState(if (focused) 1.03f else 1f, label = "focusScale")
    this
        .graphicsLayer {
            scaleX = scale
            scaleY = scale
        }
        .onFocusChanged { focused = it.hasFocus }
        .then(if (focused) Modifier.border(2.dp, skin.focus, sh) else Modifier)
}

/** Не дає текстовому полю «захопити» пульт: стрілки вгору/вниз виводять фокус із поля. */
fun Modifier.dpadEscape(): Modifier = composed {
    val fm = LocalFocusManager.current
    onPreviewKeyEvent { e ->
        if (e.type != KeyEventType.KeyDown) return@onPreviewKeyEvent false
        when (e.key) {
            Key.DirectionDown -> {
                fm.moveFocus(FocusDirection.Down)
                true
            }
            Key.DirectionUp -> {
                fm.moveFocus(FocusDirection.Up)
                true
            }
            else -> false
        }
    }
}

@Composable
fun IconBtn(
    icon: ImageVector,
    description: String,
    modifier: Modifier = Modifier,
    tint: Color = MaterialTheme.colorScheme.onSurface,
    onClick: () -> Unit,
) {
    IconButton(onClick = onClick, modifier = modifier.focusHighlight(CircleShape)) {
        Icon(icon, contentDescription = description, tint = tint)
    }
}

@Composable
fun rememberNow(): Long {
    val now by produceState(System.currentTimeMillis()) {
        while (true) {
            delay(20_000)
            value = System.currentTimeMillis()
        }
    }
    return now
}

private val hmFormat = SimpleDateFormat("HH:mm", Locale.getDefault())
fun hm(ms: Long): String = hmFormat.format(Date(ms))

fun nowProgramme(list: List<Programme>?, now: Long): Programme? =
    list?.firstOrNull { it.start <= now && now < it.stop }

fun nextProgramme(list: List<Programme>?, now: Long): Programme? =
    list?.firstOrNull { it.start >= now }

fun progressOf(p: Programme, now: Long): Float =
    ((now - p.start).toFloat() / (p.stop - p.start).coerceAtLeast(1)).coerceIn(0f, 1f)

private fun initials(name: String): String {
    val words = name.split(' ', '-', '_').filter { it.isNotBlank() }
    return when {
        words.isEmpty() -> "TV"
        words.size == 1 -> words[0].take(2).uppercase()
        else -> (words[0].take(1) + words[1].take(1)).uppercase()
    }
}

@Composable
fun ChannelLogo(c: Channel, size: Dp) {
    var loaded by remember(c.logo) { mutableStateOf(false) }
    Box(
        Modifier
            .size(size)
            .clip(RoundedCornerShape(LocalSkin.current.cornerS + 2.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant),
        contentAlignment = Alignment.Center,
    ) {
        if (!loaded) {
            Text(
                initials(c.name),
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                fontWeight = FontWeight.Bold,
                fontSize = (size.value / 3f).sp,
            )
        }
        if (c.logo.isNotBlank()) {
            AsyncImage(
                model = c.logo,
                contentDescription = null,
                contentScale = ContentScale.Fit,
                onSuccess = { loaded = true },
                modifier = Modifier
                    .fillMaxSize()
                    .padding(4.dp),
            )
        }
    }
}

private val OnlineGreen = Color(0xFF2ECC71)
private val OfflineRed = Color(0xFFFF4D4F)

/** Зелений напівпрозорий кружок — потік працює; червоний сумний смайлик — не працює. */
@Composable
fun StreamStatusIcon(status: AppViewModel.StreamStatus?, dim: Dp) {
    when (status) {
        AppViewModel.StreamStatus.Online -> Box(
            Modifier
                .size(dim)
                .clip(CircleShape)
                .background(OnlineGreen.copy(alpha = 0.55f)),
        )
        AppViewModel.StreamStatus.Offline -> Canvas(Modifier.size(dim)) {
            val r = size.minDimension / 2f
            val c = center
            drawCircle(OfflineRed, radius = r * 0.9f, style = Stroke(width = r * 0.16f))
            drawCircle(OfflineRed, radius = r * 0.13f, center = Offset(c.x - r * 0.35f, c.y - r * 0.22f))
            drawCircle(OfflineRed, radius = r * 0.13f, center = Offset(c.x + r * 0.35f, c.y - r * 0.22f))
            drawArc(
                color = OfflineRed,
                startAngle = 200f,
                sweepAngle = 140f,
                useCenter = false,
                topLeft = Offset(c.x - r * 0.45f, c.y + r * 0.22f),
                size = Size(r * 0.9f, r * 0.7f),
                style = Stroke(width = r * 0.15f, cap = StrokeCap.Round),
            )
        }
        AppViewModel.StreamStatus.Checking -> Box(
            Modifier
                .size(dim)
                .clip(CircleShape)
                .background(Color.White.copy(alpha = 0.12f)),
        )
        null -> {}
    }
}

/** Назва плейлиста: зелений кружок — працює, червоний текст — не відповідає. */
@Composable
fun PlaylistTitle(text: String, active: Boolean?, style: TextStyle, fontWeight: FontWeight? = null) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        if (active == true) {
            val dim = with(LocalDensity.current) { style.fontSize.toDp() }
            StreamStatusIcon(AppViewModel.StreamStatus.Online, dim)
            Spacer(Modifier.width(8.dp))
        }
        Text(
            text,
            style = style,
            fontWeight = fontWeight,
            color = if (active == false) OfflineRed else Color.Unspecified,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun ChannelRow(
    c: Channel,
    favorite: Boolean,
    programme: Programme?,
    now: Long,
    modifier: Modifier = Modifier,
    selected: Boolean = false,
    compact: Boolean = false,
    status: AppViewModel.StreamStatus? = null,
    onLongClick: (() -> Unit)? = null,
    /** Кнопка «⋮» у кінці рядка (для сенсорних екранів і миші). */
    onMenu: (() -> Unit)? = null,
    onClick: () -> Unit,
) {
    val shape = RoundedCornerShape(LocalSkin.current.cornerL)
    val colors = MaterialTheme.colorScheme
    Row(
        modifier
            .fillMaxWidth()
            .focusHighlight(shape)
            .clip(shape)
            .background(if (selected) colors.secondaryContainer else colors.surface)
            // Клавіша Menu на пульті — те саме, що довге натискання
            .onKeyEvent { e ->
                if (e.type == KeyEventType.KeyDown &&
                    e.nativeKeyEvent.keyCode == android.view.KeyEvent.KEYCODE_MENU && onLongClick != null
                ) {
                    onLongClick()
                    true
                } else {
                    false
                }
            }
            .combinedClickable(onClick = onClick, onLongClick = onLongClick)
            .padding(horizontal = 10.dp, vertical = if (compact) 8.dp else 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        ChannelLogo(c, if (compact) 42.dp else 52.dp)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    "${c.number}",
                    style = MaterialTheme.typography.labelMedium,
                    color = colors.onSurfaceVariant,
                )
                Spacer(Modifier.width(8.dp))
                if (status != null) {
                    val dim = with(LocalDensity.current) { MaterialTheme.typography.titleSmall.fontSize.toDp() }
                    StreamStatusIcon(status, dim)
                    Spacer(Modifier.width(6.dp))
                }
                Text(
                    c.name,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f, fill = false),
                )
                if (favorite) {
                    Spacer(Modifier.width(6.dp))
                    Icon(Icons.Filled.Star, contentDescription = null, tint = Gold, modifier = Modifier.size(16.dp))
                }
            }
            if (programme != null) {
                Text(
                    "${hm(programme.start)}  ${programme.title}",
                    style = MaterialTheme.typography.bodySmall,
                    color = colors.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                Spacer(Modifier.height(5.dp))
                LinearProgressIndicator(
                    progress = { progressOf(programme, now) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(3.dp)
                        .clip(RoundedCornerShape(2.dp)),
                    color = colors.primary,
                    trackColor = colors.surfaceVariant,
                )
            } else {
                Text(
                    if (c.sources.size > 1) "${c.group} · джерел: ${c.sources.size}" else c.group,
                    style = MaterialTheme.typography.bodySmall,
                    color = colors.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
        }
        if (onMenu != null) {
            IconBtn(Icons.Filled.MoreVert, "Меню каналу", tint = colors.onSurfaceVariant) { onMenu() }
        }
    }
}

@Composable
fun CenterMessage(title: String, text: String, modifier: Modifier = Modifier, actions: @Composable () -> Unit = {}) {
    Column(
        modifier
            .fillMaxWidth()
            .padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
        Text(text, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        actions()
    }
}

fun Context.findActivity(): Activity? {
    var c: Context? = this
    while (c != null) {
        if (c is Activity) return c
        c = (c as? ContextWrapper)?.baseContext
    }
    return null
}

/** Цифра з клавіші пульта/клавіатури (0–9 і цифровий блок) або null. */
fun digitOfKey(keyCode: Int): Int? = when (keyCode) {
    in android.view.KeyEvent.KEYCODE_0..android.view.KeyEvent.KEYCODE_9 -> keyCode - android.view.KeyEvent.KEYCODE_0
    in android.view.KeyEvent.KEYCODE_NUMPAD_0..android.view.KeyEvent.KEYCODE_NUMPAD_9 ->
        keyCode - android.view.KeyEvent.KEYCODE_NUMPAD_0
    else -> null
}

/** Великі цифри набору номера каналу в правому верхньому куті. */
@Composable
fun NumberDialOverlay(digits: String, modifier: Modifier = Modifier) {
    if (digits.isEmpty()) return
    Text(
        digits,
        color = Color.White,
        style = MaterialTheme.typography.displayMedium,
        fontWeight = FontWeight.Bold,
        modifier = modifier
            .padding(24.dp)
            .clip(RoundedCornerShape(LocalSkin.current.cornerL))
            .background(Color.Black.copy(alpha = 0.7f))
            .padding(horizontal = 22.dp, vertical = 8.dp),
    )
}

/** Введення номера каналу з екранної клавіатури (телефон, мишка). */
@Composable
fun NumberEntryDialog(onDone: (Int) -> Unit, onDismiss: () -> Unit) {
    var text by remember { mutableStateOf("") }
    val req = remember { androidx.compose.ui.focus.FocusRequester() }
    androidx.compose.runtime.LaunchedEffect(Unit) {
        delay(100)
        try {
            req.requestFocus()
        } catch (e: Exception) {
        }
    }
    val btn = Modifier.focusHighlight(RoundedCornerShape(20.dp))
    androidx.compose.material3.AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Номер каналу") },
        text = {
            androidx.compose.material3.OutlinedTextField(
                value = text,
                onValueChange = { v -> text = v.filter { it.isDigit() }.take(5) },
                singleLine = true,
                keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(
                    keyboardType = androidx.compose.ui.text.input.KeyboardType.Number,
                    imeAction = androidx.compose.ui.text.input.ImeAction.Go,
                ),
                keyboardActions = androidx.compose.foundation.text.KeyboardActions(
                    onGo = { text.toIntOrNull()?.let(onDone) },
                ),
                modifier = Modifier.focusRequester(req),
            )
        },
        confirmButton = {
            androidx.compose.material3.TextButton(
                onClick = { text.toIntOrNull()?.let(onDone) },
                enabled = text.isNotEmpty(),
                modifier = btn,
            ) { Text("Перейти") }
        },
        dismissButton = {
            androidx.compose.material3.TextButton(onClick = onDismiss, modifier = btn) { Text("Скасувати") }
        },
    )
}
