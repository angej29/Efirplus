package com.efir.iptv.data

/** Об'єднання каналів з кількох плейлистів: однакові назви — один канал з кількома джерелами. */
object Merger {
    private val bracketRe = Regex("""[\[(][^\])]*[\])]""")
    private val qualityRe = Regex(
        """\b(uhd|fhd|hd|sd|4k|8k|hevc|h\.?265|h\.?264|\d{3,4}[pi]|\d{2,3}\s?fps|orig|original|backup|reserve)\b""",
    )

    fun normalizeName(name: String): String {
        var s = name.lowercase()
        // «Xsport+» і «Xsport» — різні канали: плюс зберігаємо як слово
        s = s.replace("+", " plus ")
        s = bracketRe.replace(s, " ")
        s = qualityRe.replace(s, " ")
        val key = s.filter { it.isLetterOrDigit() }
        return key.ifEmpty { name.lowercase().trim() }
    }

    private val GROUPS: List<Pair<List<String>, String>> = listOf(
        listOf("kids", "child", "cartoon", "anim", "дитяч", "детск", "дети", "мульт") to "Дитячі",
        listOf("sport", "спорт", "football", "футбол") to "Спорт",
        listOf("news", "новин", "новост", "інформ", "информ") to "Новини",
        listOf("series", "серіал", "сериал") to "Серіали",
        listOf("movie", "film", "cinema", "кіно", "кино", "фільм", "фильм") to "Кіно",
        listOf("music", "музик", "музык") to "Музика",
        listOf("document", "докум") to "Документальні",
        listOf("educat", "science", "пізнав", "познав", "наук", "освіт") to "Пізнавальні",
        listOf("relig", "релі", "рели") to "Релігійні",
        listOf("business", "econom", "бізнес", "бизнес", "фінанс", "финанс") to "Бізнес",
        listOf("cook", "food", "кулін", "кулин") to "Кулінарія",
        listOf("travel", "подорож", "путеш") to "Подорожі",
        listOf("regional", "local", "регіон", "регион", "місцев", "местн") to "Регіональні",
        listOf("general", "entertain", "загальн", "общ", "розваж", "развлек") to "Загальні",
    )

    /** Країни: точний збіг назви (латиниця / українська / російська). */
    private val COUNTRIES: List<Pair<List<String>, String>> = listOf(
        listOf("ukraine", "україна", "украина", "ukraina", "ua", "ukr") to "Україна",
        listOf("poland", "polska", "польща", "польша", "pl") to "Польща",
        listOf("germany", "deutschland", "німеччина", "германия", "de") to "Німеччина",
        listOf("france", "франція", "франция", "fr") to "Франція",
        listOf("italy", "italia", "італія", "италия", "it") to "Італія",
        listOf("spain", "españa", "espana", "іспанія", "испания", "es") to "Іспанія",
        listOf("united kingdom", "uk", "great britain", "britain", "england", "великобританія", "великобритания", "британія", "gb") to "Велика Британія",
        listOf("usa", "united states", "us", "america", "сша", "америка") to "США",
        listOf("canada", "канада", "ca") to "Канада",
        listOf("turkey", "türkiye", "turkiye", "туреччина", "турция", "tr") to "Туреччина",
        listOf("russia", "росія", "россия", "ru") to "Росія",
        listOf("belarus", "білорусь", "беларусь", "by") to "Білорусь",
        listOf("moldova", "молдова", "md") to "Молдова",
        listOf("romania", "românia", "румунія", "румыния", "ro") to "Румунія",
        listOf("czech", "czechia", "czech republic", "чехія", "чехия", "cz") to "Чехія",
        listOf("slovakia", "словаччина", "словакия", "sk") to "Словаччина",
        listOf("hungary", "magyarország", "угорщина", "венгрия", "hu") to "Угорщина",
        listOf("bulgaria", "болгарія", "болгария", "bg") to "Болгарія",
        listOf("lithuania", "литва", "lt") to "Литва",
        listOf("latvia", "латвія", "латвия", "lv") to "Латвія",
        listOf("estonia", "естонія", "эстония", "ee") to "Естонія",
        listOf("georgia", "грузія", "грузия", "сакартвело", "ge") to "Грузія",
        listOf("azerbaijan", "азербайджан", "az") to "Азербайджан",
        listOf("armenia", "вірменія", "армения", "am") to "Вірменія",
        listOf("kazakhstan", "казахстан", "kz") to "Казахстан",
        listOf("israel", "ізраїль", "израиль", "il") to "Ізраїль",
        listOf("portugal", "португалія", "португалия", "pt") to "Португалія",
        listOf("netherlands", "holland", "нідерланди", "нидерланды", "nl") to "Нідерланди",
        listOf("greece", "греція", "греция", "gr") to "Греція",
        listOf("india", "індія", "индия", "in") to "Індія",
        listOf("sweden", "sverige", "швеція", "швеция", "se") to "Швеція",
        listOf("norway", "norge", "норвегія", "норвегия", "no") to "Норвегія",
        listOf("finland", "suomi", "фінляндія", "финляндия", "fi") to "Фінляндія",
        listOf("denmark", "danmark", "данія", "дания", "dk") to "Данія",
        listOf("iceland", "ісландія", "исландия", "is") to "Ісландія",
        listOf("switzerland", "schweiz", "suisse", "швейцарія", "швейцария", "ch") to "Швейцарія",
        listOf("austria", "österreich", "osterreich", "австрія", "австрия", "at") to "Австрія",
        listOf("belgium", "belgique", "бельгія", "бельгия", "be") to "Бельгія",
        listOf("ireland", "ірландія", "ирландия", "ie") to "Ірландія",
        listOf("croatia", "hrvatska", "хорватія", "хорватия", "hr") to "Хорватія",
        listOf("serbia", "srbija", "сербія", "сербия", "rs") to "Сербія",
        listOf("slovenia", "slovenija", "словенія", "словения", "si") to "Словенія",
        listOf("montenegro", "чорногорія", "черногория", "me") to "Чорногорія",
        listOf("albania", "албанія", "албания", "al") to "Албанія",
        listOf("north macedonia", "macedonia", "македонія", "македония", "mk") to "Північна Македонія",
        listOf("bosnia", "bosnia and herzegovina", "боснія", "босния", "ba") to "Боснія і Герцеговина",
        listOf("japan", "японія", "япония", "jp") to "Японія",
        listOf("south korea", "korea", "корея", "південна корея", "kr") to "Південна Корея",
        listOf("china", "китай", "cn") to "Китай",
        listOf("australia", "австралія", "австралия", "au") to "Австралія",
        listOf("brazil", "brasil", "бразилія", "бразилия", "br") to "Бразилія",
        listOf("mexico", "méxico", "мексика", "mx") to "Мексика",
        listOf("argentina", "аргентина", "ar") to "Аргентина",
        listOf("united arab emirates", "uae", "оае", "оаэ", "ae") to "ОАЕ",
        listOf("saudi arabia", "саудівська аравія", "саудовская аравия", "sa") to "Саудівська Аравія",
        listOf("egypt", "єгипет", "египет", "eg") to "Єгипет",
        listOf("pakistan", "пакистан", "pk") to "Пакистан",
        listOf("iran", "іран", "иран", "ir") to "Іран",
        listOf("uzbekistan", "узбекистан", "uz") to "Узбекистан",
        listOf("singapore", "сінгапур", "сингапур", "sg") to "Сінгапур",
        listOf("international", "world", "міжнародні", "международные", "int") to "Міжнародні",
    )

    private val COUNTRY_NAMES: Set<String> = COUNTRIES.map { it.second }.toSet()

    /** Порядок країн: Україна першою, далі приблизно за індексом людського розвитку (ООН). */
    private val COUNTRY_RANK: List<String> = listOf(
        "Україна", "Швейцарія", "Норвегія", "Ісландія", "Данія", "Німеччина", "Швеція", "Австралія",
        "Нідерланди", "Бельгія", "Ірландія", "Фінляндія", "Сінгапур", "Велика Британія", "ОАЕ", "Канада",
        "США", "Австрія", "Ізраїль", "Японія", "Південна Корея", "Словенія", "Франція", "Іспанія",
        "Чехія", "Італія", "Естонія", "Греція", "Польща", "Литва", "Латвія", "Португалія",
        "Словаччина", "Хорватія", "Угорщина", "Саудівська Аравія", "Чорногорія", "Румунія", "Болгарія",
        "Туреччина", "Грузія", "Сербія", "Казахстан", "Росія", "Білорусь", "Албанія", "Вірменія",
        "Північна Македонія", "Боснія і Герцеговина", "Азербайджан", "Молдова", "Китай", "Бразилія",
        "Мексика", "Аргентина", "Іран", "Узбекистан", "Єгипет", "Індія", "Пакистан", "Міжнародні",
    )

    fun isCountry(group: String): Boolean = group in COUNTRY_NAMES

    fun countryRank(group: String): Int? = COUNTRY_RANK.indexOf(group).takeIf { it >= 0 }

    /** Точна назва або код країни → українська назва країни. */
    fun countryOf(text: String): String? {
        val l = text.lowercase().trim()
        if (l.isEmpty()) return null
        return COUNTRIES.firstOrNull { l in it.first }?.second
    }

    private val tvgCountryRe = Regex("""\.([a-z]{2})(?:@|$)""")

    /** iptv-org: tvg-id виду "1plus1.ua@SD" → Україна. */
    fun countryFromTvgId(tvgId: String): String? {
        val m = tvgCountryRe.find(tvgId.lowercase().trim()) ?: return null
        return countryOf(m.groupValues[1])
    }

    /** Плейлист однієї країни: за назвою («Польща», «Poland») або файлом (pl.m3u, countries/pl.m3u). */
    fun countryFromPlaylist(name: String, url: String): String? =
        countryOf(name) ?: countryOf(
            url.substringBefore('?').substringAfterLast('/').substringBeforeLast('.'),
        )

    fun normalizeGroup(group: String): String {
        val first = group.split(';', '|').first().trim()
        if (first.isEmpty() || first == M3uParser.NO_GROUP) return M3uParser.NO_GROUP
        val l = first.lowercase()
        for ((keys, name) in COUNTRIES) if (l in keys) return name
        for ((keys, name) in GROUPS) if (keys.any { l.contains(it) }) return name
        return first.replaceFirstChar { it.uppercase() }
    }

    private val TRANSLIT = mapOf(
        'а' to "a", 'б' to "b", 'в' to "v", 'г' to "g", 'ґ' to "g", 'д' to "d", 'е' to "e", 'є' to "e",
        'ё' to "e", 'ж' to "zh", 'з' to "z", 'и' to "i", 'і' to "i", 'ї' to "i", 'й' to "i", 'к' to "k",
        'л' to "l", 'м' to "m", 'н' to "n", 'о' to "o", 'п' to "p", 'р' to "r", 'с' to "s", 'т' to "t",
        'у' to "u", 'ф' to "f", 'х' to "h", 'ц' to "ts", 'ч' to "ch", 'ш' to "sh", 'щ' to "sh",
        'ъ' to "", 'ы' to "i", 'ь' to "", 'э' to "e", 'ю' to "u", 'я' to "a",
    )

    /**
     * "Скелет" назви для порівняння кирилиці й латиниці: транслітерація, спрощення
     * схожих звуків, без подвоєнь і кінцевих голосних. «Дискавері» ≈ «Discovery».
     */
    fun groupSkeleton(name: String): String {
        val sb = StringBuilder()
        for (ch in name.lowercase()) {
            when {
                TRANSLIT.containsKey(ch) -> sb.append(TRANSLIT[ch])
                ch.isLetterOrDigit() -> sb.append(ch)
            }
        }
        var s = sb.toString()
            .replace("ph", "f").replace("ck", "k").replace("x", "ks")
            .replace('c', 'k').replace('q', 'k').replace('w', 'v')
            .replace('y', 'i').replace('j', 'i').replace("h", "")
        val dedup = StringBuilder()
        for (ch in s) if (dedup.isEmpty() || dedup.last() != ch) dedup.append(ch)
        s = dedup.toString().trimEnd('a', 'e', 'i', 'o', 'u')
        return s.ifEmpty { name.lowercase() }
    }

    /** Плейлист для режиму «Усі плейлисти» + країна, якщо це плейлист однієї країни. */
    data class Part(val playlist: ParsedPlaylist, val country: String?)

    /**
     * Об'єднання в межах одного плейлиста: однакові канали (різна лише якість/регістр) —
     * один рядок з кількома потоками. Ключ і група першого каналу зберігаються.
     * Канали з різними назвами (NTV і HTV) лишаються окремими.
     */
    fun mergeSingle(p: ParsedPlaylist): ParsedPlaylist {
        val map = LinkedHashMap<String, MutableList<Channel>>()
        for (c in p.channels) map.getOrPut(normalizeName(c.name)) { ArrayList() }.add(c)
        if (map.size == p.channels.size) return p
        val out = ArrayList<Channel>(map.size)
        for ((_, list) in map) {
            val primary = list.first()
            val sources = dedupeSources(list)
            out += if (sources.size < 2) primary else primary.copy(
                logo = list.firstOrNull { it.logo.isNotBlank() }?.logo.orEmpty(),
                tvgId = list.firstOrNull { it.tvgId.isNotBlank() }?.tvgId.orEmpty(),
                tvgName = list.firstOrNull { it.tvgName.isNotBlank() }?.tvgName.orEmpty(),
                sources = sources,
            )
        }
        return p.copy(channels = out)
    }

    fun merge(parts: List<Part>): ParsedPlaylist {
        val map = LinkedHashMap<String, MutableList<Channel>>()
        // Група кожного каналу: країна (з tvg-id, плейлиста або назви групи), інакше тематика
        for (part in parts) for (c in part.playlist.channels) {
            val raw = c.group.split(';', '|').first().trim()
            val country = countryFromTvgId(c.tvgId) ?: part.country ?: countryOf(raw)
            val g = country ?: normalizeGroup(c.group)
            map.getOrPut(normalizeName(c.name)) { ArrayList() }.add(if (g != c.group) c.copy(group = g) else c)
        }
        val out = ArrayList<Channel>(map.size)
        val bySkeleton = HashMap<String, String>()
        fun unify(g: String): String =
            if (g == M3uParser.NO_GROUP) g else bySkeleton.getOrPut(groupSkeleton(g)) { g }
        for ((k, list) in map) {
            val primary = list.first()
            val sources = dedupeSources(list)
            // Країна має перевагу над тематикою; кирилиця/латиниця тематик зводиться в одну
            val group = list.firstOrNull { isCountry(it.group) }?.group
                ?: unify(list.firstOrNull { it.group != M3uParser.NO_GROUP }?.group ?: M3uParser.NO_GROUP)
            out += primary.copy(
                key = "all|$k",
                number = out.size + 1,
                logo = list.firstOrNull { it.logo.isNotBlank() }?.logo.orEmpty(),
                group = group,
                tvgId = list.firstOrNull { it.tvgId.isNotBlank() }?.tvgId.orEmpty(),
                tvgName = list.firstOrNull { it.tvgName.isNotBlank() }?.tvgName.orEmpty(),
                sources = if (sources.size > 1) sources else emptyList(),
            )
        }
        return ParsedPlaylist(out, "")
    }

    private val q4k = Regex("""\b(4k|uhd|2160[pi]?)\b""")
    private val qfhd = Regex("""\b(fhd|full\s?hd|1080[pi]?)\b""")
    private val qhd = Regex("""\b(hd|720[pi]?)\b""")
    private val qsd = Regex("""\b(sd|576[pi]?|480[pi]?)\b""")

    private fun qualityTag(c: Channel): String {
        val t = c.name.lowercase()
        return when {
            q4k.containsMatchIn(t) -> "4k"
            qfhd.containsMatchIn(t) -> "fhd"
            qhd.containsMatchIn(t) -> "hd"
            qsd.containsMatchIn(t) -> "sd"
            else -> "?"
        }
    }

    /**
     * Прибирає дублікати джерел: однакова адреса (без параметрів і різниці http/https)
     * або той самий сервер з тією ж якістю — лишається перший варіант.
     */
    fun dedupeSources(list: List<Channel>): List<Channel> {
        val seenPath = HashSet<String>()
        val seenHost = HashSet<String>()
        return list.filter { c ->
            val path = c.url.substringAfter("://").substringBefore('?').trimEnd('/').lowercase()
            if (!seenPath.add(path)) return@filter false
            val host = path.substringBefore('/').substringBefore(':')
            if (host.isBlank()) true else seenHost.add(host + "|" + qualityTag(c))
        }
    }
}
