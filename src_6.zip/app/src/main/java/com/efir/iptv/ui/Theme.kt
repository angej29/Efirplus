package com.efir.iptv.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Accent = Color(0xFF4F8CFF)
val Gold = Color(0xFFFFC857)
val Bg = Color(0xFF0E1116)

private val scheme = darkColorScheme(
    primary = Accent,
    onPrimary = Color.White,
    secondary = Color(0xFF7AE0B8),
    background = Bg,
    onBackground = Color(0xFFE6EAF0),
    surface = Color(0xFF161B22),
    onSurface = Color(0xFFE6EAF0),
    surfaceVariant = Color(0xFF1F2630),
    onSurfaceVariant = Color(0xFF9AA4B2),
    secondaryContainer = Color(0xFF243B63),
    onSecondaryContainer = Color.White,
    outline = Color(0xFF3A4452),
)

@Composable
fun EfirTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = scheme, content = content)
}
