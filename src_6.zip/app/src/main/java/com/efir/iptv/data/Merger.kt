package com.efir.iptv.data

/** Об'єднання каналів з кількох плейлистів: однакові назви — один канал з кількома джерелами. */
object Merger {
    private val bracketRe = Regex("""[\[(][^\])]*[\])]""")
    private val qualityRe = Regex(
        """\b(uhd|fhd|hd|sd|4k|8k|hevc|h\.?265|h\.?264|\d{3,4}[pi]|\d{2,3}\s?fps|orig|original|backup|reserve)\b""",
    )

    fun normalizeName(name: String): String {
        var s = name.lowercase()
        s = bracketRe.replace(s, " ")
        s = qualityRe.replace(s, " ")
        val key = s.filter { it.isLetterOrDigit() }
        return key.ifEmpty { name.lowercase().trim() }
    }

    private val GROUPS: List<Pair<List<String>, String>> = listOf(
        listOf("kids", "child", "cartoon", "anim", "дитяч", "детск", "дети", "мульт") to "Дитячі",
        listOf("sport", "спорт", "football", "футбол") to "Спорт",
        listOf("news", "новин", "новост", "інформ", "информ") to "Новини",
        listOf("series", "серіал", "сериал") to "Серіали",
        listOf("movie", "film", "cinema", "кіно", "кино", "фільм", "фильм") to "Кіно",
        listOf("music", "музик", "музык") to "Музика",
        listOf("document", "докум") to "Документальні",
        listOf("educat", "science", "пізнав", "познав", "наук", "освіт") to "Пізнавальні",
        listOf("relig", "релі", "рели") to "Релігійні",
        listOf("business", "econom", "бізнес", "бизнес", "фінанс", "финанс") to "Бізнес",
        listOf("cook", "food", "кулін", "кулин") to "Кулінарія",
        listOf("travel", "подорож", "путеш") to "Подорожі",
        listOf("regional", "local", "регіон", "регион", "місцев", "местн") to "Регіональні",
        listOf("general", "entertain", "загальн", "общ", "розваж", "развлек") to "Загальні",
    )

    /** Країни: точний збіг назви (латиниця / українська / російська). */
    private val COUNTRIES: List<Pair<List<String>, String>> = listOf(
        listOf("ukraine", "україна", "украина", "ukraina", "ua", "ukr") to "Україна",
        listOf("poland", "polska", "польща", "польша", "pl") to "Польща",
        listOf("germany", "deutschland", "німеччина", "германия", "de") to "Німеччина",
        listOf("france", "франція", "франция", "fr") to "Франція",
        listOf("italy", "italia", "італія", "италия", "it") to "Італія",
        listOf("spain", "españa", "espana", "іспанія", "испания", "es") to "Іспанія",
        listOf("united kingdom", "uk", "great britain", "britain", "england", "великобританія", "великобритания", "британія", "gb") to "Велика Британія",
        listOf("usa", "united states", "us", "america", "сша", "америка") to "США",
        listOf("canada", "канада", "ca") to "Канада",
        listOf("turkey", "türkiye", "turkiye", "туреччина", "турция", "tr") to "Туреччина",
        listOf("russia", "росія", "россия", "ru") to "Росія",
        listOf("belarus", "білорусь", "беларусь", "by") to "Білорусь",
        listOf("moldova", "молдова", "md") to "Молдова",
        listOf("romania", "românia", "румунія", "румыния", "ro") to "Румунія",
        listOf("czech", "czechia", "czech republic", "чехія", "чехия", "cz") to "Чехія",
        listOf("slovakia", "словаччина", "словакия", "sk") to "Словаччина",
        listOf("hungary", "magyarország", "угорщина", "венгрия", "hu") to "Угорщина",
        listOf("bulgaria", "болгарія", "болгария", "bg") to "Болгарія",
        listOf("lithuania", "литва", "lt") to "Литва",
        listOf("latvia", "латвія", "латвия", "lv") to "Латвія",
        listOf("estonia", "естонія", "эстония", "ee") to "Естонія",
        listOf("georgia", "грузія", "грузия", "сакартвело", "ge") to "Грузія",
        listOf("azerbaijan", "азербайджан", "az") to "Азербайджан",
        listOf("armenia", "вірменія", "армения", "am") to "Вірменія",
        listOf("kazakhstan", "казахстан", "kz") to "Казахстан",
        listOf("israel", "ізраїль", "израиль", "il") to "Ізраїль",
        listOf("portugal", "португалія", "португалия", "pt") to "Португалія",
        listOf("netherlands", "holland", "нідерланди", "нидерланды", "nl") to "Нідерланди",
        listOf("greece", "греція", "греция", "gr") to "Греція",
        listOf("india", "індія", "индия", "in") to "Індія",
        listOf("international", "world", "міжнародні", "международные", "int") to "Міжнародні",
    )

    fun normalizeGroup(group: String): String {
        val first = group.split(';', '|').first().trim()
        if (first.isEmpty() || first == M3uParser.NO_GROUP) return M3uParser.NO_GROUP
        val l = first.lowercase()
        for ((keys, name) in COUNTRIES) if (l in keys) return name
        for ((keys, name) in GROUPS) if (keys.any { l.contains(it) }) return name
        return first.replaceFirstChar { it.uppercase() }
    }

    private val TRANSLIT = mapOf(
        'а' to "a", 'б' to "b", 'в' to "v", 'г' to "g", 'ґ' to "g", 'д' to "d", 'е' to "e", 'є' to "e",
        'ё' to "e", 'ж' to "zh", 'з' to "z", 'и' to "i", 'і' to "i", 'ї' to "i", 'й' to "i", 'к' to "k",
        'л' to "l", 'м' to "m", 'н' to "n", 'о' to "o", 'п' to "p", 'р' to "r", 'с' to "s", 'т' to "t",
        'у' to "u", 'ф' to "f", 'х' to "h", 'ц' to "ts", 'ч' to "ch", 'ш' to "sh", 'щ' to "sh",
        'ъ' to "", 'ы' to "i", 'ь' to "", 'э' to "e", 'ю' to "u", 'я' to "a",
    )

    /**
     * "Скелет" назви для порівняння кирилиці й латиниці: транслітерація, спрощення
     * схожих звуків, без подвоєнь і кінцевих голосних. «Дискавері» ≈ «Discovery».
     */
    fun groupSkeleton(name: String): String {
        val sb = StringBuilder()
        for (ch in name.lowercase()) {
            when {
                TRANSLIT.containsKey(ch) -> sb.append(TRANSLIT[ch])
                ch.isLetterOrDigit() -> sb.append(ch)
            }
        }
        var s = sb.toString()
            .replace("ph", "f").replace("ck", "k").replace("x", "ks")
            .replace('c', 'k').replace('q', 'k').replace('w', 'v')
            .replace('y', 'i').replace('j', 'i').replace("h", "")
        val dedup = StringBuilder()
        for (ch in s) if (dedup.isEmpty() || dedup.last() != ch) dedup.append(ch)
        s = dedup.toString().trimEnd('a', 'e', 'i', 'o', 'u')
        return s.ifEmpty { name.lowercase() }
    }

    fun merge(parts: List<ParsedPlaylist>): ParsedPlaylist {
        val map = LinkedHashMap<String, MutableList<Channel>>()
        for (p in parts) for (c in p.channels) map.getOrPut(normalizeName(c.name)) { ArrayList() }.add(c)
        val out = ArrayList<Channel>(map.size)
        val bySkeleton = HashMap<String, String>()
        fun unify(g: String): String =
            if (g == M3uParser.NO_GROUP) g else bySkeleton.getOrPut(groupSkeleton(g)) { g }
        for ((k, list) in map) {
            val primary = list.first()
            val sources = list.distinctBy { it.url }
            val group = unify(
                list.map { normalizeGroup(it.group) }.firstOrNull { it != M3uParser.NO_GROUP } ?: M3uParser.NO_GROUP,
            )
            out += primary.copy(
                key = "all|$k",
                number = out.size + 1,
                logo = list.firstOrNull { it.logo.isNotBlank() }?.logo.orEmpty(),
                group = group,
                tvgId = list.firstOrNull { it.tvgId.isNotBlank() }?.tvgId.orEmpty(),
                tvgName = list.firstOrNull { it.tvgName.isNotBlank() }?.tvgName.orEmpty(),
                sources = if (sources.size > 1) sources else emptyList(),
            )
        }
        return ParsedPlaylist(out, "")
    }
}
