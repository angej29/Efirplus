package com.efir.iptv

import android.app.Application
import android.content.Context
import android.net.Uri
import android.widget.Toast
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.Format
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.Tracks
import androidx.media3.common.VideoSize
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.hls.DefaultHlsExtractorFactory
import androidx.media3.exoplayer.hls.HlsMediaSource
import androidx.media3.extractor.DefaultExtractorsFactory
import androidx.media3.extractor.ts.DefaultTsPayloadReaderFactory
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import com.efir.iptv.data.Catchup
import com.efir.iptv.data.Channel
import com.efir.iptv.data.Xtream
import com.efir.iptv.data.EpgParser
import com.efir.iptv.data.HOUR
import com.efir.iptv.data.M3uParser
import com.efir.iptv.data.Merger
import com.efir.iptv.data.Net
import com.efir.iptv.data.ParsedPlaylist
import com.efir.iptv.data.PlaylistSource
import com.efir.iptv.data.Programme
import com.efir.iptv.data.Storage
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import java.io.BufferedInputStream
import java.io.File
import java.io.FileInputStream
import java.io.IOException
import java.util.Locale
import java.util.UUID

class AppViewModel(app: Application) : AndroidViewModel(app) {

    enum class Screen { Home, Player, Playlists, Guide }

    data class State(
        val playlists: List<PlaylistSource> = emptyList(),
        val selectedId: String? = null,
        val channels: List<Channel> = emptyList(),
        val groups: List<String> = emptyList(),
        val loading: Boolean = false,
        val error: String? = null,
        val favorites: Set<String> = emptySet(),
        val recents: List<String> = emptyList(),
        val epg: Map<String, List<Programme>> = emptyMap(),
        val epgLoading: Boolean = false,
        val hiddenCount: Int = 0,
        val movedCount: Int = 0,
        /** Скільки каналів 18+ зараз заблоковано батьківським контролем. */
        val lockedCount: Int = 0,
    )

    data class Playback(val buffering: Boolean = false, val error: String? = null)

    enum class StreamStatus { Checking, Online, Offline }

    data class AudioTrack(
        val group: Int,
        val index: Int,
        val label: String,
        val selected: Boolean,
        val supported: Boolean,
    )

    private val ctx: Context = app.applicationContext
    private val storage = Storage(ctx)

    private val _state = MutableStateFlow(State())
    val state: StateFlow<State> = _state.asStateFlow()

    val screen = MutableStateFlow(Screen.Home)
    val skin = MutableStateFlow(
        try {
            com.efir.iptv.ui.Skin.valueOf(Storage(app.applicationContext).skin)
        } catch (e: Exception) {
            com.efir.iptv.ui.Skin.CLASSIC
        },
    )
    val selectedGroup = MutableStateFlow(GROUP_ALL)
    val query = MutableStateFlow("")
    val inPip = MutableStateFlow(false)

    val current = MutableStateFlow<Channel?>(null)
    val queue = MutableStateFlow<List<Channel>>(emptyList())
    val playback = MutableStateFlow(Playback())

    /** Стан потоків: перевіряються лише канали, видимі на екрані. */
    val streamStatus = MutableStateFlow<Map<String, StreamStatus>>(emptyMap())
    private val checkedAt = HashMap<String, Long>()
    private val probeLimit = Semaphore(10)

    /** Масова перевірка: (перевірено, усього) або null, якщо не йде. */
    val cleanup = MutableStateFlow<Pair<Int, Int>?>(null)
    private var cleanupJob: Job? = null

    /** Доступність плейлистів: id → true (працює) / false (не відповідає). */
    val playlistStatus = MutableStateFlow<Map<String, Boolean>>(emptyMap())

    val audioTracks = MutableStateFlow<List<AudioTrack>>(emptyList())
    private var audioGroups: List<Tracks.Group> = emptyList()

    // FFmpeg-декодер має пріоритет для звуку: однаково працює на всіх пристроях,
    // включно з MP2 та AC3, яких часто немає в системних декодерах телефонів.
    private val renderers = DefaultRenderersFactory(ctx)
        .setExtensionRendererMode(DefaultRenderersFactory.EXTENSION_RENDERER_MODE_PREFER)
        .setEnableDecoderFallback(true)

    private val extractors = DefaultExtractorsFactory()
        .setTsExtractorFlags(TS_FLAGS)
        .setConstantBitrateSeekingEnabled(true)

    val player: ExoPlayer = ExoPlayer.Builder(ctx, renderers)
        .setAudioAttributes(
            AudioAttributes.Builder()
                .setUsage(C.USAGE_MEDIA)
                .setContentType(C.AUDIO_CONTENT_TYPE_MOVIE)
                .build(),
            true,
        )
        .build()

    private var restoreGroupPending = false
    private var autostartPending = false
    val startLastChannel = MutableStateFlow(true)

    /** Ключ каналу, який дивились останнім у поточному плейлисті (для прокрутки списку до нього). */
    val lastChannelKey = MutableStateFlow<String?>(null)

    private var allChannels: List<Channel> = emptyList()
    val parentalOn = MutableStateFlow(false)
    val adultUnlocked = MutableStateFlow(false)
    private var adultGroups: Set<String> = emptySet()
    val adultGroupsFlow = MutableStateFlow<Set<String>>(emptySet())
    private var groupOverrides: Map<String, String> = emptyMap()
    private var groupRenames: Map<String, String> = emptyMap()
    private var groupOrder: List<String> = emptyList()
    private var hidden: Set<String> = emptySet()
    private var playlistEpg = ""

    private var sourceIndex = 0
    /** Порядок джерел поточного каналу: найкраща якість → така ж якість → нижча → відомі неробочі. */
    private var playOrder: List<Channel> = emptyList()
    /** Що відомо про кожне джерело: url → працює / ні. */
    private val sourceOk = HashMap<String, Boolean>()
    /** Непрацюючі джерела, прибрані чисткою (url). Спільні для всіх плейлистів. */
    private var deadSources: Set<String> = emptySet()
    val deadSourceCount = MutableStateFlow(0)
    /** Йде перевірка джерел поточного каналу. */
    val sourceCleanupRunning = MutableStateFlow(false)
    /** Інфо про потік унизу плеєра: роздільність, кодек, звук. */
    val streamInfo = MutableStateFlow<String?>(null)

    /** Підпис у плеєрі: «Джерело 2 з 3 · FHD». */
    val sourceInfo = MutableStateFlow<String?>(null)

    data class SourceChoice(
        val index: Int,
        val title: String,
        val subtitle: String,
        val current: Boolean,
        val ok: Boolean?,
        val preferred: Boolean,
    )

    /** Джерела поточного каналу для ручного перемикання. */
    val sourceChoices = MutableStateFlow<List<SourceChoice>>(emptyList())
    /** Вибране користувачем джерело за замовчуванням: ключ каналу → url. */
    private var preferredSource: Map<String, String> = emptyMap()
    private var triedHls = false
    private var retries = 0
    private var loadJob: Job? = null
    private var epgJob: Job? = null
    private var retryJob: Job? = null

    init {
        player.playWhenReady = true
        player.trackSelectionParameters = player.trackSelectionParameters.buildUpon()
            .setPreferredAudioLanguages("uk", "en")
            .build()
        player.addListener(object : Player.Listener {
            override fun onPlaybackStateChanged(playbackState: Int) {
                playback.update { it.copy(buffering = playbackState == Player.STATE_BUFFERING) }
                if (playbackState == Player.STATE_READY) {
                    current.value?.let { c ->
                        markStatus(c.key, StreamStatus.Online)
                        playOrder.getOrNull(sourceIndex)?.let { sourceOk[it.url] = true }
                        updateSourceChoices(c)
                    }
                    retries = 0
                    playback.update { it.copy(error = null) }
                }
                if (playbackState == Player.STATE_ENDED) {
                    // Передача з архіву скінчилась — повертаємось у прямий ефір
                    if (archive.value != null) goLive() else scheduleRestart(1000)
                }
            }

            override fun onPlayerError(error: PlaybackException) = handleError(error)

            override fun onTracksChanged(tracks: Tracks) {
                updateAudioTracks(tracks)
                updateStreamInfo()
            }

            override fun onVideoSizeChanged(videoSize: VideoSize) = updateStreamInfo()
        })

        preferredSource = storage.stringMap("pref_sources")
        deadSources = storage.stringList("dead_sources").toSet()
        deadSourceCount.value = deadSources.size
        val list = storage.loadPlaylists()
        val sel = storage.selectedId?.takeIf { id -> (id == ALL_ID && list.size > 1) || list.any { it.id == id } }
            ?: list.firstOrNull()?.id
        _state.update {
            it.copy(
                playlists = list,
                selectedId = sel,
                favorites = storage.favorites(),
                recents = storage.recents(),
            )
        }
        if (sel != null) {
            hidden = storage.hidden(sel)
            loadGroupSettings(sel)
        }
        checkPlaylists()
        loadParental()
        restoreGroupPending = true
        autostartPending = true
        startLastChannel.value = autostartPending
        if (sel == null) screen.value = Screen.Playlists else load(force = false)
    }

    // ---------------- Плейлисти ----------------

    private fun currentSource(): PlaylistSource? =
        _state.value.playlists.firstOrNull { it.id == _state.value.selectedId }

    fun load(force: Boolean) {
        val selId = _state.value.selectedId ?: return
        if (force) clearStatuses()
        loadJob?.cancel()
        if (selId == ALL_ID) {
            loadAll(force)
            return
        }
        val src = currentSource() ?: return
        loadJob = viewModelScope.launch {
            _state.update { it.copy(loading = true, error = null) }
            val file = storage.playlistFile(src.id)
            var parsed: ParsedPlaylist? = null
            if (!force && file.exists()) {
                parsed = withContext(Dispatchers.IO) {
                    try {
                        M3uParser.parse(file.readText())
                    } catch (e: Exception) {
                        null
                    }
                }
                if (parsed != null && parsed.channels.isNotEmpty()) applyChannels(parsed) else parsed = null
            }
            val stale = !file.exists() || System.currentTimeMillis() - file.lastModified() > 6 * HOUR
            if (force || parsed == null || stale) {
                try {
                    val text = withContext(Dispatchers.IO) { downloadPlaylist(src) }
                    val fresh = withContext(Dispatchers.Default) { M3uParser.parse(text) }
                    if (fresh.channels.isEmpty()) throw IOException("плейлист порожній або має невідомий формат")
                    withContext(Dispatchers.IO) { file.writeText(text) }
                    parsed = fresh
                    applyChannels(fresh)
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    if (parsed == null) {
                        _state.update {
                            it.copy(error = "Не вдалося завантажити плейлист: ${e.message ?: e.javaClass.simpleName}")
                        }
                    }
                }
            }
            _state.update { it.copy(loading = false) }
            val result = parsed
            if (result != null) loadEpg(src, result, force)
        }
    }

    // ---------------- Режим «Усі плейлисти» ----------------

    private fun loadAll(force: Boolean) {
        val sources = _state.value.playlists
        loadJob = viewModelScope.launch {
            _state.update { it.copy(loading = true, error = null) }
            val parts = ArrayList<Pair<PlaylistSource, ParsedPlaylist>>()
            for (src in sources) {
                val p = fetchPlaylist(src, force) ?: continue
                val hiddenHere = storage.hidden(src.id)
                parts += src to p.copy(channels = p.channels.filter { it.key !in hiddenHere })
            }
            if (parts.isEmpty()) {
                _state.update { it.copy(loading = false, error = "Не вдалося завантажити жоден плейлист") }
                return@launch
            }
            val merged = withContext(Dispatchers.Default) {
                Merger.merge(parts.map { (src, p) -> Merger.Part(p, Merger.countryFromPlaylist(src.name, src.url)) })
            }
            applyChannels(merged)
            _state.update { it.copy(loading = false) }
            // Телепрограма, вказана вручну, має перевагу над вбудованою в плейлист
            val epgUrl = parts.map { it.first.epgUrl }.firstOrNull { it.isNotBlank() }
                ?: parts.map { it.second.epgUrl }.firstOrNull { it.isNotBlank() } ?: ""
            loadEpg(PlaylistSource(ALL_ID, ALL_NAME, "", epgUrl), merged, force)
        }
    }

    /** Плейлист із кешу (якщо свіжий) або з мережі; при помилці мережі — з кешу. */
    private suspend fun fetchPlaylist(src: PlaylistSource, force: Boolean): ParsedPlaylist? {
        val file = storage.playlistFile(src.id)
        val fresh = file.exists() && System.currentTimeMillis() - file.lastModified() < 6 * HOUR
        if (!force && fresh) readCached(file)?.let { return it }
        return try {
            val text = withContext(Dispatchers.IO) { downloadPlaylist(src) }
            val p = withContext(Dispatchers.Default) { M3uParser.parse(text) }
            if (p.channels.isEmpty()) throw IOException("порожній плейлист")
            withContext(Dispatchers.IO) { file.writeText(text) }
            p
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            readCached(file)
        }
    }

    private suspend fun readCached(file: File): ParsedPlaylist? = withContext(Dispatchers.IO) {
        try {
            if (file.exists()) M3uParser.parse(file.readText()).takeIf { it.channels.isNotEmpty() } else null
        } catch (e: Exception) {
            null
        }
    }

    private fun applyChannels(p: ParsedPlaylist) {
        // В окремому плейлисті однакові канали теж об'єднуються в один з кількома потоками
        allChannels = if (_state.value.selectedId == ALL_ID) p.channels else Merger.mergeSingle(p).channels
        playlistEpg = p.epgUrl
        recompute()
        restoreSession()
    }

    // ---------------- Останній канал, група, набір номера ----------------


    fun setStartLastChannel(on: Boolean) {
        startLastChannel.value = on
        storage.putBool("autostart_last", on)
    }

    /** Вибір групи з запам'ятовуванням (після перезапуску відкриється та сама). */
    fun chooseGroup(g: String) {
        selectedGroup.value = g
        _state.value.selectedId?.let { storage.putString("last_group_$it", g) }
    }

    private fun restoreSession() {
        val id = _state.value.selectedId ?: return
        lastChannelKey.value = storage.getString("last_ch_$id")
        if (restoreGroupPending) {
            restoreGroupPending = false
            val g = storage.getString("last_group_$id")
            if (g != null && (g in SPECIAL_GROUPS || g in _state.value.groups)) selectedGroup.value = g
        }
        if (autostartPending) {
            autostartPending = false
            val key = lastChannelKey.value ?: return
            val c = _state.value.channels.firstOrNull { it.key == key } ?: return
            if (screen.value == Screen.Home) play(c, filter(_state.value, selectedGroup.value, ""))
        }
    }

    /** Перемикання за номером каналу: спершу в поточному списку, потім серед усіх. */
    fun playNumber(n: Int): Boolean {
        val c = queue.value.firstOrNull { it.number == n }
            ?: _state.value.channels.firstOrNull { it.number == n }
        if (c == null) {
            toast("Канал №$n не знайдено")
            return false
        }
        val list = if (queue.value.any { it.key == c.key } && screen.value == Screen.Player) {
            queue.value
        } else {
            filter(_state.value, selectedGroup.value, "").takeIf { l -> l.any { it.key == c.key } } ?: _state.value.channels
        }
        play(c, list)
        return true
    }

    /** Застосовує список видалених (прихованих) каналів до повного плейлиста. */
    private fun recompute() {
        // 1) ручні переміщення, 2) перейменування вкладок
        val base = allChannels
            .filter { it.key !in hidden }
            .map { stripDead(it) }
            .map { c ->
                val g0 = groupOverrides[c.key] ?: c.group
                val g1 = groupRenames[g0] ?: g0
                if (g1 != c.group) c.copy(group = g1) else c
            }
        // 3) малі групи (до 5 каналів) і «Без групи» → «Інше»; групи, створені вручну, не чіпаємо
        val otherName = groupRenames[OTHER_GROUP] ?: OTHER_GROUP
        val manual = groupOverrides.values.map { groupRenames[it] ?: it }.toSet() + groupRenames.values
        val counts = base.groupingBy { it.group }.eachCount()
        val visible = base.map { c ->
            val fold = c.group == M3uParser.NO_GROUP ||
                ((counts[c.group] ?: 0) <= SMALL_GROUP && c.group !in manual && !Merger.isCountry(c.group))
            if (fold && c.group != otherName) c.copy(group = otherName) else c
        }
        // Батьківський контроль: канали 18+ ховаємо, доки не введено PIN
        val hideAdult = parentalOn.value && !adultUnlocked.value
        val adultCount = if (hideAdult) visible.count { isAdult(it) } else 0
        val shown = if (adultCount > 0) visible.filter { !isAdult(it) } else visible
        // 4) порядок вкладок: збережений вручну; далі країни (Україна першою, потім за розвитком),
        //    тематичні — у порядку появи, «Інше» в кінці
        val appearance = shown.map { it.group }.distinct()
        val orderIdx = groupOrder.withIndex().associate { (i, g) -> g to i }
        val groups = appearance.sortedWith(
            compareBy<String>(
                { orderIdx[it] ?: Int.MAX_VALUE },
                { if (it == otherName) 2 else if (Merger.isCountry(it)) 0 else 1 },
                { Merger.countryRank(it) ?: Int.MAX_VALUE },
            ),
        ) + (if (adultCount > 0) listOf(LOCKED_GROUP) else emptyList())
        _state.update {
            it.copy(
                channels = shown,
                lockedCount = adultCount,
                groups = groups,
                error = null,
                hiddenCount = allChannels.size - allChannels.count { c -> c.key !in hidden },
                movedCount = groupOverrides.size + groupRenames.size + (if (groupOrder.isEmpty()) 0 else 1),
            )
        }
        val g = selectedGroup.value
        if (g !in SPECIAL_GROUPS && (g !in groups || g == LOCKED_GROUP)) selectedGroup.value = GROUP_ALL
    }

    // ---------------- Батьківський контроль (18+) ----------------


    private fun loadParental() {
        parentalOn.value = storage.getBool("parental_on", false) && !storage.getString("parental_pin").isNullOrBlank()
        adultGroups = storage.stringList("adult_groups").toSet()
        adultGroupsFlow.value = adultGroups
    }

    /** Канал для дорослих: за групою або назвою, або група позначена вручну. */
    fun isAdult(c: Channel): Boolean {
        if (c.group in adultGroups) return true
        val g = c.group.lowercase()
        if (ADULT_GROUP_KEYS.any { g.contains(it) }) return true
        val n = c.name.lowercase()
        return ADULT_NAME_KEYS.any { n.contains(it) }
    }

    fun checkPin(pin: String): Boolean = pin.isNotBlank() && pin == storage.getString("parental_pin")

    /** Увімкнути контроль із новим PIN. */
    fun enableParental(pin: String) {
        storage.putString("parental_pin", pin)
        storage.putBool("parental_on", true)
        parentalOn.value = true
        adultUnlocked.value = false
        recompute()
        toast("Батьківський контроль увімкнено")
    }

    fun disableParental(pin: String): Boolean {
        if (!checkPin(pin)) {
            toast("Невірний PIN")
            return false
        }
        storage.putBool("parental_on", false)
        parentalOn.value = false
        adultUnlocked.value = false
        recompute()
        toast("Батьківський контроль вимкнено")
        return true
    }

    fun unlockAdult(pin: String): Boolean {
        if (!checkPin(pin)) {
            toast("Невірний PIN")
            return false
        }
        adultUnlocked.value = true
        recompute()
        return true
    }

    fun lockAdult() {
        adultUnlocked.value = false
        recompute()
    }

    /** Ручна позначка групи як «18+». */
    fun toggleAdultGroup(g: String) {
        adultGroups = if (g in adultGroups) adultGroups - g else adultGroups + g
        adultGroupsFlow.value = adultGroups
        storage.saveStringList("adult_groups", adultGroups.toList())
        recompute()
    }

    // ---------------- Вигляд головного екрана ----------------

    /** 0 — список, 1 — плитки в 2 стовпці, 2 — плитки в 4 стовпці. */
    val viewMode = MutableStateFlow(storage.getString("view_mode")?.toIntOrNull() ?: 0)

    fun setViewMode(m: Int) {
        viewMode.value = m
        storage.putString("view_mode", m.toString())
    }

    /** Власні фони: назва скіна → шлях до зменшеної копії фото. */
    val backgrounds = MutableStateFlow(
        storage.stringMap("backgrounds").filterValues { File(it).exists() },
    )

    /** Своє фото фоном для скіна: копія зменшується (до ~2400 px), щоб не навантажувати пам'ять. */
    fun setCustomBackground(s: com.efir.iptv.ui.Skin, open: () -> java.io.InputStream?) {
        viewModelScope.launch {
            try {
                val path = withContext(Dispatchers.IO) {
                    val bytes = open()?.use { it.readBytes() } ?: throw IOException("не вдалося відкрити файл")
                    val bounds = android.graphics.BitmapFactory.Options().apply { inJustDecodeBounds = true }
                    android.graphics.BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
                    var sample = 1
                    while (maxOf(bounds.outWidth, bounds.outHeight) / sample > 2400) sample *= 2
                    val bmp = android.graphics.BitmapFactory.decodeByteArray(
                        bytes, 0, bytes.size,
                        android.graphics.BitmapFactory.Options().apply { inSampleSize = sample },
                    ) ?: throw IOException("це не зображення")
                    val dir = File(ctx.filesDir, "backgrounds").apply { mkdirs() }
                    dir.listFiles()?.filter { it.name.startsWith(s.name + "_") }?.forEach { it.delete() }
                    val out = File(dir, "${s.name}_${System.currentTimeMillis()}.jpg")
                    out.outputStream().use { bmp.compress(android.graphics.Bitmap.CompressFormat.JPEG, 88, it) }
                    bmp.recycle()
                    out.absolutePath
                }
                backgrounds.update { it + (s.name to path) }
                storage.saveStringMap("backgrounds", backgrounds.value)
                toast("Фон для скіна «${s.title}» встановлено")
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                toast("Не вдалося встановити фон: ${e.message ?: e.javaClass.simpleName}")
            }
        }
    }

    /** Вибраний вбудований фон для кожного скіна (індекс; за межами списку — намальований фон). */
    val bgIndex = MutableStateFlow(
        storage.stringMap("bg_index").mapValues { it.value.toIntOrNull() ?: 0 },
    )

    fun nextBundledBackground(s: com.efir.iptv.ui.Skin) {
        val count = com.efir.iptv.ui.bundledBackgrounds(s).size
        if (count == 0) return
        val cur = bgIndex.value[s.name] ?: 0
        val next = (cur + 1) % (count + 1) // останній варіант — намальований фон без фото
        bgIndex.update { it + (s.name to next) }
        storage.saveStringMap("bg_index", bgIndex.value.mapValues { it.value.toString() })
    }

    fun clearCustomBackground(s: com.efir.iptv.ui.Skin) {
        backgrounds.value[s.name]?.let { File(it).delete() }
        backgrounds.update { it - s.name }
        storage.saveStringMap("backgrounds", backgrounds.value)
    }

    fun setSkin(s: com.efir.iptv.ui.Skin) {
        skin.value = s
        storage.skin = s.name
    }

    // ---------------- Перевірка потоків ----------------

    suspend fun checkStream(c: Channel) {
        if (!c.url.startsWith("http", ignoreCase = true)) return
        val now = System.currentTimeMillis()
        val last = checkedAt[c.key]
        if (last != null && now - last < STATUS_TTL) return
        checkedAt[c.key] = now
        if (streamStatus.value[c.key] == null) setStatus(c.key, StreamStatus.Checking)
        try {
            val candidates = orderSources(c)
            // Перевіряємо джерела в тому ж порядку, що й плеєр, до першого робочого
            val results = probeLimit.withPermit {
                withContext(Dispatchers.IO) {
                    val r = LinkedHashMap<String, Boolean>()
                    for (s in candidates) {
                        val works = Net.probe(s)
                        r[s.url] = works
                        if (works) break
                    }
                    r
                }
            }
            sourceOk.putAll(results)
            val ok = results.values.any { it }
            setStatus(c.key, if (ok) StreamStatus.Online else StreamStatus.Offline)
        } catch (e: CancellationException) {
            // Канал прокрутили з екрана до завершення перевірки — перевіримо пізніше
            checkedAt.remove(c.key)
            if (streamStatus.value[c.key] == StreamStatus.Checking) streamStatus.update { it - c.key }
            throw e
        }
    }

    private fun markStatus(key: String, st: StreamStatus) {
        checkedAt[key] = System.currentTimeMillis()
        setStatus(key, st)
    }

    private fun setStatus(key: String, st: StreamStatus) {
        streamStatus.update { it + (key to st) }
    }

    private fun clearStatuses() {
        checkedAt.clear()
        streamStatus.value = emptyMap()
    }

    // ---------------- Видалення каналів ----------------

    fun hideChannel(c: Channel) {
        val id = _state.value.selectedId ?: return
        hidden = hidden + c.key
        storage.saveHidden(id, hidden)
        recompute()
        toast("Канал «${c.name}» видалено. Повернути можна в розділі «Плейлисти».")
    }

    fun hideGroup(group: String) {
        val id = _state.value.selectedId ?: return
        val keys = _state.value.channels.filter { it.group == group }.map { it.key }
        hidden = hidden + keys
        storage.saveHidden(id, hidden)
        recompute()
        toast("Групу «$group» видалено (${keys.size} каналів).")
    }

    // ---------------- Переміщення між групами ----------------

    fun moveToGroup(c: Channel, group: String) {
        val id = _state.value.selectedId ?: return
        val g = group.trim()
        if (g.isEmpty()) return
        groupOverrides = groupOverrides + (c.key to g)
        storage.saveGroupOverrides(id, groupOverrides)
        recompute()
        toast("«${c.name}» переміщено в групу «$g»")
    }

    fun resetGroups() {
        val id = _state.value.selectedId ?: return
        groupOverrides = emptyMap()
        groupRenames = emptyMap()
        groupOrder = emptyList()
        storage.clearGroupOverrides(id)
        storage.remove("renames_$id")
        storage.remove("order_$id")
        recompute()
        toast("Групи повернуто до початкового вигляду")
    }

    private fun loadGroupSettings(id: String) {
        groupOverrides = storage.groupOverrides(id)
        groupRenames = storage.stringMap("renames_$id")
        groupOrder = storage.stringList("order_$id")
    }

    // ---------------- Вкладки: перейменування й порядок ----------------

    fun renameGroup(old: String, new: String) {
        val id = _state.value.selectedId ?: return
        val n = new.trim()
        if (n.isEmpty() || n == old) return
        if (n in SPECIAL_GROUPS) {
            toast("Ця назва зарезервована")
            return
        }
        val renames = groupRenames.mapValues { (_, v) -> if (v == old) n else v }.toMutableMap()
        renames[old] = n
        groupRenames = renames
        groupOverrides = groupOverrides.mapValues { (_, v) -> if (v == old) n else v }
        groupOrder = groupOrder.map { if (it == old) n else it }.distinct()
        storage.saveStringMap("renames_$id", groupRenames)
        storage.saveGroupOverrides(id, groupOverrides)
        storage.saveStringList("order_$id", groupOrder)
        if (selectedGroup.value == old) selectedGroup.value = n
        recompute()
    }

    /** Перетягування вкладки на нову позицію (0 — початок). */
    fun moveGroupTo(group: String, target: Int) {
        val id = _state.value.selectedId ?: return
        val list = _state.value.groups.toMutableList()
        if (!list.remove(group)) return
        list.add(target.coerceIn(0, list.size), group)
        groupOrder = list
        storage.saveStringList("order_$id", groupOrder)
        recompute()
    }

    /** Зміна назви й телепрограми вже доданого плейлиста. */
    fun updatePlaylist(id: String, name: String, epg: String) {
        val list = _state.value.playlists.map {
            if (it.id == id) it.copy(name = name.trim().ifBlank { it.name }, epgUrl = epg.trim()) else it
        }
        storage.savePlaylists(list)
        _state.update { it.copy(playlists = list) }
        storage.epgFile(id).delete()
        storage.epgFile(ALL_ID).delete()
        val sel = _state.value.selectedId
        if (sel == id || sel == ALL_ID) load(force = false)
        toast("Збережено. Телепрограма завантажується…")
    }

    fun moveGroup(group: String, delta: Int) {
        val id = _state.value.selectedId ?: return
        val list = _state.value.groups.toMutableList()
        val i = list.indexOf(group)
        val j = i + delta
        if (i < 0 || j !in list.indices) return
        list[i] = list[j]
        list[j] = group
        groupOrder = list
        storage.saveStringList("order_$id", groupOrder)
        recompute()
    }

    // ---------------- Масове видалення неактивних каналів ----------------

    fun cleanupInactive() {
        if (cleanupJob?.isActive == true) return
        val list = _state.value.channels.filter { it.url.startsWith("http", ignoreCase = true) }
        if (list.isEmpty()) return
        cleanupJob = viewModelScope.launch {
            cleanup.value = 0 to list.size
            try {
                val deadSrc = java.util.concurrent.ConcurrentHashMap.newKeySet<String>()
                coroutineScope {
                    list.map { c ->
                        async {
                            if (c.sources.size > 1) {
                                // Канал з кількома джерелами: перевіряємо кожне, неробочі прибираємо
                                val r = probeSources(c.sources)
                                sourceOk.putAll(r)
                                val alive = r.values.any { it }
                                markStatus(c.key, if (alive) StreamStatus.Online else StreamStatus.Offline)
                                if (alive) deadSrc.addAll(r.filterValues { !it }.keys)
                            } else {
                                checkStream(c)
                            }
                            cleanup.update { p -> p?.let { (it.first + 1) to it.second } }
                        }
                    }.awaitAll()
                }
                val st = streamStatus.value
                val dead = list.filter { st[it.key] == StreamStatus.Offline }
                val id = _state.value.selectedId
                if (dead.isNotEmpty() && id != null) {
                    hidden = hidden + dead.map { it.key }
                    storage.saveHidden(id, hidden)
                }
                addDeadSources(deadSrc)
                recompute()
                toast(
                    "Видалено неактивних каналів: ${dead.size}, непрацюючих джерел: ${deadSrc.size}. " +
                        "Повернути: Плейлисти → «Повернути видалені».",
                )
            } finally {
                cleanup.value = null
            }
        }
    }

    // ---------------- Чистка непрацюючих джерел ----------------

    /** Канал без прибраних джерел. Якщо не працює жодне — канал лишається як є (його прибере чистка каналів). */
    private fun stripDead(c: Channel): Channel {
        if (c.sources.isEmpty() || deadSources.isEmpty()) return c
        val alive = c.sources.filter { it.url !in deadSources }
        if (alive.size == c.sources.size || alive.isEmpty()) return c
        val first = alive.first()
        return c.copy(url = first.url, headers = first.headers, sources = if (alive.size > 1) alive else emptyList())
    }

    private suspend fun probeSources(list: List<Channel>): Map<String, Boolean> = coroutineScope {
        list.map { s ->
            async { s.url to probeLimit.withPermit { withContext(Dispatchers.IO) { Net.probe(s) } } }
        }.awaitAll().toMap()
    }

    private fun addDeadSources(urls: Collection<String>) {
        if (urls.isEmpty()) return
        deadSources = deadSources + urls
        storage.saveStringList("dead_sources", deadSources.toList())
        deadSourceCount.value = deadSources.size
        val pref = preferredSource.filterValues { it !in deadSources }
        if (pref.size != preferredSource.size) {
            preferredSource = pref
            storage.saveStringMap("pref_sources", preferredSource)
        }
    }

    /** Перевіряє всі джерела поточного каналу й прибирає ті, що не відповідають. */
    fun cleanupSources() {
        val c = current.value ?: return
        if (c.sources.size < 2 || sourceCleanupRunning.value) return
        val playing = playOrder.getOrNull(sourceIndex)
        val playingOk = archive.value == null && player.playbackState == Player.STATE_READY
        viewModelScope.launch {
            sourceCleanupRunning.value = true
            try {
                val toCheck = c.sources.filter { !(playingOk && it.url == playing?.url) }
                val r = probeSources(toCheck) + (if (playingOk && playing != null) mapOf(playing.url to true) else emptyMap())
                sourceOk.putAll(r)
                val dead = r.filterValues { !it }.keys
                when {
                    dead.isEmpty() -> toast("Усі джерела працюють")
                    dead.size == c.sources.size -> toast("Жодне джерело не відповідає — можливо, немає інтернету. Нічого не прибрано.")
                    else -> {
                        addDeadSources(dead)
                        recompute()
                        val updated = stripDead(c)
                        queue.update { q -> q.map { if (it.key == c.key) updated else it } }
                        current.value = updated
                        playOrder = orderSources(updated)
                        val idx = playOrder.indexOfFirst { it.url == playing?.url }
                        if (idx < 0) {
                            sourceIndex = 0
                            triedHls = false
                            retries = 0
                            startStream(updated, hls = false)
                        } else {
                            sourceIndex = idx
                            val src = playOrder[idx]
                            sourceInfo.value = if (playOrder.size > 1) {
                                "Джерело ${idx + 1} з ${playOrder.size}" + qualityLabel(src)?.let { " · $it" }.orEmpty()
                            } else {
                                null
                            }
                            updateSourceChoices(updated)
                        }
                        toast("Прибрано непрацюючих джерел: ${dead.size}")
                    }
                }
                if (dead.isEmpty() || dead.size == c.sources.size) updateSourceChoices(c)
            } finally {
                sourceCleanupRunning.value = false
            }
        }
    }

    /** Повертає всі джерела, прибрані чисткою. */
    fun restoreSources() {
        deadSources = emptySet()
        storage.remove("dead_sources")
        deadSourceCount.value = 0
        recompute()
        toast("Прибрані джерела повернуто")
    }

    fun cancelCleanup() {
        cleanupJob?.cancel()
    }

    // ---------------- Доступність плейлистів ----------------

    fun checkPlaylists() {
        for (p in _state.value.playlists) {
            viewModelScope.launch {
                val ok = withContext(Dispatchers.IO) { Net.probePlaylist(ctx, p.url) }
                playlistStatus.update { it + (p.id to ok) }
            }
        }
    }

    fun restoreHidden() {
        val id = _state.value.selectedId ?: return
        hidden = emptySet()
        storage.clearHidden(id)
        recompute()
        toast("Видалені канали повернуто")
    }

    // ---------------- Збереження плейлиста у файл ----------------

    fun suggestedFileName(): String {
        val name = currentSource()?.name ?: if (_state.value.selectedId == ALL_ID) ALL_NAME else "playlist"
        return name.replace(Regex("[\\\\/:*?\"<>|]"), "_").trim().ifBlank { "playlist" } + ".m3u"
    }

    private fun buildM3u(): String {
        fun q(v: String) = v.replace('"', '\'')
        val sb = StringBuilder()
        val epg = currentSource()?.epgUrl?.takeIf { it.isNotBlank() } ?: playlistEpg
        sb.append("#EXTM3U")
        if (epg.isNotBlank()) sb.append(" url-tvg=\"").append(q(epg)).append('"')
        sb.append('\n')
        for (c in _state.value.channels) {
            sb.append("#EXTINF:-1")
            if (c.tvgId.isNotBlank()) sb.append(" tvg-id=\"").append(q(c.tvgId)).append('"')
            if (c.tvgName.isNotBlank()) sb.append(" tvg-name=\"").append(q(c.tvgName)).append('"')
            if (c.logo.isNotBlank()) sb.append(" tvg-logo=\"").append(q(c.logo)).append('"')
            if (c.group != M3uParser.NO_GROUP) sb.append(" group-title=\"").append(q(c.group)).append('"')
            sb.append(',').append(c.name).append('\n')
            c.headers["User-Agent"]?.let { sb.append("#EXTVLCOPT:http-user-agent=").append(it).append('\n') }
            c.headers["Referer"]?.let { sb.append("#EXTVLCOPT:http-referrer=").append(it).append('\n') }
            sb.append(c.url).append('\n')
        }
        return sb.toString()
    }

    fun exportToUri(uri: Uri) {
        val text = buildM3u()
        viewModelScope.launch {
            try {
                withContext(Dispatchers.IO) {
                    val out = ctx.contentResolver.openOutputStream(uri, "wt")
                        ?: throw IOException("не вдалося відкрити файл")
                    out.use { it.write(text.toByteArray(Charsets.UTF_8)) }
                }
                toast("Плейлист збережено (${_state.value.channels.size} каналів)")
            } catch (e: Exception) {
                toast("Не вдалося зберегти: ${e.message ?: e.javaClass.simpleName}")
            }
        }
    }

    fun exportToDir(dir: File) {
        val text = buildM3u()
        viewModelScope.launch {
            try {
                val f = withContext(Dispatchers.IO) {
                    val base = suggestedFileName().removeSuffix(".m3u")
                    var file = File(dir, "$base.m3u")
                    var n = 2
                    while (file.exists()) file = File(dir, "$base ($n).m3u").also { n++ }
                    file.writeText(text, Charsets.UTF_8)
                    file
                }
                toast("Збережено: ${f.absolutePath}")
            } catch (e: Exception) {
                toast("Не вдалося зберегти: ${e.message ?: e.javaClass.simpleName}")
            }
        }
    }

    private fun toast(msg: String) {
        Toast.makeText(ctx, msg, Toast.LENGTH_LONG).show()
    }

    private fun loadEpg(src: PlaylistSource, p: ParsedPlaylist, force: Boolean) {
        val url = src.epgUrl.ifBlank { p.epgUrl }
        epgJob?.cancel()
        if (url.isBlank()) {
            _state.update { it.copy(epg = emptyMap(), epgLoading = false) }
            return
        }
        epgJob = viewModelScope.launch {
            _state.update { it.copy(epgLoading = true) }
            try {
                val f = storage.epgFile(src.id)
                val map = withContext(Dispatchers.IO) {
                    val stale = !f.exists() || System.currentTimeMillis() - f.lastModified() > 12 * HOUR
                    if (force || stale) {
                        try {
                            Net.download(ctx, url, f)
                        } catch (e: Exception) {
                            if (!f.exists()) throw e
                        }
                    }
                    Net.maybeGunzip(BufferedInputStream(FileInputStream(f), 65536)).use {
                        EpgParser.parse(it, p.channels)
                    }
                }
                _state.update { it.copy(epg = map) }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                // Телепрограма необовʼязкова — просто працюємо без неї
            } finally {
                _state.update { it.copy(epgLoading = false) }
            }
        }
    }

    /** Текст плейлиста: звичайне посилання/файл або Xtream Codes. */
    private fun downloadPlaylist(src: PlaylistSource): String {
        val acc = Xtream.decode(src.url)
        return if (acc != null) Xtream.loadAsM3u(ctx, acc) else Net.readText(ctx, src.url)
    }

    fun addXtream(name: String, server: String, user: String, pass: String) {
        if (server.isBlank() || user.isBlank()) {
            toast("Вкажіть сервер і логін")
            return
        }
        addPlaylist(name.ifBlank { "Xtream" }, Xtream.encode(server, user, pass), "")
    }

    // ---------------- Резервна копія налаштувань ----------------

    fun backupFileName(): String =
        "efir-backup-" + java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US).format(java.util.Date()) + ".json"

    /** Усе в одному файлі: налаштування, власні фони, вміст плейлистів із файлів. */
    private fun buildBackup(): String {
        val root = org.json.JSONObject()
            .put("app", "efir")
            .put("format", 1)
            .put("created", System.currentTimeMillis())
            .put("prefs", storage.exportPrefs())
        val bgs = org.json.JSONObject()
        for ((skinName, path) in backgrounds.value) {
            val f = File(path)
            if (f.exists()) bgs.put(skinName, android.util.Base64.encodeToString(f.readBytes(), android.util.Base64.NO_WRAP))
        }
        root.put("backgrounds", bgs)
        // Плейлисти з файлів: на іншому пристрої файлу може не бути — зберігаємо вміст
        val local = org.json.JSONObject()
        for (p in _state.value.playlists) {
            if (p.url.startsWith("http", ignoreCase = true) || Xtream.isXtream(p.url)) continue
            val f = storage.playlistFile(p.id)
            val text = if (f.exists()) {
                f.readText()
            } else {
                try {
                    Net.readText(ctx, p.url)
                } catch (e: Exception) {
                    null
                }
            }
            if (text != null) local.put(p.id, text)
        }
        root.put("playlists", local)
        return root.toString()
    }

    private fun backupSummary() =
        "плейлистів: ${_state.value.playlists.size}, обраних: ${_state.value.favorites.size}"

    fun backupToUri(uri: Uri) {
        viewModelScope.launch {
            try {
                withContext(Dispatchers.IO) {
                    val text = buildBackup()
                    val out = ctx.contentResolver.openOutputStream(uri, "wt") ?: throw IOException("не вдалося відкрити файл")
                    out.use { it.write(text.toByteArray(Charsets.UTF_8)) }
                }
                toast("Резервну копію збережено (${backupSummary()})")
            } catch (e: Exception) {
                toast("Не вдалося зберегти копію: ${e.message ?: e.javaClass.simpleName}")
            }
        }
    }

    fun backupToDir(dir: File) {
        viewModelScope.launch {
            try {
                val f = withContext(Dispatchers.IO) {
                    val base = backupFileName().removeSuffix(".json")
                    var file = File(dir, "$base.json")
                    var n = 2
                    while (file.exists()) file = File(dir, "$base ($n).json").also { n++ }
                    file.writeText(buildBackup(), Charsets.UTF_8)
                    file
                }
                toast("Резервну копію збережено: ${f.absolutePath}")
            } catch (e: Exception) {
                toast("Не вдалося зберегти копію: ${e.message ?: e.javaClass.simpleName}")
            }
        }
    }

    /** Відновлення: замінює всі поточні налаштування тими, що в копії. */
    fun restoreBackup(open: () -> java.io.InputStream?) {
        viewModelScope.launch {
            try {
                withContext(Dispatchers.IO) {
                    val text = open()?.use { it.readBytes().toString(Charsets.UTF_8) } ?: throw IOException("не вдалося відкрити файл")
                    val root = try {
                        org.json.JSONObject(text)
                    } catch (e: Exception) {
                        throw IOException("файл пошкоджений або це не копія Ефіру")
                    }
                    if (root.optString("app") != "efir") throw IOException("це не резервна копія Ефіру")
                    val prefsObj = root.optJSONObject("prefs") ?: throw IOException("у копії немає налаштувань")
                    // Власні фони
                    val bgDir = File(ctx.filesDir, "backgrounds").apply { mkdirs() }
                    bgDir.listFiles()?.forEach { it.delete() }
                    val bgMap = org.json.JSONObject()
                    root.optJSONObject("backgrounds")?.let { b ->
                        for (k in b.keys()) {
                            val f = File(bgDir, "${k}_${System.currentTimeMillis()}.jpg")
                            f.writeBytes(android.util.Base64.decode(b.getString(k), android.util.Base64.DEFAULT))
                            bgMap.put(k, f.absolutePath)
                        }
                    }
                    prefsObj.put("backgrounds", org.json.JSONObject().put("t", "s").put("v", bgMap.toString()))
                    // Кеш плейлистів і телепрограми — старий прибираємо, файлові плейлисти відновлюємо
                    storage.playlistFile("x").parentFile?.listFiles()?.forEach { it.delete() }
                    root.optJSONObject("playlists")?.let { pl ->
                        for (id in pl.keys()) storage.playlistFile(id).writeText(pl.getString(id), Charsets.UTF_8)
                    }
                    storage.importPrefs(prefsObj)
                }
                reloadFromStorage()
                toast("Налаштування відновлено (${backupSummary()})")
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                toast("Не вдалося відновити: ${e.message ?: e.javaClass.simpleName}")
            }
        }
    }

    /** Перечитує все зі сховища після відновлення копії. */
    private fun reloadFromStorage() {
        loadJob?.cancel()
        epgJob?.cancel()
        stopPlayer()
        queue.value = emptyList()
        sourceOk.clear()
        clearStatuses()
        preferredSource = storage.stringMap("pref_sources")
        deadSources = storage.stringList("dead_sources").toSet()
        deadSourceCount.value = deadSources.size
        adultUnlocked.value = false
        loadParental()
        viewMode.value = storage.getString("view_mode")?.toIntOrNull() ?: 0
        skin.value = try {
            com.efir.iptv.ui.Skin.valueOf(storage.skin)
        } catch (e: Exception) {
            com.efir.iptv.ui.Skin.CLASSIC
        }
        backgrounds.value = storage.stringMap("backgrounds").filterValues { File(it).exists() }
        bgIndex.value = storage.stringMap("bg_index").mapValues { it.value.toIntOrNull() ?: 0 }
        val list = storage.loadPlaylists()
        val sel = storage.selectedId?.takeIf { id -> (id == ALL_ID && list.size > 1) || list.any { it.id == id } }
            ?: list.firstOrNull()?.id
        _state.value = State(playlists = list, favorites = storage.favorites(), recents = storage.recents())
        playlistStatus.value = emptyMap()
        checkPlaylists()
        autostartPending = false
        if (sel == null) {
            hidden = emptySet()
            screen.value = Screen.Playlists
        } else {
            selectPlaylist(sel)
        }
    }

    // ---------------- Сітка телепрограми ----------------

    private var guideFrom = Screen.Home

    fun openGuide() {
        if (screen.value != Screen.Guide) guideFrom = screen.value
        screen.value = Screen.Guide
    }

    fun closeGuide() {
        screen.value = if (guideFrom == Screen.Player && current.value != null) Screen.Player else Screen.Home
    }

    fun addPlaylist(name: String, url: String, epg: String) {
        if (_state.value.playlists.size >= MAX_PLAYLISTS) {
            toast("Можна зберегти до $MAX_PLAYLISTS плейлистів. Видаліть непотрібний, щоб додати новий.")
            return
        }
        val src = PlaylistSource(
            id = UUID.randomUUID().toString(),
            name = name.trim().ifBlank { "Плейлист" },
            url = url.trim(),
            epgUrl = epg.trim(),
        )
        val list = _state.value.playlists + src
        storage.savePlaylists(list)
        _state.update { it.copy(playlists = list) }
        checkPlaylists()
        selectPlaylist(src.id)
    }

    /** Групове додавання: кожен файл — окремий плейлист з назвою файлу. */
    fun addPlaylists(items: List<Pair<String, String>>) {
        val existing = _state.value.playlists
        val existingUrls = existing.map { it.url }.toSet()
        val fresh = items.filter { it.second !in existingUrls }.distinctBy { it.second }
        val free = (MAX_PLAYLISTS - existing.size).coerceAtLeast(0)
        val toAdd = fresh.take(free).map { (name, url) ->
            PlaylistSource(UUID.randomUUID().toString(), name.ifBlank { "Плейлист" }, url, "")
        }
        val dup = items.size - fresh.size
        val overLimit = fresh.size - toAdd.size
        if (toAdd.isNotEmpty()) {
            val list = existing + toAdd
            storage.savePlaylists(list)
            _state.update { it.copy(playlists = list) }
            checkPlaylists()
        }
        toast(
            buildString {
                append("Додано плейлистів: ${toAdd.size}")
                if (dup > 0) append(" · вже були: $dup")
                if (overLimit > 0) append(" · не вмістилось (ліміт $MAX_PLAYLISTS): $overLimit")
            },
        )
        when {
            toAdd.isEmpty() -> {}
            _state.value.selectedId == null || toAdd.size == 1 -> selectPlaylist(toAdd.first().id)
            _state.value.selectedId == ALL_ID -> load(force = false)
        }
    }

    fun selectPlaylist(id: String) {
        restoreGroupPending = true
        clearStatuses()
        storage.selectedId = id
        hidden = storage.hidden(id)
        loadGroupSettings(id)
        allChannels = emptyList()
        _state.update {
            it.copy(
                selectedId = id,
                channels = emptyList(),
                groups = emptyList(),
                epg = emptyMap(),
                error = null,
                hiddenCount = 0,
                movedCount = 0,
            )
        }
        selectedGroup.value = GROUP_ALL
        query.value = ""
        screen.value = Screen.Home
        load(force = false)
    }

    fun refreshPlaylist(id: String) {
        if (_state.value.selectedId != id) {
            storage.playlistFile(id).delete()
            storage.epgFile(id).delete()
            selectPlaylist(id)
        } else {
            screen.value = Screen.Home
            load(force = true)
        }
    }

    fun deletePlaylist(id: String) {
        val list = _state.value.playlists.filter { it.id != id }
        storage.savePlaylists(list)
        storage.playlistFile(id).delete()
        storage.epgFile(id).delete()
        storage.clearHidden(id)
        storage.clearGroupOverrides(id)
        storage.remove("renames_$id")
        storage.remove("order_$id")
        playlistStatus.update { it - id }
        _state.update { it.copy(playlists = list) }
        val sel = _state.value.selectedId
        if (sel == ALL_ID && list.size > 1) {
            load(force = false)
            return
        }
        if (sel == id || sel == ALL_ID) {
            val next = list.firstOrNull()
            if (next != null) {
                selectPlaylist(next.id)
                screen.value = Screen.Playlists
            } else {
                loadJob?.cancel()
                epgJob?.cancel()
                storage.selectedId = null
                allChannels = emptyList()
                hidden = emptySet()
                groupOverrides = emptyMap()
                groupRenames = emptyMap()
                groupOrder = emptyList()
                _state.update {
                    it.copy(selectedId = null, channels = emptyList(), groups = emptyList(), epg = emptyMap())
                }
            }
        }
    }

    // ---------------- Обране / недавні ----------------

    fun toggleFavorite(c: Channel) {
        val f = _state.value.favorites.toMutableSet()
        if (!f.add(c.key)) f.remove(c.key)
        storage.saveFavorites(f)
        _state.update { it.copy(favorites = f) }
    }

    private fun addRecent(c: Channel) {
        val r = (listOf(c.key) + _state.value.recents.filter { it != c.key }).take(30)
        storage.saveRecents(r)
        _state.update { it.copy(recents = r) }
    }

    // ---------------- Відтворення ----------------

    fun play(c: Channel, list: List<Channel>) {
        queue.value = list.ifEmpty { listOf(c) }
        screen.value = Screen.Player
        start(c)
    }

    fun start(c: Channel) {
        archive.value = null
        paused.value = false
        pausedAt = 0
        sourceIndex = 0
        playOrder = orderSources(c)
        triedHls = false
        retries = 0
        addRecent(c)
        _state.value.selectedId?.let { storage.putString("last_ch_$it", c.key) }
        lastChannelKey.value = c.key
        startStream(c, hls = false)
    }

    private fun startStream(c: Channel, hls: Boolean) {
        retryJob?.cancel()
        current.value = c
        playback.value = Playback(buffering = true)
        if (playOrder.isEmpty() || playOrder.none { it.url == c.url || it in c.sources }) playOrder = orderSources(c)
        val arch = archive.value
        val src = if (arch != null) archiveSrc ?: c else playOrder.getOrNull(sourceIndex) ?: c
        val streamUrl = if (arch != null) archiveUrl else src.url
        val multi = playOrder.size > 1
        sourceInfo.value = if (multi) {
            "Джерело ${sourceIndex + 1} з ${playOrder.size}" + qualityLabel(src)?.let { " · $it" }.orEmpty()
        } else {
            null
        }

        updateSourceChoices(c)
        streamInfo.value = null

        val headers = HashMap(src.headers)
        val ua = headers.remove("User-Agent") ?: Net.USER_AGENT
        val http = DefaultHttpDataSource.Factory()
            .setUserAgent(ua)
            .setAllowCrossProtocolRedirects(true)
            // Є резерв — швидше визнаємо джерело неробочим і перемикаємось без довгих пауз
            .setConnectTimeoutMs(if (multi) 7_000 else 15_000)
            .setReadTimeoutMs(if (multi) 10_000 else 20_000)
            .setDefaultRequestProperties(headers)
        val dataSource = DefaultDataSource.Factory(ctx, http)

        val isHls = hls || looksHls(streamUrl)
        val item = MediaItem.Builder().setUri(streamUrl)
        if (isHls) item.setMimeType(MimeTypes.APPLICATION_M3U8)
        val mediaItem = item.build()

        val source = if (isHls) {
            HlsMediaSource.Factory(dataSource)
                .setExtractorFactory(DefaultHlsExtractorFactory(TS_FLAGS, true))
                .createMediaSource(mediaItem)
        } else {
            DefaultMediaSourceFactory(dataSource, extractors).createMediaSource(mediaItem)
        }
        // Новий канал — скидаємо ручний вибір звукової доріжки
        player.trackSelectionParameters = player.trackSelectionParameters.buildUpon()
            .clearOverridesOfType(C.TRACK_TYPE_AUDIO)
            .build()
        audioTracks.value = emptyList()
        player.setMediaSource(source)
        player.prepare()
        player.play()
    }

    private fun updateAudioTracks(tracks: Tracks) {
        val groups = tracks.groups.filter { it.type == C.TRACK_TYPE_AUDIO }
        audioGroups = groups
        val list = ArrayList<AudioTrack>()
        groups.forEachIndexed { gi, g ->
            for (ti in 0 until g.length) {
                list += AudioTrack(
                    group = gi,
                    index = ti,
                    label = describeAudio(g.getTrackFormat(ti), list.size + 1),
                    selected = g.isTrackSelected(ti),
                    supported = g.isTrackSupported(ti),
                )
            }
        }
        audioTracks.value = list
    }

    private fun updateStreamInfo() {
        val vf = player.videoFormat
        val vs = player.videoSize
        val w = if (vs.width > 0) vs.width else vf?.width ?: 0
        val h = if (vs.height > 0) vs.height else vf?.height ?: 0
        val video = ArrayList<String>()
        if (w > 0 && h > 0) {
            val label = when {
                h >= 2000 -> "4K"
                h >= 1000 -> "FHD"
                h >= 700 -> "HD"
                else -> "SD"
            }
            video += "$w×$h ($label)"
        }
        vf?.sampleMimeType?.let { m ->
            video += when (m) {
                MimeTypes.VIDEO_H264 -> "H.264"
                MimeTypes.VIDEO_H265 -> "H.265"
                MimeTypes.VIDEO_MPEG2 -> "MPEG-2"
                MimeTypes.VIDEO_AV1 -> "AV1"
                MimeTypes.VIDEO_VP9 -> "VP9"
                else -> m.substringAfter('/').uppercase()
            }
        }
        val fps = vf?.frameRate ?: -1f
        if (fps > 0f) video += "${kotlin.math.round(fps).toInt()} к/с"
        val audio = audioTracks.value.firstOrNull { it.selected }?.label
            ?: player.audioFormat?.let { describeAudio(it, 1) }
        val text = buildString {
            if (video.isNotEmpty()) append("Відео: ").append(video.joinToString(" · "))
            if (audio != null) {
                if (isNotEmpty()) append("     ")
                append("Звук: ").append(audio)
            }
        }
        streamInfo.value = text.ifBlank { null }
    }

    fun selectAudio(t: AudioTrack) {
        val g = audioGroups.getOrNull(t.group) ?: return
        player.trackSelectionParameters = player.trackSelectionParameters.buildUpon()
            .setOverrideForType(TrackSelectionOverride(g.mediaTrackGroup, t.index))
            .build()
    }

    private fun describeAudio(f: Format, n: Int): String {
        val lang = f.language
            ?.takeIf { it.isNotBlank() && it != "und" }
            ?.let { code ->
                Locale.forLanguageTag(code).getDisplayLanguage(Locale.forLanguageTag("uk"))
                    .ifBlank { code }
                    .replaceFirstChar { it.uppercase() }
            }
        val label = f.label?.takeIf { it.isNotBlank() }
        val parts = ArrayList<String>()
        parts += label ?: lang ?: "Доріжка $n"
        if (label != null && lang != null) parts += lang
        val codec = when (f.sampleMimeType) {
            MimeTypes.AUDIO_AAC -> "AAC"
            MimeTypes.AUDIO_AC3 -> "AC3 (Dolby)"
            MimeTypes.AUDIO_E_AC3, MimeTypes.AUDIO_E_AC3_JOC -> "E-AC3 (Dolby)"
            MimeTypes.AUDIO_MPEG, MimeTypes.AUDIO_MPEG_L2 -> "MPEG"
            MimeTypes.AUDIO_DTS -> "DTS"
            MimeTypes.AUDIO_OPUS -> "Opus"
            null -> null
            else -> f.sampleMimeType?.substringAfter('/')?.uppercase()
        }
        if (codec != null) parts += codec
        when (f.channelCount) {
            Format.NO_VALUE, 0 -> {}
            1 -> parts += "моно"
            2 -> parts += "стерео"
            6 -> parts += "5.1"
            8 -> parts += "7.1"
            else -> parts += "${f.channelCount} кан."
        }
        return parts.joinToString(" · ")
    }

    // ---------------- Ручне перемикання джерел ----------------

    private fun updateSourceChoices(c: Channel) {
        if (playOrder.size < 2) {
            sourceChoices.value = emptyList()
            return
        }
        val pref = preferredSource[c.key]
        sourceChoices.value = playOrder.mapIndexed { i, s ->
            val host = try {
                Uri.parse(s.url).host.orEmpty()
            } catch (e: Exception) {
                ""
            }
            SourceChoice(
                index = i,
                title = "Джерело ${i + 1}" + qualityLabel(s)?.let { " · $it" }.orEmpty(),
                subtitle = listOf(s.name, host).filter { it.isNotBlank() }.joinToString(" · "),
                current = i == sourceIndex,
                ok = sourceOk[s.url],
                preferred = s.url == pref,
            )
        }
    }

    /** Ручний вибір джерела — запам'ятовується як типове для цього каналу. */
    fun selectSource(index: Int) {
        val c = current.value ?: return
        val s = playOrder.getOrNull(index) ?: return
        preferredSource = preferredSource + (c.key to s.url)
        storage.saveStringMap("pref_sources", preferredSource)
        sourceIndex = index
        triedHls = false
        retries = 0
        startStream(c, hls = false)
        toast("Джерело ${index + 1} тепер типове для «${c.name}»")
    }

    fun resetPreferredSource() {
        val c = current.value ?: return
        preferredSource = preferredSource - c.key
        storage.saveStringMap("pref_sources", preferredSource)
        updateSourceChoices(c)
        toast("Для «${c.name}» знову автовибір джерела")
    }

    /** 4 — 4K, 3 — FHD, 2 — HD, 1 — SD, -1 — невідомо (з назви або посилання). */
    private fun qualityOf(c: Channel): Int {
        val t = (c.name + " " + c.url).lowercase()
        return when {
            Q4K.containsMatchIn(t) -> 4
            QFHD.containsMatchIn(t) -> 3
            QHD.containsMatchIn(t) -> 2
            QSD.containsMatchIn(t) -> 1
            else -> -1
        }
    }

    private fun qualityLabel(c: Channel): String? = when (qualityOf(c)) {
        4 -> "4K"
        3 -> "FHD"
        2 -> "HD"
        1 -> "SD"
        else -> null
    }

    private fun orderSources(c: Channel): List<Channel> {
        val list = c.sources.ifEmpty { listOf(c) }
        if (list.size == 1) return list
        return list.withIndex().sortedWith(
            compareBy<IndexedValue<Channel>>(
                { if (sourceOk[it.value.url] == false) 1 else 0 }, // відомі неробочі — в самий кінець
                { q -> -(qualityOf(q.value).let { if (it < 0) 2 else it }) }, // найкраща якість першою (невідома ≈ HD)
                { if (sourceOk[it.value.url] == true) 0 else 1 }, // серед однакової якості — перевірені робочі
                { it.index }, // далі — порядок плейлистів
            ),
        ).map { it.value }.let { sorted ->
            // Джерело, вибране користувачем вручну, завжди першим
            val pref = preferredSource[c.key] ?: return@let sorted
            val chosen = sorted.firstOrNull { it.url == pref } ?: return@let sorted
            listOf(chosen) + sorted.filter { it !== chosen }
        }
    }

    private fun looksHls(url: String): Boolean {
        val u = url.lowercase().substringBefore('?')
        return u.endsWith(".m3u8") || u.endsWith(".m3u") || url.lowercase().contains("m3u8")
    }

    private fun handleError(e: PlaybackException) {
        val c = current.value ?: return
        if (screen.value != Screen.Player) return
        if (e.errorCode == PlaybackException.ERROR_CODE_BEHIND_LIVE_WINDOW) {
            player.seekToDefaultPosition()
            player.prepare()
            return
        }
        if (archive.value != null) {
            if (!triedHls && !looksHls(archiveUrl) && e.errorCode in 3000..3999) {
                triedHls = true
                startStream(c, hls = true)
                return
            }
            playback.value = Playback(buffering = false, error = "Архів цієї передачі недоступний (${describe(e)})")
            return
        }
        val src = playOrder.getOrNull(sourceIndex) ?: c
        // Невідомий формат — пробуємо як HLS (часто посилання без розширення .m3u8)
        if (!triedHls && !looksHls(src.url) && e.errorCode in 3000..3999) {
            triedHls = true
            startStream(c, hls = true)
            return
        }
        // Є наступне джерело — перемикаємося одразу, без пауз і повторів
        if (sourceIndex < playOrder.size - 1) {
            sourceOk[src.url] = false
            sourceIndex++
            triedHls = false
            retries = 0
            startStream(c, hls = false)
            return
        }
        // Останнє (або єдине) джерело — кілька повторів з паузою
        val maxRetries = if (playOrder.size > 1) 1 else 3
        if (retries < maxRetries) {
            retries++
            scheduleRestart(1500L * retries)
            return
        }
        sourceOk[src.url] = false
        markStatus(c.key, StreamStatus.Offline)
        updateSourceChoices(c)
        playback.value = Playback(buffering = false, error = describe(e))
    }

    private fun scheduleRestart(delayMs: Long) {
        val c = current.value ?: return
        if (screen.value != Screen.Player) return
        retryJob?.cancel()
        retryJob = viewModelScope.launch {
            delay(delayMs)
            if (current.value?.key == c.key && screen.value == Screen.Player) startStream(c, triedHls)
        }
    }

    private fun describe(e: PlaybackException): String = when (e.errorCode) {
        PlaybackException.ERROR_CODE_IO_BAD_HTTP_STATUS ->
            "Сервер відхилив запит (канал недоступний або потрібна авторизація)"
        PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_FAILED,
        PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_TIMEOUT ->
            "Немає зʼєднання з сервером каналу"
        in 3000..3999 -> "Невідомий формат потоку"
        in 4000..4999 -> "Пристрій не може декодувати це відео"
        else -> "Помилка відтворення (${e.errorCodeName})"
    }

    fun step(delta: Int) {
        val c = current.value ?: return
        val q = queue.value
        if (q.isEmpty()) return
        val i = q.indexOfFirst { it.key == c.key }.coerceAtLeast(0)
        val n = ((i + delta) % q.size + q.size) % q.size
        start(q[n])
    }

    /** Список каналів у плеєрі: перемкнути на іншу групу (поточний канал грає далі). */
    fun switchQueueGroup(g: String) {
        if (g == LOCKED_GROUP) {
            toast("Канали 18+ відкриваються на головному екрані після введення PIN")
            return
        }
        chooseGroup(g)
        query.value = ""
        val list = filter(_state.value, g, "")
        if (list.isNotEmpty()) queue.value = list
    }

    /** Після видалення/переміщення оновлюємо список у плеєрі. */
    fun refreshQueue() {
        val list = filter(_state.value, selectedGroup.value, query.value)
        queue.value = list.ifEmpty { listOfNotNull(current.value) }
    }

    fun retry() {
        current.value?.let { start(it) }
    }

    // ---------------- Пауза ефіру й архів ----------------

    data class ArchiveState(val title: String, val start: Long, val end: Long)

    /** Не null — зараз грає запис з архіву. */
    val archive = MutableStateFlow<ArchiveState?>(null)
    val paused = MutableStateFlow(false)
    private var pausedAt = 0L
    private var archiveUrl = ""
    private var archiveSrc: Channel? = null

    /** Перегляд передачі з архіву (catch-up). */
    fun playArchive(c: Channel, from: Long, end: Long, title: String) {
        val src = Catchup.archiveSource(c)
        if (src == null) {
            toast("У каналу «${c.name}» немає архіву")
            return
        }
        val now = System.currentTimeMillis()
        if (from >= now - 30_000) {
            screen.value = Screen.Player
            start(c)
            return
        }
        if (queue.value.none { it.key == c.key }) {
            queue.value = filter(_state.value, selectedGroup.value, "").ifEmpty { listOf(c) }
        }
        archiveSrc = src
        archiveUrl = Catchup.buildUrl(src, from, end, now)
        archive.value = ArchiveState(title, from, end)
        paused.value = false
        pausedAt = 0
        triedHls = false
        retries = 0
        screen.value = Screen.Player
        startStream(c, hls = false)
    }

    /**
     * Пауза ефіру. Коротка пауза — продовжуємо з буфера; довга — з моменту паузи
     * через архів (якщо він є), інакше повертаємось у прямий ефір.
     */
    fun togglePause() {
        if (player.isPlaying) {
            player.pause()
            paused.value = true
            if (archive.value == null) pausedAt = System.currentTimeMillis()
            return
        }
        paused.value = false
        val c = current.value ?: return
        val pauseLen = if (pausedAt > 0) System.currentTimeMillis() - pausedAt else 0
        if (archive.value == null && pauseLen > 20_000) {
            val t = pausedAt
            pausedAt = 0
            if (Catchup.archiveSource(c) != null) {
                playArchive(c, t, t + 6 * HOUR, "Відкладений перегляд")
            } else {
                if (player.playbackState == Player.STATE_IDLE) player.prepare()
                player.seekToDefaultPosition()
                player.play()
                toast("У каналу немає архіву — продовжую з прямого ефіру")
            }
            return
        }
        pausedAt = 0
        if (player.playbackState == Player.STATE_IDLE) player.prepare()
        player.play()
    }

    /** Перемотка: в архіві — на ±N секунд, у прямому ефірі — назад через архів. */
    fun seekBy(deltaMs: Long) {
        val c = current.value ?: return
        val a = archive.value
        val now = System.currentTimeMillis()
        if (a == null) {
            if (deltaMs < 0 && Catchup.archiveSource(c) != null) {
                val t = now + deltaMs - 60_000
                playArchive(c, t, t + 6 * HOUR, "Відкладений перегляд")
            }
            return
        }
        if (player.isCurrentMediaItemSeekable && player.duration > 0) {
            player.seekTo((player.currentPosition + deltaMs).coerceIn(0, player.duration))
            return
        }
        val pos = a.start + player.currentPosition + deltaMs
        if (pos >= now - 60_000) goLive() else playArchive(c, pos.coerceAtLeast(a.start - 6 * HOUR), a.end, a.title)
    }

    fun goLive() {
        val c = current.value ?: return
        archive.value = null
        start(c)
    }

    fun stopPlayer() {
        retryJob?.cancel()
        player.stop()
        player.clearMediaItems()
        current.value = null
        sourceInfo.value = null
        sourceChoices.value = emptyList()
        streamInfo.value = null
        archive.value = null
        paused.value = false
        pausedAt = 0
        playback.value = Playback()
        screen.value = Screen.Home
    }

    fun onForeground() {
        if (screen.value == Screen.Player && current.value != null) {
            if (player.playbackState == Player.STATE_IDLE) player.prepare()
            player.seekToDefaultPosition()
            player.play()
        }
    }

    fun onBackground() {
        player.pause()
    }

    override fun onCleared() {
        player.release()
        super.onCleared()
    }

    companion object {
        const val GROUP_FAV = "★ Обране"
        const val GROUP_RECENT = "Недавні"
        const val GROUP_ALL = "Усі канали"
        val SPECIAL_GROUPS = listOf(GROUP_FAV, GROUP_RECENT, GROUP_ALL)
        const val LOCKED_GROUP = "🔒 18+"
        private val ADULT_GROUP_KEYS = listOf(
            "xxx", "adult", "18+", "для дорослих", "для взрослых", "взросл", "доросл", "эрот", "еротик", "erotic", "porn",
        )
        private val ADULT_NAME_KEYS = listOf(
            "xxx", "18+", "playboy", "hustler", "brazzers", "dorcel", "penthouse", "redlight", "vivid", "porn", "erotic",
            "эрот", "еротик",
        )
        const val MAX_PLAYLISTS = 10
        private val Q4K = Regex("""\b(4k|uhd|2160[pi]?)\b""")
        private val QFHD = Regex("""\b(fhd|full\s?hd|1080[pi]?)\b""")
        private val QHD = Regex("""\b(hd|720[pi]?)\b""")
        private val QSD = Regex("""\b(sd|576[pi]?|480[pi]?|360[pi]?|240[pi]?)\b""")
        const val OTHER_GROUP = "Інше"
        private const val SMALL_GROUP = 5
        const val ALL_ID = "__all__"
        const val ALL_NAME = "Усі плейлисти"
        private const val STATUS_TTL = 10 * 60_000L

        private val TS_FLAGS = DefaultTsPayloadReaderFactory.FLAG_ALLOW_NON_IDR_KEYFRAMES or
            DefaultTsPayloadReaderFactory.FLAG_DETECT_ACCESS_UNITS or
            DefaultTsPayloadReaderFactory.FLAG_ENABLE_HDMV_DTS_AUDIO_STREAMS

        fun filter(s: State, group: String, query: String): List<Channel> {
            val base = when (group) {
                GROUP_FAV -> s.channels.filter { it.key in s.favorites }
                GROUP_RECENT -> {
                    val byKey = s.channels.associateBy { it.key }
                    s.recents.mapNotNull { byKey[it] }
                }
                GROUP_ALL -> s.channels
                LOCKED_GROUP -> emptyList()
                else -> s.channels.filter { it.group == group }
            }
            val q = query.trim().lowercase()
            if (q.isEmpty()) return base
            return base.filter { it.name.lowercase().contains(q) }
        }
    }
}
