package com.efir.iptv

import android.app.PictureInPictureParams
import android.app.UiModeManager
import android.content.Context
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.os.Build
import android.os.Bundle
import android.util.Rational
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.compose.ui.graphics.Color
import com.efir.iptv.ui.EfirTheme
import com.efir.iptv.ui.SkinBackground
import com.efir.iptv.ui.HomeScreen
import com.efir.iptv.ui.PlayerScreen
import com.efir.iptv.ui.PlaylistsScreen

class MainActivity : ComponentActivity() {

    private val vm: AppViewModel by viewModels()
    private var isTv = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val uiMode = getSystemService(Context.UI_MODE_SERVICE) as UiModeManager
        isTv = packageManager.hasSystemFeature(PackageManager.FEATURE_LEANBACK) ||
            uiMode.currentModeType == Configuration.UI_MODE_TYPE_TELEVISION

        addOnPictureInPictureModeChangedListener { info ->
            vm.inPip.value = info.isInPictureInPictureMode
        }

        setContent {
            val skin by vm.skin.collectAsStateWithLifecycle()
            EfirTheme(skin) {
                EfirApp(vm, isTv) { enterPip() }
            }
        }
    }

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        if (!isTv && vm.screen.value == AppViewModel.Screen.Player && vm.player.isPlaying) enterPip()
    }

    override fun onStart() {
        super.onStart()
        vm.onForeground()
    }

    override fun onStop() {
        super.onStop()
        vm.onBackground()
    }

    private fun enterPip() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        if (!packageManager.hasSystemFeature(PackageManager.FEATURE_PICTURE_IN_PICTURE)) return
        val size = vm.player.videoSize
        var ratio = if (size.width > 0 && size.height > 0) size.width.toFloat() / size.height else 16f / 9f
        ratio = ratio.coerceIn(1f / 2.39f, 2.39f)
        val params = PictureInPictureParams.Builder()
            .setAspectRatio(Rational((ratio * 1000).toInt(), 1000))
            .build()
        try {
            enterPictureInPictureMode(params)
        } catch (e: Exception) {
        }
    }
}

@Composable
fun EfirApp(vm: AppViewModel, isTv: Boolean, onPip: () -> Unit) {
    val screen by vm.screen.collectAsStateWithLifecycle()
    val skin by vm.skin.collectAsStateWithLifecycle()
    val backgrounds by vm.backgrounds.collectAsStateWithLifecycle()
    SkinBackground(skin, backgrounds[skin.name]) {
        Surface(Modifier.fillMaxSize(), color = Color.Transparent, contentColor = MaterialTheme.colorScheme.onBackground) {
            when (screen) {
                AppViewModel.Screen.Home -> HomeScreen(vm, isTv)
                AppViewModel.Screen.Player -> PlayerScreen(vm, isTv, onPip)
                AppViewModel.Screen.Playlists -> PlaylistsScreen(vm, isTv)
            }
        }
    }
}
