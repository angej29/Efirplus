package com.efir.iptv.data

import android.util.Xml
import org.xmlpull.v1.XmlPullParser
import java.io.InputStream
import java.util.Calendar
import java.util.TimeZone

/** Потоковий розбір XMLTV: зберігає лише програми каналів із плейлиста і лише на найближчі години. */
object EpgParser {

    fun normalize(s: String): String = s.lowercase().filter { it.isLetterOrDigit() }

    fun parse(
        input: InputStream,
        channels: List<Channel>,
        now: Long = System.currentTimeMillis(),
    ): Map<String, List<Programme>> {
        val byId = HashMap<String, MutableList<String>>()
        val byName = HashMap<String, MutableList<String>>()
        for (c in channels) {
            if (c.tvgId.isNotBlank()) byId.getOrPut(c.tvgId.lowercase()) { ArrayList() }.add(c.key)
            val n1 = normalize(c.tvgName)
            if (n1.isNotEmpty()) byName.getOrPut(n1) { ArrayList() }.add(c.key)
            val n2 = normalize(c.name)
            if (n2.isNotEmpty() && n2 != n1) byName.getOrPut(n2) { ArrayList() }.add(c.key)
        }

        val epgToKeys = HashMap<String, MutableSet<String>>()
        val out = HashMap<String, MutableList<Programme>>()
        val from = now - 3 * HOUR
        val to = now + 36 * HOUR

        val p = Xml.newPullParser()
        p.setFeature(XmlPullParser.FEATURE_PROCESS_NAMESPACES, false)
        p.setInput(input, null)

        var curChannel: String? = null
        var progKeys: Collection<String>? = null
        var start = 0L
        var stop = 0L
        var title = ""
        var desc = ""

        var ev = p.eventType
        while (ev != XmlPullParser.END_DOCUMENT) {
            if (ev == XmlPullParser.START_TAG) {
                when (p.name) {
                    "channel" -> {
                        val id = p.getAttributeValue(null, "id")
                        curChannel = id
                        if (id != null) {
                            val keys = byId[id.lowercase()]
                            if (keys != null) epgToKeys.getOrPut(id) { HashSet() }.addAll(keys)
                        }
                    }
                    "display-name" -> {
                        val id = curChannel
                        if (id != null) {
                            val keys = byName[normalize(safeText(p))]
                            if (keys != null) epgToKeys.getOrPut(id) { HashSet() }.addAll(keys)
                        }
                    }
                    "programme" -> {
                        val ch = p.getAttributeValue(null, "channel") ?: ""
                        start = parseTime(p.getAttributeValue(null, "start") ?: "")
                        stop = parseTime(p.getAttributeValue(null, "stop") ?: "")
                        val keys: Collection<String>? = epgToKeys[ch] ?: byId[ch.lowercase()]
                        progKeys = if (keys != null && keys.isNotEmpty() && start > 0 && stop > start &&
                            stop > from && start < to
                        ) keys else null
                        title = ""
                        desc = ""
                    }
                    "title" -> if (progKeys != null && title.isEmpty()) title = safeText(p)
                    "desc" -> if (progKeys != null && desc.isEmpty()) desc = safeText(p)
                }
            } else if (ev == XmlPullParser.END_TAG) {
                when (p.name) {
                    "channel" -> curChannel = null
                    "programme" -> {
                        val keys = progKeys
                        if (keys != null) {
                            val pr = Programme(start, stop, title.trim(), desc.trim())
                            for (k in keys) out.getOrPut(k) { ArrayList() }.add(pr)
                        }
                        progKeys = null
                    }
                }
            }
            ev = p.next()
        }
        return out.mapValues { (_, list) -> list.sortedBy { it.start }.distinctBy { it.start } }
    }

    private fun safeText(p: XmlPullParser): String = try {
        p.nextText() ?: ""
    } catch (e: Exception) {
        ""
    }

    /** "20261029153000 +0200" -> мілісекунди UTC */
    fun parseTime(s: String): Long {
        return try {
            val t = s.trim()
            if (t.length < 14) return 0
            val cal = Calendar.getInstance(TimeZone.getTimeZone("UTC"))
            cal.clear()
            cal.set(
                t.substring(0, 4).toInt(),
                t.substring(4, 6).toInt() - 1,
                t.substring(6, 8).toInt(),
                t.substring(8, 10).toInt(),
                t.substring(10, 12).toInt(),
                t.substring(12, 14).toInt(),
            )
            var ms = cal.timeInMillis
            val tz = t.substring(14).trim()
            if (tz.length >= 5 && (tz[0] == '+' || tz[0] == '-')) {
                val sign = if (tz[0] == '-') -1 else 1
                val oh = tz.substring(1, 3).toInt()
                val om = tz.substring(3, 5).toInt()
                ms -= sign * (oh * HOUR + om * 60_000L)
            }
            ms
        } catch (e: Exception) {
            0
        }
    }
}
