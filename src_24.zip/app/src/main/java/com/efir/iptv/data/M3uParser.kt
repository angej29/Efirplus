package com.efir.iptv.data

import java.net.URLDecoder

object M3uParser {
    const val NO_GROUP = "Без групи"

    private val attrRegex = Regex("""([A-Za-z0-9_\-]+)\s*=\s*"([^"]*)"""")

    fun parse(text: String): ParsedPlaylist {
        val result = ArrayList<Channel>()
        val usedKeys = HashSet<String>()
        var epgUrl = ""
        var title: String? = null
        var attrs: Map<String, String> = emptyMap()
        var extGroup: String? = null
        val opts = HashMap<String, String>()
        var hdrCatchup = ""
        var hdrCatchupSource = ""
        var hdrCatchupDays = 0

        for (raw in text.lineSequence()) {
            val line = raw.trim().trimStart('﻿')
            if (line.isEmpty()) continue

            if (line.startsWith("#")) {
                val upper = line.uppercase()
                when {
                    upper.startsWith("#EXTM3U") -> {
                        val a = parseAttrs(line)
                        val e = a["url-tvg"] ?: a["x-tvg-url"] ?: ""
                        if (e.isNotBlank()) epgUrl = e.split(',').first().trim()
                        // Типові налаштування архіву для всього плейлиста
                        a["catchup"]?.let { hdrCatchup = it }
                        a["catchup-source"]?.let { hdrCatchupSource = it }
                        (a["catchup-days"] ?: a["timeshift"])?.toIntOrNull()?.let { hdrCatchupDays = it }
                    }
                    upper.startsWith("#EXTINF") -> {
                        val (head, name) = splitExtinf(line)
                        attrs = parseAttrs(head)
                        title = name
                    }
                    upper.startsWith("#EXTGRP:") -> extGroup = line.substringAfter(':').trim()
                    upper.startsWith("#EXTVLCOPT:") -> {
                        val opt = line.substringAfter(':')
                        val k = opt.substringBefore('=').trim().lowercase()
                        val v = opt.substringAfter('=', "").trim()
                        when (k) {
                            "http-user-agent" -> opts["User-Agent"] = v
                            "http-referrer", "http-referer" -> opts["Referer"] = v
                        }
                    }
                }
                continue
            }

            var url = line
            val headers = HashMap<String, String>(opts)
            attrs["user-agent"]?.takeIf { it.isNotBlank() }?.let { headers["User-Agent"] = it }
            attrs["http-user-agent"]?.takeIf { it.isNotBlank() }?.let { headers["User-Agent"] = it }
            attrs["http-referrer"]?.takeIf { it.isNotBlank() }?.let { headers["Referer"] = it }

            val pipe = url.indexOf('|')
            if (pipe > 0) {
                val extra = url.substring(pipe + 1)
                url = url.substring(0, pipe)
                for (kv in extra.split('&')) {
                    val k = kv.substringBefore('=').trim()
                    val v = decode(kv.substringAfter('=', "").trim())
                    if (k.isNotEmpty() && v.isNotEmpty()) headers[normalizeHeader(k)] = v
                }
            }

            if (url.contains("://")) {
                val name = title?.takeIf { it.isNotBlank() }
                    ?: attrs["tvg-name"]?.takeIf { it.isNotBlank() }
                    ?: url
                val group = attrs["group-title"]?.takeIf { it.isNotBlank() }
                    ?: extGroup?.takeIf { it.isNotBlank() }
                    ?: NO_GROUP
                var key = "$name|$url"
                var n = 2
                while (!usedKeys.add(key)) key = "$name|$url#${n++}"
                result += Channel(
                    key = key,
                    number = attrs["tvg-chno"]?.toIntOrNull() ?: (result.size + 1),
                    name = name,
                    url = url,
                    logo = attrs["tvg-logo"].orEmpty(),
                    group = group,
                    tvgId = attrs["tvg-id"].orEmpty(),
                    tvgName = attrs["tvg-name"].orEmpty(),
                    headers = headers,
                    catchupType = (attrs["catchup"] ?: attrs["catchup-type"] ?: hdrCatchup).lowercase(),
                    catchupDays = (attrs["catchup-days"] ?: attrs["timeshift"] ?: attrs["tvg-rec"])?.toIntOrNull()
                        ?: if ((attrs["catchup"] ?: hdrCatchup).isNotBlank()) hdrCatchupDays.takeIf { it > 0 } ?: 7 else 0,
                    catchupSource = attrs["catchup-source"] ?: hdrCatchupSource,
                    catchupTz = attrs["catchup-tz"].orEmpty(),
                )
            }
            title = null
            attrs = emptyMap()
            extGroup = null
            opts.clear()
        }
        return ParsedPlaylist(result, epgUrl)
    }

    private fun parseAttrs(s: String): Map<String, String> =
        attrRegex.findAll(s).associate { it.groupValues[1].lowercase() to it.groupValues[2].trim() }

    /** Розділяє "#EXTINF:-1 attr="a,b",Назва" по першій комі поза лапками. */
    private fun splitExtinf(line: String): Pair<String, String> {
        var inQuotes = false
        for (i in line.indices) {
            val c = line[i]
            if (c == '"') inQuotes = !inQuotes
            else if (c == ',' && !inQuotes) return line.substring(0, i) to line.substring(i + 1).trim()
        }
        return line to ""
    }

    private fun normalizeHeader(k: String): String = when (k.lowercase()) {
        "user-agent" -> "User-Agent"
        "referer", "referrer" -> "Referer"
        "origin" -> "Origin"
        "cookie" -> "Cookie"
        else -> k
    }

    private fun decode(v: String): String = try {
        URLDecoder.decode(v, "UTF-8")
    } catch (e: Exception) {
        v
    }
}
