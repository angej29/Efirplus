package com.efir.iptv.data

/** Об'єднання каналів з кількох плейлистів: однакові назви — один канал з кількома джерелами. */
object Merger {
    private val bracketRe = Regex("""[\[(][^\])]*[\])]""")
    private val qualityRe = Regex(
        """\b(uhd|fhd|hd|sd|4k|8k|hevc|h\.?265|h\.?264|\d{3,4}[pi]|\d{2,3}\s?fps|orig|original|backup|reserve)\b""",
    )

    fun normalizeName(name: String): String {
        var s = name.lowercase()
        s = bracketRe.replace(s, " ")
        s = qualityRe.replace(s, " ")
        val key = s.filter { it.isLetterOrDigit() }
        return key.ifEmpty { name.lowercase().trim() }
    }

    private val GROUPS: List<Pair<List<String>, String>> = listOf(
        listOf("kids", "child", "cartoon", "anim", "дитяч", "детск", "дети", "мульт") to "Дитячі",
        listOf("sport", "спорт", "football", "футбол") to "Спорт",
        listOf("news", "новин", "новост", "інформ", "информ") to "Новини",
        listOf("series", "серіал", "сериал") to "Серіали",
        listOf("movie", "film", "cinema", "кіно", "кино", "фільм", "фильм") to "Кіно",
        listOf("music", "музик", "музык") to "Музика",
        listOf("document", "докум") to "Документальні",
        listOf("educat", "science", "пізнав", "познав", "наук", "освіт") to "Пізнавальні",
        listOf("relig", "релі", "рели") to "Релігійні",
        listOf("business", "econom", "бізнес", "бизнес", "фінанс", "финанс") to "Бізнес",
        listOf("cook", "food", "кулін", "кулин") to "Кулінарія",
        listOf("travel", "подорож", "путеш") to "Подорожі",
        listOf("regional", "local", "регіон", "регион", "місцев", "местн") to "Регіональні",
        listOf("general", "entertain", "загальн", "общ", "розваж", "развлек") to "Загальні",
    )

    fun normalizeGroup(group: String): String {
        val first = group.split(';', '|').first().trim()
        if (first.isEmpty() || first == M3uParser.NO_GROUP) return M3uParser.NO_GROUP
        val l = first.lowercase()
        for ((keys, name) in GROUPS) if (keys.any { l.contains(it) }) return name
        return first.replaceFirstChar { it.uppercase() }
    }

    fun merge(parts: List<ParsedPlaylist>): ParsedPlaylist {
        val map = LinkedHashMap<String, MutableList<Channel>>()
        for (p in parts) for (c in p.channels) map.getOrPut(normalizeName(c.name)) { ArrayList() }.add(c)
        val out = ArrayList<Channel>(map.size)
        for ((k, list) in map) {
            val primary = list.first()
            val sources = list.distinctBy { it.url }
            val group = list.map { normalizeGroup(it.group) }.firstOrNull { it != M3uParser.NO_GROUP }
                ?: M3uParser.NO_GROUP
            out += primary.copy(
                key = "all|$k",
                number = out.size + 1,
                logo = list.firstOrNull { it.logo.isNotBlank() }?.logo.orEmpty(),
                group = group,
                tvgId = list.firstOrNull { it.tvgId.isNotBlank() }?.tvgId.orEmpty(),
                tvgName = list.firstOrNull { it.tvgName.isNotBlank() }?.tvgName.orEmpty(),
                sources = if (sources.size > 1) sources else emptyList(),
            )
        }
        return ParsedPlaylist(out, "")
    }
}
