package com.efir.iptv.data

data class PlaylistSource(
    val id: String,
    val name: String,
    val url: String,
    val epgUrl: String = "",
)

data class Channel(
    val key: String,
    val number: Int,
    val name: String,
    val url: String,
    val logo: String,
    val group: String,
    val tvgId: String,
    val tvgName: String,
    val headers: Map<String, String>,
    /** Резервні джерела (режим «Усі плейлисти»): той самий канал з різних плейлистів. */
    val sources: List<Channel> = emptyList(),
    /** Архів (catch-up): тип (default/append/shift/flussonic), скільки днів, шаблон адреси, часовий пояс. */
    val catchupType: String = "",
    val catchupDays: Int = 0,
    val catchupSource: String = "",
    val catchupTz: String = "",
) {
    val hasArchive: Boolean get() = catchupType.isNotBlank() && catchupDays > 0
}

data class Programme(
    val start: Long,
    val stop: Long,
    val title: String,
    val desc: String,
)

data class ParsedPlaylist(
    val channels: List<Channel>,
    val epgUrl: String,
)

const val HOUR = 3_600_000L
