package com.efir.iptv.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

class Storage(context: Context) {
    private val prefs = context.getSharedPreferences("efir", Context.MODE_PRIVATE)
    private val dir = File(context.filesDir, "playlists").apply { mkdirs() }

    fun loadPlaylists(): List<PlaylistSource> = try {
        val arr = JSONArray(prefs.getString("playlists", null) ?: "[]")
        (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            PlaylistSource(
                id = o.getString("id"),
                name = o.optString("name"),
                url = o.optString("url"),
                epgUrl = o.optString("epg"),
            )
        }
    } catch (e: Exception) {
        emptyList()
    }

    fun savePlaylists(list: List<PlaylistSource>) {
        val arr = JSONArray()
        for (p in list) {
            arr.put(
                JSONObject()
                    .put("id", p.id)
                    .put("name", p.name)
                    .put("url", p.url)
                    .put("epg", p.epgUrl)
            )
        }
        prefs.edit().putString("playlists", arr.toString()).apply()
    }

    var selectedId: String?
        get() = prefs.getString("selected", null)
        set(value) {
            prefs.edit().putString("selected", value).apply()
        }

    fun favorites(): Set<String> = prefs.getStringSet("favorites", null)?.toSet() ?: emptySet()

    fun saveFavorites(set: Set<String>) {
        prefs.edit().putStringSet("favorites", HashSet(set)).apply()
    }

    fun recents(): List<String> = try {
        val arr = JSONArray(prefs.getString("recents", null) ?: "[]")
        (0 until arr.length()).map { arr.getString(it) }
    } catch (e: Exception) {
        emptyList()
    }

    fun saveRecents(list: List<String>) {
        val arr = JSONArray()
        list.forEach { arr.put(it) }
        prefs.edit().putString("recents", arr.toString()).apply()
    }

    fun hidden(id: String): Set<String> = prefs.getStringSet("hidden_$id", null)?.toSet() ?: emptySet()

    fun saveHidden(id: String, set: Set<String>) {
        prefs.edit().putStringSet("hidden_$id", HashSet(set)).apply()
    }

    fun clearHidden(id: String) {
        prefs.edit().remove("hidden_$id").apply()
    }

    /** Ручні переміщення каналів між групами: ключ каналу → нова група. */
    fun groupOverrides(id: String): Map<String, String> = try {
        val o = JSONObject(prefs.getString("groups_$id", null) ?: "{}")
        o.keys().asSequence().associateWith { o.getString(it) }
    } catch (e: Exception) {
        emptyMap()
    }

    fun saveGroupOverrides(id: String, map: Map<String, String>) {
        val o = JSONObject()
        for ((k, v) in map) o.put(k, v)
        prefs.edit().putString("groups_$id", o.toString()).apply()
    }

    fun clearGroupOverrides(id: String) {
        prefs.edit().remove("groups_$id").apply()
    }

    fun stringMap(key: String): Map<String, String> = try {
        val o = JSONObject(prefs.getString(key, null) ?: "{}")
        o.keys().asSequence().associateWith { o.getString(it) }
    } catch (e: Exception) {
        emptyMap()
    }

    fun saveStringMap(key: String, map: Map<String, String>) {
        val o = JSONObject()
        for ((k, v) in map) o.put(k, v)
        prefs.edit().putString(key, o.toString()).apply()
    }

    fun stringList(key: String): List<String> = try {
        val arr = JSONArray(prefs.getString(key, null) ?: "[]")
        (0 until arr.length()).map { arr.getString(it) }
    } catch (e: Exception) {
        emptyList()
    }

    fun saveStringList(key: String, list: List<String>) {
        val arr = JSONArray()
        list.forEach { arr.put(it) }
        prefs.edit().putString(key, arr.toString()).apply()
    }

    fun remove(key: String) {
        prefs.edit().remove(key).apply()
    }

    var skin: String
        get() = prefs.getString("skin", null) ?: "CLASSIC"
        set(value) {
            prefs.edit().putString("skin", value).apply()
        }

    fun getString(key: String): String? = prefs.getString(key, null)

    fun putString(key: String, value: String) {
        prefs.edit().putString(key, value).apply()
    }

    fun getBool(key: String, def: Boolean): Boolean = prefs.getBoolean(key, def)

    fun putBool(key: String, value: Boolean) {
        prefs.edit().putBoolean(key, value).apply()
    }

    fun playlistFile(id: String) = File(dir, "$id.m3u")
    fun epgFile(id: String) = File(dir, "$id.epg")

    /** Усі налаштування як JSON: {ключ: {"t": тип, "v": значення}}. */
    fun exportPrefs(): JSONObject {
        val o = JSONObject()
        for ((k, v) in prefs.all) {
            val e = JSONObject()
            when (v) {
                is String -> e.put("t", "s").put("v", v)
                is Boolean -> e.put("t", "b").put("v", v)
                is Int -> e.put("t", "i").put("v", v)
                is Long -> e.put("t", "l").put("v", v)
                is Float -> e.put("t", "f").put("v", v.toDouble())
                is Set<*> -> e.put("t", "set").put("v", JSONArray(v.map { it.toString() }))
                else -> continue
            }
            o.put(k, e)
        }
        return o
    }

    /** Замінює всі налаштування збереженими в копії. */
    fun importPrefs(o: JSONObject) {
        val ed = prefs.edit().clear()
        for (k in o.keys()) {
            val e = o.optJSONObject(k) ?: continue
            when (e.optString("t")) {
                "s" -> ed.putString(k, e.optString("v"))
                "b" -> ed.putBoolean(k, e.optBoolean("v"))
                "i" -> ed.putInt(k, e.optInt("v"))
                "l" -> ed.putLong(k, e.optLong("v"))
                "f" -> ed.putFloat(k, e.optDouble("v").toFloat())
                "set" -> {
                    val arr = e.optJSONArray("v") ?: JSONArray()
                    ed.putStringSet(k, (0 until arr.length()).map { arr.getString(it) }.toSet())
                }
            }
        }
        ed.commit()
    }
}
