package com.efir.iptv.ui

import android.content.Context
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.media.AudioManager
import android.os.Build
import android.provider.Settings
import android.view.KeyEvent
import android.view.ViewGroup
import android.view.WindowManager
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.List
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.onKeyEvent
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import com.efir.iptv.AppViewModel
import com.efir.iptv.data.Channel
import kotlinx.coroutines.delay
import kotlin.math.abs
import kotlin.math.roundToInt

private data class Indicator(val label: String, val value: Float)

private val resizeModes = listOf(
    AspectRatioFrameLayout.RESIZE_MODE_FIT to "Вписати",
    AspectRatioFrameLayout.RESIZE_MODE_ZOOM to "Заповнити",
    AspectRatioFrameLayout.RESIZE_MODE_FILL to "Розтягнути",
)

@Composable
fun PlayerScreen(vm: AppViewModel, isTv: Boolean, onPip: () -> Unit) {
    val context = LocalContext.current
    val activity = remember(context) { context.findActivity() }
    val inPip by vm.inPip.collectAsStateWithLifecycle()
    val current by vm.current.collectAsStateWithLifecycle()
    val queue by vm.queue.collectAsStateWithLifecycle()
    val playback by vm.playback.collectAsStateWithLifecycle()
    val audioTracks by vm.audioTracks.collectAsStateWithLifecycle()
    val statuses by vm.streamStatus.collectAsStateWithLifecycle()
    val s by vm.state.collectAsStateWithLifecycle()
    val group by vm.selectedGroup.collectAsStateWithLifecycle()
    val now = rememberNow()

    var controlsVisible by remember { mutableStateOf(false) }
    var bannerVisible by remember { mutableStateOf(true) }
    var listOpen by remember { mutableStateOf(false) }
    var audioOpen by remember { mutableStateOf(false) }
    var interaction by remember { mutableIntStateOf(0) }
    var resizeIndex by rememberSaveable { mutableIntStateOf(0) }
    var indicator by remember { mutableStateOf<Indicator?>(null) }
    val rootFocus = remember { FocusRequester() }
    val firstButton = remember { FocusRequester() }
    val audio = remember { context.getSystemService(Context.AUDIO_SERVICE) as AudioManager }
    val volumeAcc = remember { floatArrayOf(-1f) }
    val pipSupported = remember {
        Build.VERSION.SDK_INT >= Build.VERSION_CODES.O &&
            context.packageManager.hasSystemFeature(PackageManager.FEATURE_PICTURE_IN_PICTURE)
    }

    // Повноекранний режим і альбомна орієнтація на телефоні
    DisposableEffect(activity, isTv) {
        val window = activity?.window
        val ctl = window?.let { WindowCompat.getInsetsController(it, it.decorView) }
        ctl?.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        ctl?.hide(WindowInsetsCompat.Type.systemBars())
        val prevOrientation = activity?.requestedOrientation
        if (!isTv) activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        onDispose {
            ctl?.show(WindowInsetsCompat.Type.systemBars())
            if (!isTv && prevOrientation != null) activity?.requestedOrientation = prevOrientation
            if (window != null) {
                val lp = window.attributes
                lp.screenBrightness = WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE
                window.attributes = lp
            }
        }
    }

    // Автоприховування панелей
    LaunchedEffect(controlsVisible, interaction, listOpen, audioOpen) {
        if (controlsVisible && !listOpen && !audioOpen) {
            delay(4500)
            controlsVisible = false
        }
    }
    LaunchedEffect(current?.key) {
        if (current != null) {
            bannerVisible = true
            delay(3500)
            bannerVisible = false
        }
    }
    LaunchedEffect(indicator) {
        if (indicator != null) {
            delay(1200)
            indicator = null
        }
    }
    // Фокус для пульта
    LaunchedEffect(controlsVisible, listOpen, audioOpen) {
        delay(60)
        try {
            if (audioOpen || listOpen) return@LaunchedEffect
            if (controlsVisible) firstButton.requestFocus() else rootFocus.requestFocus()
        } catch (e: Exception) {
        }
    }

    BackHandler {
        when {
            audioOpen -> audioOpen = false
            listOpen -> listOpen = false
            controlsVisible && isTv -> controlsVisible = false
            else -> vm.stopPlayer()
        }
    }

    val playerView = remember {
        PlayerView(context).apply {
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT,
            )
            useController = false
            setShutterBackgroundColor(android.graphics.Color.BLACK)
            setKeepContentOnPlayerReset(true)
            keepScreenOn = true
            isFocusable = false
            isFocusableInTouchMode = false
            descendantFocusability = ViewGroup.FOCUS_BLOCK_DESCENDANTS
        }
    }
    DisposableEffect(playerView) {
        playerView.player = vm.player
        onDispose { playerView.player = null }
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(Color.Black)
            .onPreviewKeyEvent {
                interaction++
                false
            }
            .onKeyEvent { e ->
                if (e.type != KeyEventType.KeyDown) return@onKeyEvent false
                if (listOpen || controlsVisible || audioOpen) return@onKeyEvent false
                when (e.nativeKeyEvent.keyCode) {
                    KeyEvent.KEYCODE_DPAD_UP -> {
                        vm.step(-1); true
                    }
                    KeyEvent.KEYCODE_DPAD_DOWN -> {
                        vm.step(1); true
                    }
                    KeyEvent.KEYCODE_CHANNEL_UP -> {
                        vm.step(1); true
                    }
                    KeyEvent.KEYCODE_CHANNEL_DOWN -> {
                        vm.step(-1); true
                    }
                    KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER,
                    KeyEvent.KEYCODE_NUMPAD_ENTER, KeyEvent.KEYCODE_DPAD_LEFT -> {
                        listOpen = true; true
                    }
                    KeyEvent.KEYCODE_DPAD_RIGHT, KeyEvent.KEYCODE_MENU, KeyEvent.KEYCODE_INFO -> {
                        controlsVisible = true; true
                    }
                    KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE, KeyEvent.KEYCODE_MEDIA_PLAY, KeyEvent.KEYCODE_MEDIA_PAUSE -> {
                        vm.togglePause(); true
                    }
                    else -> false
                }
            }
            .focusRequester(rootFocus)
            .focusable(),
    ) {
        AndroidView(
            factory = { playerView },
            modifier = Modifier.fillMaxSize(),
            update = { it.resizeMode = resizeModes[resizeIndex].first },
        )

        if (!inPip) {
            // Жести: тап — панель, подвійний тап — список, вертикально — яскравість/гучність, горизонтально — канали
            Box(
                Modifier
                    .fillMaxSize()
                    .pointerInput(Unit) {
                        detectTapGestures(
                            onTap = {
                                if (listOpen || audioOpen) {
                                    listOpen = false
                                    audioOpen = false
                                } else {
                                    controlsVisible = !controlsVisible
                                    interaction++
                                }
                            },
                            onDoubleTap = { listOpen = true },
                        )
                    }
                    .pointerInput(Unit) {
                        var mode = 0 // 0 — ще не визначено, 1 — яскравість, 2 — гучність, 3 — канали
                        var startX = 0f
                        var dx = 0f
                        var dy = 0f
                        detectDragGestures(
                            onDragStart = { o ->
                                mode = 0
                                startX = o.x
                                dx = 0f
                                dy = 0f
                                volumeAcc[0] = -1f
                            },
                            onDragEnd = {
                                if (mode == 3) {
                                    if (dx < -120f) vm.step(1) else if (dx > 120f) vm.step(-1)
                                }
                                mode = 0
                            },
                            onDragCancel = { mode = 0 },
                            onDrag = { change, d ->
                                change.consume()
                                dx += d.x
                                dy += d.y
                                if (mode == 0) {
                                    if (abs(dy) > 30f && abs(dy) > abs(dx)) {
                                        mode = if (startX < size.width / 2f) 1 else 2
                                    } else if (abs(dx) > 30f && abs(dx) > abs(dy)) {
                                        mode = 3
                                    }
                                }
                                val delta = -d.y / size.height.coerceAtLeast(1) * 1.4f
                                if (mode == 1) {
                                    val w = activity?.window
                                    if (w != null) {
                                        val lp = w.attributes
                                        var b = lp.screenBrightness
                                        if (b < 0f) b = systemBrightness(context)
                                        b = (b + delta).coerceIn(0.02f, 1f)
                                        lp.screenBrightness = b
                                        w.attributes = lp
                                        indicator = Indicator("Яскравість", b)
                                    }
                                } else if (mode == 2) {
                                    val max = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
                                    if (volumeAcc[0] < 0f) {
                                        volumeAcc[0] = audio.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat() / max
                                    }
                                    volumeAcc[0] = (volumeAcc[0] + delta).coerceIn(0f, 1f)
                                    try {
                                        audio.setStreamVolume(
                                            AudioManager.STREAM_MUSIC,
                                            (volumeAcc[0] * max).roundToInt(),
                                            0,
                                        )
                                    } catch (e: Exception) {
                                    }
                                    indicator = Indicator("Гучність", volumeAcc[0])
                                }
                            },
                        )
                    },
            )

            if (playback.buffering && playback.error == null) {
                CircularProgressIndicator(
                    Modifier
                        .align(Alignment.Center)
                        .size(48.dp),
                    color = Color.White,
                )
            }

            playback.error?.let { msg ->
                Column(
                    Modifier
                        .align(Alignment.Center)
                        .clip(RoundedCornerShape(16.dp))
                        .background(Color(0xCC000000))
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    Text("Канал не відтворюється", color = Color.White, fontWeight = FontWeight.SemiBold)
                    Text(msg, color = Color.White.copy(alpha = 0.8f), style = MaterialTheme.typography.bodyMedium)
                    if (isTv) {
                        Text(
                            "▲▼ — інший канал,  OK — список,  ► — меню",
                            color = Color.White.copy(alpha = 0.6f),
                            style = MaterialTheme.typography.bodySmall,
                        )
                    } else {
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            Button(onClick = { vm.retry() }) { Text("Повторити") }
                            OutlinedButton(onClick = { listOpen = true }) { Text("Інший канал") }
                        }
                    }
                }
            }

            val ch = current
            AnimatedVisibility(
                visible = ch != null && (controlsVisible || bannerVisible) && !listOpen && !audioOpen,
                enter = fadeIn(),
                exit = fadeOut(),
                modifier = Modifier.align(Alignment.TopCenter),
            ) {
                if (ch != null) {
                    TopOverlay(
                        ch = ch,
                        vm = vm,
                        s = s,
                        now = now,
                        isTv = isTv,
                        showButtons = controlsVisible,
                        favorite = ch.key in s.favorites,
                        resizeLabel = resizeModes[resizeIndex].second,
                        pipSupported = pipSupported,
                        hasAudioTracks = audioTracks.isNotEmpty(),
                        firstButton = firstButton,
                        onResize = {
                            resizeIndex = (resizeIndex + 1) % resizeModes.size
                            interaction++
                        },
                        onPip = onPip,
                        onList = { listOpen = true },
                        onAudio = { audioOpen = true },
                        onInteract = { interaction++ },
                    )
                }
            }

            indicator?.let { ind ->
                Column(
                    Modifier
                        .align(Alignment.Center)
                        .width(220.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .background(Color(0xCC000000))
                        .padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Text("${ind.label}: ${(ind.value * 100).roundToInt()}%", color = Color.White)
                    Spacer(Modifier.height(10.dp))
                    LinearProgressIndicator(
                        progress = { ind.value },
                        modifier = Modifier.fillMaxWidth(),
                        color = Accent,
                        trackColor = Color.White.copy(alpha = 0.2f),
                    )
                }
            }

            AnimatedVisibility(
                visible = listOpen,
                enter = slideInHorizontally { -it } + fadeIn(),
                exit = slideOutHorizontally { -it } + fadeOut(),
                modifier = Modifier.align(Alignment.CenterStart),
            ) {
                ChannelPanel(
                    queue = queue,
                    current = current,
                    s = s,
                    now = now,
                    isTv = isTv,
                    title = if (vm.query.value.isNotBlank()) "Пошук" else group,
                    statuses = statuses,
                    onVisible = { vm.checkStream(it) },
                    onPick = {
                        listOpen = false
                        vm.start(it)
                    },
                    onFavorite = { vm.toggleFavorite(it) },
                    onClose = { listOpen = false },
                )
            }

            AnimatedVisibility(
                visible = audioOpen,
                enter = slideInHorizontally { it } + fadeIn(),
                exit = slideOutHorizontally { it } + fadeOut(),
                modifier = Modifier.align(Alignment.CenterEnd),
            ) {
                AudioPanel(
                    tracks = audioTracks,
                    isTv = isTv,
                    onPick = {
                        vm.selectAudio(it)
                        audioOpen = false
                    },
                    onClose = { audioOpen = false },
                )
            }
        }
    }
}

private fun systemBrightness(context: Context): Float = try {
    Settings.System.getInt(context.contentResolver, Settings.System.SCREEN_BRIGHTNESS) / 255f
} catch (e: Exception) {
    0.5f
}

@Composable
private fun TopOverlay(
    ch: Channel,
    vm: AppViewModel,
    s: AppViewModel.State,
    now: Long,
    isTv: Boolean,
    showButtons: Boolean,
    favorite: Boolean,
    resizeLabel: String,
    pipSupported: Boolean,
    hasAudioTracks: Boolean,
    firstButton: FocusRequester,
    onResize: () -> Unit,
    onPip: () -> Unit,
    onList: () -> Unit,
    onAudio: () -> Unit,
    onInteract: () -> Unit,
) {
    val programmes = s.epg[ch.key]
    val cur = nowProgramme(programmes, now)
    val next = nextProgramme(programmes, now)
    Box(
        Modifier
            .fillMaxWidth()
            .background(Brush.verticalGradient(listOf(Color.Black.copy(alpha = 0.85f), Color.Transparent)))
            .padding(horizontal = if (isTv) 40.dp else 16.dp, vertical = if (isTv) 28.dp else 14.dp)
            .padding(bottom = 28.dp),
    ) {
        Row(verticalAlignment = Alignment.Top) {
            if (showButtons && !isTv) {
                IconBtn(Icons.AutoMirrored.Filled.ArrowBack, "Назад", tint = Color.White) { vm.stopPlayer() }
                Spacer(Modifier.width(4.dp))
            }
            ChannelLogo(ch, if (isTv) 64.dp else 52.dp)
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    "${ch.number}   ${ch.name}",
                    color = Color.White,
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                if (cur != null) {
                    Text(
                        "${hm(cur.start)}–${hm(cur.stop)}   ${cur.title}",
                        color = Color.White.copy(alpha = 0.9f),
                        style = MaterialTheme.typography.bodyMedium,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                    Spacer(Modifier.height(6.dp))
                    LinearProgressIndicator(
                        progress = { progressOf(cur, now) },
                        modifier = Modifier
                            .width(260.dp)
                            .height(3.dp),
                        color = Accent,
                        trackColor = Color.White.copy(alpha = 0.25f),
                    )
                }
                if (next != null) {
                    Spacer(Modifier.height(6.dp))
                    Text(
                        "Далі: ${hm(next.start)}  ${next.title}",
                        color = Color.White.copy(alpha = 0.7f),
                        style = MaterialTheme.typography.bodySmall,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
                if (cur == null && next == null) {
                    Text(ch.group, color = Color.White.copy(alpha = 0.7f), style = MaterialTheme.typography.bodySmall)
                }
            }
            if (showButtons) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconBtn(
                        if (favorite) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
                        "Обране",
                        modifier = Modifier.focusRequester(firstButton),
                        tint = if (favorite) Gold else Color.White,
                    ) {
                        vm.toggleFavorite(ch)
                        onInteract()
                    }
                    TextButton(onClick = onResize, modifier = Modifier.focusHighlight(RoundedCornerShape(20.dp))) {
                        Text(resizeLabel, color = Color.White)
                    }
                    if (hasAudioTracks) {
                        TextButton(onClick = onAudio, modifier = Modifier.focusHighlight(RoundedCornerShape(20.dp))) {
                            Text("Звук", color = Color.White)
                        }
                    }
                    if (pipSupported && !isTv) {
                        TextButton(onClick = onPip, modifier = Modifier.focusHighlight(RoundedCornerShape(20.dp))) {
                            Text("PiP", color = Color.White)
                        }
                    }
                    IconBtn(Icons.AutoMirrored.Filled.List, "Список каналів", tint = Color.White) { onList() }
                }
            }
        }
    }
}

@Composable
private fun ChannelPanel(
    queue: List<Channel>,
    current: Channel?,
    s: AppViewModel.State,
    now: Long,
    isTv: Boolean,
    title: String,
    statuses: Map<String, AppViewModel.StreamStatus>,
    onVisible: suspend (Channel) -> Unit,
    onPick: (Channel) -> Unit,
    onFavorite: (Channel) -> Unit,
    onClose: () -> Unit,
) {
    val listState = rememberLazyListState()
    val idx = queue.indexOfFirst { it.key == current?.key }.coerceAtLeast(0)
    val currentReq = remember { FocusRequester() }
    LaunchedEffect(Unit) {
        listState.scrollToItem((idx - 2).coerceAtLeast(0))
        delay(80)
        try {
            currentReq.requestFocus()
        } catch (e: Exception) {
        }
    }
    Column(
        Modifier
            .fillMaxHeight()
            .width(if (isTv) 440.dp else 340.dp)
            .background(Color(0xF20E1116))
            .pointerInput(Unit) { detectTapGestures { } }
            .padding(12.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold,
                color = Color.White,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier
                    .weight(1f)
                    .padding(start = 4.dp),
            )
            if (!isTv) IconBtn(Icons.Filled.Close, "Закрити", tint = Color.White) { onClose() }
        }
        Spacer(Modifier.height(8.dp))
        LazyColumn(state = listState, verticalArrangement = Arrangement.spacedBy(6.dp)) {
            itemsIndexed(queue, key = { _, c -> c.key }) { i, c ->
                LaunchedEffect(c.key) { onVisible(c) }
                ChannelRow(
                    c = c,
                    favorite = c.key in s.favorites,
                    programme = nowProgramme(s.epg[c.key], now),
                    now = now,
                    selected = c.key == current?.key,
                    compact = true,
                    status = statuses[c.key],
                    modifier = if (i == idx) Modifier.focusRequester(currentReq) else Modifier,
                    onLongClick = { onFavorite(c) },
                    onClick = { onPick(c) },
                )
            }
        }
    }
}

@Composable
private fun AudioPanel(
    tracks: List<AppViewModel.AudioTrack>,
    isTv: Boolean,
    onPick: (AppViewModel.AudioTrack) -> Unit,
    onClose: () -> Unit,
) {
    val firstReq = remember { FocusRequester() }
    LaunchedEffect(Unit) {
        delay(80)
        try {
            firstReq.requestFocus()
        } catch (e: Exception) {
        }
    }
    val selectedIdx = tracks.indexOfFirst { it.selected }.coerceAtLeast(0)
    Column(
        Modifier
            .fillMaxHeight()
            .width(if (isTv) 420.dp else 320.dp)
            .background(Color(0xF20E1116))
            .pointerInput(Unit) { detectTapGestures { } }
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                "Звукова доріжка",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold,
                color = Color.White,
                modifier = Modifier
                    .weight(1f)
                    .padding(start = 4.dp),
            )
            if (!isTv) IconBtn(Icons.Filled.Close, "Закрити", tint = Color.White) { onClose() }
        }
        tracks.forEachIndexed { i, t ->
            val shape = RoundedCornerShape(12.dp)
            Column(
                (if (i == selectedIdx) Modifier.focusRequester(firstReq) else Modifier)
                    .fillMaxWidth()
                    .focusHighlight(shape)
                    .clip(shape)
                    .background(if (t.selected) MaterialTheme.colorScheme.secondaryContainer else MaterialTheme.colorScheme.surface)
                    .clickable { onPick(t) }
                    .padding(horizontal = 14.dp, vertical = 12.dp),
            ) {
                Text(
                    (if (t.selected) "✓  " else "") + t.label,
                    color = Color.White,
                    style = MaterialTheme.typography.bodyLarge,
                )
                if (!t.supported) {
                    Text(
                        "Пристрій не підтримує цей формат",
                        color = Color(0xFFFF8A80),
                        style = MaterialTheme.typography.bodySmall,
                    )
                }
            }
        }
    }
}
