package com.efir.iptv

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import com.efir.iptv.data.Channel
import com.efir.iptv.data.EpgParser
import com.efir.iptv.data.HOUR
import com.efir.iptv.data.M3uParser
import com.efir.iptv.data.Net
import com.efir.iptv.data.ParsedPlaylist
import com.efir.iptv.data.PlaylistSource
import com.efir.iptv.data.Programme
import com.efir.iptv.data.Storage
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.BufferedInputStream
import java.io.FileInputStream
import java.io.IOException
import java.util.UUID

class AppViewModel(app: Application) : AndroidViewModel(app) {

    enum class Screen { Home, Player, Playlists }

    data class State(
        val playlists: List<PlaylistSource> = emptyList(),
        val selectedId: String? = null,
        val channels: List<Channel> = emptyList(),
        val groups: List<String> = emptyList(),
        val loading: Boolean = false,
        val error: String? = null,
        val favorites: Set<String> = emptySet(),
        val recents: List<String> = emptyList(),
        val epg: Map<String, List<Programme>> = emptyMap(),
        val epgLoading: Boolean = false,
    )

    data class Playback(val buffering: Boolean = false, val error: String? = null)

    private val ctx: Context = app.applicationContext
    private val storage = Storage(ctx)

    private val _state = MutableStateFlow(State())
    val state: StateFlow<State> = _state.asStateFlow()

    val screen = MutableStateFlow(Screen.Home)
    val selectedGroup = MutableStateFlow(GROUP_ALL)
    val query = MutableStateFlow("")
    val inPip = MutableStateFlow(false)

    val current = MutableStateFlow<Channel?>(null)
    val queue = MutableStateFlow<List<Channel>>(emptyList())
    val playback = MutableStateFlow(Playback())

    val player: ExoPlayer = ExoPlayer.Builder(ctx)
        .setAudioAttributes(
            AudioAttributes.Builder()
                .setUsage(C.USAGE_MEDIA)
                .setContentType(C.AUDIO_CONTENT_TYPE_MOVIE)
                .build(),
            true,
        )
        .build()

    private var triedHls = false
    private var retries = 0
    private var loadJob: Job? = null
    private var epgJob: Job? = null
    private var retryJob: Job? = null

    init {
        player.playWhenReady = true
        player.addListener(object : Player.Listener {
            override fun onPlaybackStateChanged(playbackState: Int) {
                playback.update { it.copy(buffering = playbackState == Player.STATE_BUFFERING) }
                if (playbackState == Player.STATE_READY) {
                    retries = 0
                    playback.update { it.copy(error = null) }
                }
                if (playbackState == Player.STATE_ENDED) scheduleRestart(1000)
            }

            override fun onPlayerError(error: PlaybackException) = handleError(error)
        })

        val list = storage.loadPlaylists()
        val sel = storage.selectedId?.takeIf { id -> list.any { it.id == id } } ?: list.firstOrNull()?.id
        _state.update {
            it.copy(
                playlists = list,
                selectedId = sel,
                favorites = storage.favorites(),
                recents = storage.recents(),
            )
        }
        if (sel == null) screen.value = Screen.Playlists else load(force = false)
    }

    // ---------------- Плейлисти ----------------

    private fun currentSource(): PlaylistSource? =
        _state.value.playlists.firstOrNull { it.id == _state.value.selectedId }

    fun load(force: Boolean) {
        val src = currentSource() ?: return
        loadJob?.cancel()
        loadJob = viewModelScope.launch {
            _state.update { it.copy(loading = true, error = null) }
            val file = storage.playlistFile(src.id)
            var parsed: ParsedPlaylist? = null
            if (!force && file.exists()) {
                parsed = withContext(Dispatchers.IO) {
                    try {
                        M3uParser.parse(file.readText())
                    } catch (e: Exception) {
                        null
                    }
                }
                if (parsed != null && parsed.channels.isNotEmpty()) applyChannels(parsed) else parsed = null
            }
            val stale = !file.exists() || System.currentTimeMillis() - file.lastModified() > 6 * HOUR
            if (force || parsed == null || stale) {
                try {
                    val text = withContext(Dispatchers.IO) { Net.readText(ctx, src.url) }
                    val fresh = withContext(Dispatchers.Default) { M3uParser.parse(text) }
                    if (fresh.channels.isEmpty()) throw IOException("плейлист порожній або має невідомий формат")
                    withContext(Dispatchers.IO) { file.writeText(text) }
                    parsed = fresh
                    applyChannels(fresh)
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    if (parsed == null) {
                        _state.update {
                            it.copy(error = "Не вдалося завантажити плейлист: ${e.message ?: e.javaClass.simpleName}")
                        }
                    }
                }
            }
            _state.update { it.copy(loading = false) }
            val result = parsed
            if (result != null) loadEpg(src, result, force)
        }
    }

    private fun applyChannels(p: ParsedPlaylist) {
        val groups = p.channels.map { it.group }.distinct()
        _state.update { it.copy(channels = p.channels, groups = groups, error = null) }
        val g = selectedGroup.value
        if (g !in SPECIAL_GROUPS && g !in groups) selectedGroup.value = GROUP_ALL
    }

    private fun loadEpg(src: PlaylistSource, p: ParsedPlaylist, force: Boolean) {
        val url = src.epgUrl.ifBlank { p.epgUrl }
        epgJob?.cancel()
        if (url.isBlank()) {
            _state.update { it.copy(epg = emptyMap(), epgLoading = false) }
            return
        }
        epgJob = viewModelScope.launch {
            _state.update { it.copy(epgLoading = true) }
            try {
                val f = storage.epgFile(src.id)
                val map = withContext(Dispatchers.IO) {
                    val stale = !f.exists() || System.currentTimeMillis() - f.lastModified() > 12 * HOUR
                    if (force || stale) {
                        try {
                            Net.download(ctx, url, f)
                        } catch (e: Exception) {
                            if (!f.exists()) throw e
                        }
                    }
                    Net.maybeGunzip(BufferedInputStream(FileInputStream(f), 65536)).use {
                        EpgParser.parse(it, p.channels)
                    }
                }
                _state.update { it.copy(epg = map) }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                // Телепрограма необовʼязкова — просто працюємо без неї
            } finally {
                _state.update { it.copy(epgLoading = false) }
            }
        }
    }

    fun addPlaylist(name: String, url: String, epg: String) {
        val src = PlaylistSource(
            id = UUID.randomUUID().toString(),
            name = name.trim().ifBlank { "Плейлист" },
            url = url.trim(),
            epgUrl = epg.trim(),
        )
        val list = _state.value.playlists + src
        storage.savePlaylists(list)
        _state.update { it.copy(playlists = list) }
        selectPlaylist(src.id)
    }

    fun selectPlaylist(id: String) {
        storage.selectedId = id
        _state.update {
            it.copy(selectedId = id, channels = emptyList(), groups = emptyList(), epg = emptyMap(), error = null)
        }
        selectedGroup.value = GROUP_ALL
        query.value = ""
        screen.value = Screen.Home
        load(force = false)
    }

    fun refreshPlaylist(id: String) {
        if (_state.value.selectedId != id) {
            storage.playlistFile(id).delete()
            storage.epgFile(id).delete()
            selectPlaylist(id)
        } else {
            screen.value = Screen.Home
            load(force = true)
        }
    }

    fun deletePlaylist(id: String) {
        val list = _state.value.playlists.filter { it.id != id }
        storage.savePlaylists(list)
        storage.playlistFile(id).delete()
        storage.epgFile(id).delete()
        _state.update { it.copy(playlists = list) }
        if (_state.value.selectedId == id) {
            val next = list.firstOrNull()
            if (next != null) {
                selectPlaylist(next.id)
                screen.value = Screen.Playlists
            } else {
                loadJob?.cancel()
                epgJob?.cancel()
                storage.selectedId = null
                _state.update {
                    it.copy(selectedId = null, channels = emptyList(), groups = emptyList(), epg = emptyMap())
                }
            }
        }
    }

    // ---------------- Обране / недавні ----------------

    fun toggleFavorite(c: Channel) {
        val f = _state.value.favorites.toMutableSet()
        if (!f.add(c.key)) f.remove(c.key)
        storage.saveFavorites(f)
        _state.update { it.copy(favorites = f) }
    }

    private fun addRecent(c: Channel) {
        val r = (listOf(c.key) + _state.value.recents.filter { it != c.key }).take(30)
        storage.saveRecents(r)
        _state.update { it.copy(recents = r) }
    }

    // ---------------- Відтворення ----------------

    fun play(c: Channel, list: List<Channel>) {
        queue.value = list.ifEmpty { listOf(c) }
        screen.value = Screen.Player
        start(c)
    }

    fun start(c: Channel) {
        triedHls = false
        retries = 0
        addRecent(c)
        startStream(c, hls = false)
    }

    private fun startStream(c: Channel, hls: Boolean) {
        retryJob?.cancel()
        current.value = c
        playback.value = Playback(buffering = true)

        val headers = HashMap(c.headers)
        val ua = headers.remove("User-Agent") ?: Net.USER_AGENT
        val http = DefaultHttpDataSource.Factory()
            .setUserAgent(ua)
            .setAllowCrossProtocolRedirects(true)
            .setConnectTimeoutMs(15_000)
            .setReadTimeoutMs(20_000)
            .setDefaultRequestProperties(headers)
        val dataSource = DefaultDataSource.Factory(ctx, http)

        val item = MediaItem.Builder().setUri(c.url)
        if (hls || looksHls(c.url)) item.setMimeType(MimeTypes.APPLICATION_M3U8)

        val source = DefaultMediaSourceFactory(dataSource).createMediaSource(item.build())
        player.setMediaSource(source)
        player.prepare()
        player.play()
    }

    private fun looksHls(url: String): Boolean {
        val u = url.lowercase().substringBefore('?')
        return u.endsWith(".m3u8") || u.endsWith(".m3u") || url.lowercase().contains("m3u8")
    }

    private fun handleError(e: PlaybackException) {
        val c = current.value ?: return
        if (screen.value != Screen.Player) return
        if (e.errorCode == PlaybackException.ERROR_CODE_BEHIND_LIVE_WINDOW) {
            player.seekToDefaultPosition()
            player.prepare()
            return
        }
        // Невідомий формат — пробуємо як HLS (часто посилання без розширення .m3u8)
        if (!triedHls && !looksHls(c.url) && e.errorCode in 3000..3999) {
            triedHls = true
            startStream(c, hls = true)
            return
        }
        if (retries < 3) {
            retries++
            scheduleRestart(1500L * retries)
            return
        }
        playback.value = Playback(buffering = false, error = describe(e))
    }

    private fun scheduleRestart(delayMs: Long) {
        val c = current.value ?: return
        if (screen.value != Screen.Player) return
        retryJob?.cancel()
        retryJob = viewModelScope.launch {
            delay(delayMs)
            if (current.value?.key == c.key && screen.value == Screen.Player) startStream(c, triedHls)
        }
    }

    private fun describe(e: PlaybackException): String = when (e.errorCode) {
        PlaybackException.ERROR_CODE_IO_BAD_HTTP_STATUS ->
            "Сервер відхилив запит (канал недоступний або потрібна авторизація)"
        PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_FAILED,
        PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_TIMEOUT ->
            "Немає зʼєднання з сервером каналу"
        in 3000..3999 -> "Невідомий формат потоку"
        in 4000..4999 -> "Пристрій не може декодувати це відео"
        else -> "Помилка відтворення (${e.errorCodeName})"
    }

    fun step(delta: Int) {
        val c = current.value ?: return
        val q = queue.value
        if (q.isEmpty()) return
        val i = q.indexOfFirst { it.key == c.key }.coerceAtLeast(0)
        val n = ((i + delta) % q.size + q.size) % q.size
        start(q[n])
    }

    fun retry() {
        current.value?.let { start(it) }
    }

    fun togglePause() {
        if (player.isPlaying) player.pause() else {
            if (player.playbackState == Player.STATE_IDLE) player.prepare()
            player.seekToDefaultPosition()
            player.play()
        }
    }

    fun stopPlayer() {
        retryJob?.cancel()
        player.stop()
        player.clearMediaItems()
        current.value = null
        playback.value = Playback()
        screen.value = Screen.Home
    }

    fun onForeground() {
        if (screen.value == Screen.Player && current.value != null) {
            if (player.playbackState == Player.STATE_IDLE) player.prepare()
            player.seekToDefaultPosition()
            player.play()
        }
    }

    fun onBackground() {
        player.pause()
    }

    override fun onCleared() {
        player.release()
        super.onCleared()
    }

    companion object {
        const val GROUP_FAV = "★ Обране"
        const val GROUP_RECENT = "Недавні"
        const val GROUP_ALL = "Усі канали"
        val SPECIAL_GROUPS = listOf(GROUP_FAV, GROUP_RECENT, GROUP_ALL)

        fun filter(s: State, group: String, query: String): List<Channel> {
            val base = when (group) {
                GROUP_FAV -> s.channels.filter { it.key in s.favorites }
                GROUP_RECENT -> {
                    val byKey = s.channels.associateBy { it.key }
                    s.recents.mapNotNull { byKey[it] }
                }
                GROUP_ALL -> s.channels
                else -> s.channels.filter { it.group == group }
            }
            val q = query.trim().lowercase()
            if (q.isEmpty()) return base
            return base.filter { it.name.lowercase().contains(q) }
        }
    }
}
