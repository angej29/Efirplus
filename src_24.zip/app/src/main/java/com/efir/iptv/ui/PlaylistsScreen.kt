package com.efir.iptv.ui

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.clickable
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.efir.iptv.AppViewModel
import com.efir.iptv.data.PlaylistSource

private const val SAMPLE_URL = "https://iptv-org.github.io/iptv/countries/ua.m3u"

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun PlaylistsScreen(vm: AppViewModel, isTv: Boolean) {
    val s by vm.state.collectAsStateWithLifecycle()
    val context = LocalContext.current
    var name by rememberSaveable { mutableStateOf("") }
    var url by rememberSaveable { mutableStateOf("") }
    var epg by rememberSaveable { mutableStateOf("") }
    var xtream by rememberSaveable { mutableStateOf(false) }
    var xServer by rememberSaveable { mutableStateOf("") }
    var xUser by rememberSaveable { mutableStateOf("") }
    var xPass by rememberSaveable { mutableStateOf("") }
    var browser by remember { mutableStateOf<BrowseMode?>(null) }
    var editFor by remember { mutableStateOf<PlaylistSource?>(null) }
    val plStatus by vm.playlistStatus.collectAsStateWithLifecycle()
    val deadSrc by vm.deadSourceCount.collectAsStateWithLifecycle()
    LaunchedEffect(s.playlists.size) { vm.checkPlaylists() }

    // Системний вибір файлів (телефони, планшети) — можна кілька одразу
    val openDocs = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNotEmpty()) {
            val items = uris.map { uri ->
                try {
                    context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                } catch (e: Exception) {
                }
                playlistNameFromFile(displayName(context, uri) ?: uri.lastPathSegment) to uri.toString()
            }
            vm.addPlaylists(items)
        }
    }
    // Системне збереження файлу
    val createDoc = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("audio/x-mpegurl")) { uri ->
        if (uri != null) vm.exportToUri(uri)
    }

    // Резервна копія: збереження і відкриття через системне вікно
    val createBackupDoc = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) vm.backupToUri(uri)
    }
    val openBackupDoc = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.restoreBackup { context.contentResolver.openInputStream(uri) }
    }

    // Своє фото фоном (телефони)
    val pickImage = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) vm.setCustomBackground(vm.skin.value) { context.contentResolver.openInputStream(uri) }
    }

    fun chooseBackground() {
        if (isTv) {
            browser = BrowseMode.OpenImage
        } else {
            try {
                pickImage.launch("image/*")
            } catch (e: Exception) {
                browser = BrowseMode.OpenImage
            }
        }
    }

    // Вибір, де шукати / куди зберігати: провідник Ефіру (пам'ять, флешка, ПК) або системне вікно
    var chooser by remember { mutableStateOf<BrowseMode?>(null) }

    fun systemPicker(m: BrowseMode) {
        try {
            when (m) {
                BrowseMode.OpenPlaylist -> openDocs.launch(arrayOf("*/*"))
                BrowseMode.SaveToFolder -> createDoc.launch(vm.suggestedFileName())
                BrowseMode.SaveBackup -> createBackupDoc.launch(vm.backupFileName())
                BrowseMode.OpenBackup -> openBackupDoc.launch(arrayOf("application/json", "text/plain", "application/octet-stream", "*/*"))
                BrowseMode.OpenImage -> pickImage.launch("image/*")
            }
        } catch (e: Exception) {
            browser = m
        }
    }

    fun choose(m: BrowseMode) {
        if (isTv) browser = m else chooser = m
    }

    fun openFromDevice() = choose(BrowseMode.OpenPlaylist)
    fun saveToDisk() = choose(BrowseMode.SaveToFolder)
    fun saveBackup() = choose(BrowseMode.SaveBackup)
    fun openBackup() = choose(BrowseMode.OpenBackup)

    chooser?.let { m ->
        val btnM = Modifier.focusHighlight(RoundedCornerShape(20.dp))
        val save = m == BrowseMode.SaveToFolder || m == BrowseMode.SaveBackup
        androidx.compose.material3.AlertDialog(
            onDismissRequest = { chooser = null },
            title = {
                Text(
                    when (m) {
                        BrowseMode.SaveToFolder -> "Куди зберегти плейлист?"
                        BrowseMode.SaveBackup -> "Куди зберегти резервну копію?"
                        BrowseMode.OpenBackup -> "Звідки відновити копію?"
                        else -> "Звідки додати плейлист?"
                    },
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(
                        onClick = {
                            chooser = null
                            browser = m
                        },
                        modifier = btnM.fillMaxWidth(),
                    ) { Text(if (save) "💻 На ПК / флешку / в пам'ять (провідник Ефіру)" else "💻 Пам'ять / флешка / ПК (провідник Ефіру)") }
                    OutlinedButton(
                        onClick = {
                            chooser = null
                            systemPicker(m)
                        },
                        modifier = btnM.fillMaxWidth(),
                    ) { Text("📱 Системне вікно Android") }
                }
            },
            confirmButton = {},
            dismissButton = {
                TextButton(onClick = { chooser = null }, modifier = btnM) { Text("Скасувати") }
            },
        )
    }


    editFor?.let { p ->
        EditPlaylistDialog(
            p = p,
            onSave = { n, e ->
                vm.updatePlaylist(p.id, n, e)
                editFor = null
            },
            onDismiss = { editFor = null },
        )
    }

    val mode = browser
    if (mode != null) {
        FileBrowser(
            mode = mode,
            isTv = isTv,
            onPickFiles = { files ->
                if (mode == BrowseMode.OpenImage) {
                    files.firstOrNull()?.let { f -> vm.setCustomBackground(vm.skin.value) { java.io.FileInputStream(f) } }
                } else if (mode == BrowseMode.OpenBackup) {
                    files.firstOrNull()?.let { f -> vm.restoreBackup { java.io.FileInputStream(f) } }
                } else {
                    vm.addPlaylists(files.map { playlistNameFromFile(it.name) to Uri.fromFile(it).toString() })
                }
                browser = null
            },
            onPickFolder = { dir ->
                if (mode == BrowseMode.SaveBackup) vm.backupToDir(dir) else vm.exportToDir(dir)
                browser = null
            },
            onClose = { browser = null },
        )
        return
    }

    BackHandler(enabled = s.playlists.isNotEmpty()) { vm.screen.value = AppViewModel.Screen.Home }

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = if (isTv) 48.dp else 16.dp, vertical = if (isTv) 28.dp else 12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (s.playlists.isNotEmpty()) {
                    IconBtn(Icons.AutoMirrored.Filled.ArrowBack, "Назад") {
                        vm.screen.value = AppViewModel.Screen.Home
                    }
                    Spacer(Modifier.width(4.dp))
                }
                Text(
                    "Плейлисти  ${s.playlists.size}/${AppViewModel.MAX_PLAYLISTS}",
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold,
                )
            }
        }

        item { SkinPicker(vm, onPickImage = { chooseBackground() }) }
        item { SettingsCard(vm, onBackup = { saveBackup() }, onRestore = { openBackup() }) }

        if (s.playlists.isEmpty()) {
            item {
                Text(
                    "Додайте M3U-плейлист від свого IPTV-провайдера: посиланням, файлом із пам'яті пристрою або з флешки.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }

        if (s.selectedId == AppViewModel.ALL_ID) {
            item {
                Column(
                    Modifier
                        .widthIn(max = 720.dp)
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .background(MaterialTheme.colorScheme.secondaryContainer)
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                    Text(
                        "✓  ${AppViewModel.ALL_NAME} (об'єднано)",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold,
                    )
                    Text(
                        buildString {
                            append("Каналів: ${s.channels.size}")
                            if (s.hiddenCount > 0) append(" · видалено: ${s.hiddenCount}")
                        },
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        val btn = Modifier.focusHighlight(RoundedCornerShape(20.dp))
                        TextButton(onClick = { vm.refreshPlaylist(AppViewModel.ALL_ID) }, modifier = btn) {
                            Text("Оновити все")
                        }
                        TextButton(onClick = { saveToDisk() }, modifier = btn) { Text("Зберегти у файл…") }
                        if (s.hiddenCount > 0) {
                            TextButton(onClick = { vm.restoreHidden() }, modifier = btn) {
                                Text("Повернути видалені (${s.hiddenCount})")
                            }
                        }
                        if (deadSrc > 0) {
                            TextButton(onClick = { vm.restoreSources() }, modifier = btn) {
                                Text("Повернути прибрані джерела ($deadSrc)")
                            }
                        }
                        if (s.movedCount > 0) {
                            TextButton(onClick = { vm.resetGroups() }, modifier = btn) {
                                Text("Скинути налаштування груп")
                            }
                        }
                    }
                }
            }
        } else if (s.playlists.size > 1) {
            item {
                OutlinedButton(
                    onClick = { vm.selectPlaylist(AppViewModel.ALL_ID) },
                    modifier = Modifier.focusHighlight(RoundedCornerShape(20.dp)),
                ) { Text("Об'єднати всі плейлисти в один список") }
            }
        }

        items(s.playlists, key = { it.id }) { p ->
            val selected = p.id == s.selectedId
            PlaylistCard(
                p = p,
                active = plStatus[p.id],
                selected = selected,
                channelCount = if (selected) s.channels.size else null,
                hiddenCount = if (selected) s.hiddenCount else 0,
                onSelect = { vm.selectPlaylist(p.id) },
                onRefresh = { vm.refreshPlaylist(p.id) },
                onEdit = { editFor = p },
                onSave = { saveToDisk() },
                onRestore = { vm.restoreHidden() },
                deadSources = if (selected) deadSrc else 0,
                onRestoreSources = { vm.restoreSources() },
                movedCount = if (selected) s.movedCount else 0,
                onResetGroups = { vm.resetGroups() },
                onDelete = { vm.deletePlaylist(p.id) },
            )
        }

        item {
            Column(
                Modifier
                    .widthIn(max = 720.dp)
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(MaterialTheme.colorScheme.surface)
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                val full = s.playlists.size >= AppViewModel.MAX_PLAYLISTS
                Text("Новий плейлист", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                if (full) {
                    Text(
                        "Збережено максимум — ${AppViewModel.MAX_PLAYLISTS} плейлистів. Видаліть непотрібний, щоб додати новий.",
                        color = Color(0xFFFF8A80),
                        style = MaterialTheme.typography.bodySmall,
                    )
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    val tb = Modifier.focusHighlight(RoundedCornerShape(20.dp))
                    if (xtream) {
                        OutlinedButton(onClick = { xtream = false }, modifier = tb) { Text("M3U / файл") }
                        Button(onClick = {}, modifier = tb) { Text("✓ Xtream Codes") }
                    } else {
                        Button(onClick = {}, modifier = tb) { Text("✓ M3U / файл") }
                        OutlinedButton(onClick = { xtream = true }, modifier = tb) { Text("Xtream Codes") }
                    }
                }
                if (xtream) {
                    OutlinedTextField(
                        value = name,
                        onValueChange = { name = it },
                        label = { Text("Назва") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().dpadEscape(),
                    )
                    OutlinedTextField(
                        value = xServer,
                        onValueChange = { xServer = it },
                        label = { Text("Сервер (наприклад http://example.com:8080)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().dpadEscape(),
                    )
                    OutlinedTextField(
                        value = xUser,
                        onValueChange = { xUser = it },
                        label = { Text("Логін") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().dpadEscape(),
                    )
                    OutlinedTextField(
                        value = xPass,
                        onValueChange = { xPass = it },
                        label = { Text("Пароль") },
                        singleLine = true,
                        visualTransformation = androidx.compose.ui.text.input.PasswordVisualTransformation(),
                        modifier = Modifier.fillMaxWidth().dpadEscape(),
                    )
                    Text(
                        "Канали, групи, телепрограма й архів завантажаться з сервера провайдера автоматично.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    Button(
                        onClick = {
                            vm.addXtream(name, xServer, xUser, xPass)
                            name = ""
                            xPass = ""
                        },
                        enabled = xServer.isNotBlank() && xUser.isNotBlank() && !full,
                        modifier = Modifier.focusHighlight(RoundedCornerShape(20.dp)),
                    ) { Text("Підключити") }
                } else {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Назва") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .dpadEscape(),
                )
                OutlinedTextField(
                    value = url,
                    onValueChange = { url = it },
                    label = { Text("Посилання на M3U / M3U8 або файл") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .dpadEscape(),
                )
                OutlinedTextField(
                    value = epg,
                    onValueChange = { epg = it },
                    label = { Text("Телепрограма XMLTV (необовʼязково)") },
                    supportingText = { Text("Якщо порожньо — візьмемо з плейлиста (url-tvg), якщо він її вказує") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .dpadEscape(),
                )
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    Button(
                        onClick = {
                            vm.addPlaylist(name, url, epg)
                            name = ""
                            url = ""
                            epg = ""
                        },
                        enabled = url.isNotBlank() && !full,
                        modifier = Modifier.focusHighlight(RoundedCornerShape(20.dp)),
                    ) { Text("Додати") }
                    OutlinedButton(
                        onClick = { openFromDevice() },
                        modifier = Modifier.focusHighlight(RoundedCornerShape(20.dp)),
                    ) { Text("📂 З файлу…") }
                }
                Text(
                    "Файли можна вибрати кілька одразу — кожен стане окремим плейлистом із назвою файлу.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                TextButton(
                    onClick = {
                        name = "Україна (iptv-org)"
                        url = SAMPLE_URL
                        epg = ""
                    },
                    modifier = Modifier.focusHighlight(RoundedCornerShape(20.dp)),
                ) { Text("Підставити відкритий тестовий плейлист") }
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun PlaylistCard(
    p: PlaylistSource,
    active: Boolean?,
    selected: Boolean,
    channelCount: Int?,
    hiddenCount: Int,
    deadSources: Int,
    onRestoreSources: () -> Unit,
    onSelect: () -> Unit,
    onRefresh: () -> Unit,
    onEdit: () -> Unit,
    onSave: () -> Unit,
    onRestore: () -> Unit,
    movedCount: Int,
    onResetGroups: () -> Unit,
    onDelete: () -> Unit,
) {
    var confirmDelete by remember { mutableStateOf(false) }
    val colors = MaterialTheme.colorScheme
    val btn = Modifier.focusHighlight(RoundedCornerShape(20.dp))
    Column(
        Modifier
            .widthIn(max = 720.dp)
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(if (selected) colors.secondaryContainer else colors.surface)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (selected) {
                Icon(Icons.Filled.CheckCircle, contentDescription = null, tint = colors.primary)
                Spacer(Modifier.width(8.dp))
            }
            PlaylistTitle(p.name, active, MaterialTheme.typography.titleMedium, FontWeight.SemiBold)
        }
        Text(
            com.efir.iptv.data.Xtream.decode(p.url)?.let { "Xtream Codes · ${it.server} · ${it.user}" } ?: p.url,
            style = MaterialTheme.typography.bodySmall,
            color = colors.onSurfaceVariant,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
        if (p.epgUrl.isNotBlank()) {
            Text(
                "EPG: ${p.epgUrl}",
                style = MaterialTheme.typography.bodySmall,
                color = colors.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
        if (channelCount != null) {
            Text(
                buildString {
                    append("Каналів: $channelCount")
                    if (hiddenCount > 0) append(" · видалено: $hiddenCount")
                },
                style = MaterialTheme.typography.bodySmall,
                color = colors.onSurfaceVariant,
            )
        }
        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            if (!selected) {
                TextButton(onClick = onSelect, modifier = btn) { Text("Відкрити") }
            }
            TextButton(onClick = onRefresh, modifier = btn) { Text("Оновити") }
            TextButton(onClick = onEdit, modifier = btn) { Text("Телепрограма / назва") }
            if (selected) {
                TextButton(onClick = onSave, modifier = btn) { Text("Зберегти у файл…") }
                if (hiddenCount > 0) {
                    TextButton(onClick = onRestore, modifier = btn) { Text("Повернути видалені ($hiddenCount)") }
                }
                if (deadSources > 0) {
                    TextButton(onClick = onRestoreSources, modifier = btn) { Text("Повернути прибрані джерела ($deadSources)") }
                }
                if (movedCount > 0) {
                    TextButton(onClick = onResetGroups, modifier = btn) { Text("Скинути налаштування груп") }
                }
            }
            TextButton(
                onClick = { if (confirmDelete) onDelete() else confirmDelete = true },
                modifier = btn,
            ) {
                Text(if (confirmDelete) "Точно видалити?" else "Видалити", color = Color(0xFFFF8A80))
            }
        }
    }
}

/** "Спорт HD.m3u8" -> "Спорт HD" */
private fun playlistNameFromFile(fileName: String?): String =
    fileName?.substringAfterLast('/')?.substringBeforeLast('.')?.trim()?.takeIf { it.isNotBlank() } ?: "Плейлист"

private fun displayName(context: android.content.Context, uri: Uri): String? = try {
    context.contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)
        ?.use { c -> if (c.moveToFirst()) c.getString(0) else null }
} catch (e: Exception) {
    null
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun SkinPicker(vm: AppViewModel, onPickImage: () -> Unit) {
    val current by vm.skin.collectAsStateWithLifecycle()
    val backgrounds by vm.backgrounds.collectAsStateWithLifecycle()
    val bgIndex by vm.bgIndex.collectAsStateWithLifecycle()
    Column(
        Modifier
            .widthIn(max = 720.dp)
            .fillMaxWidth()
            .clip(RoundedCornerShape(LocalSkin.current.cornerL))
            .background(MaterialTheme.colorScheme.surface)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Text("Оформлення", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
        FlowRow(
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Skin.entries.forEach { sk ->
                val spec = skinSpec(sk)
                val selected = sk == current
                val shape = RoundedCornerShape(spec.cornerL)
                Column(
                    Modifier
                        .width(120.dp)
                        .focusHighlight(shape)
                        .clip(shape)
                        .background(spec.background)
                        .border(if (selected) 2.dp else 1.dp, if (selected) spec.accent else spec.scheme.outline, shape)
                        .clickable { vm.setSkin(sk) }
                        .padding(10.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        listOf(spec.accent, spec.scheme.secondaryContainer, spec.scheme.surfaceVariant).forEach { c ->
                            Box(
                                Modifier
                                    .size(14.dp)
                                    .clip(RoundedCornerShape(spec.cornerS))
                                    .background(c),
                            )
                        }
                    }
                    Text(
                        (if (selected) "✓ " else "") + sk.title,
                        color = spec.scheme.onSurface,
                        fontFamily = spec.titleFont,
                        fontWeight = spec.titleWeight ?: FontWeight.SemiBold,
                    )
                    Text(sk.hint, color = spec.scheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall, maxLines = 2)
                }
            }
        }
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            val btn = Modifier.focusHighlight(RoundedCornerShape(20.dp))
            val bundled = bundledBackgrounds(current).size
            if (bundled > 0 && backgrounds[current.name] == null) {
                val idx = bgIndex[current.name] ?: 0
                OutlinedButton(onClick = { vm.nextBundledBackground(current) }, modifier = btn) {
                    Text(if (idx < bundled) "Інший фон (${idx + 1}/$bundled)" else "Інший фон (без фото)")
                }
            }
            OutlinedButton(onClick = onPickImage, modifier = btn) { Text("Своє фото фоном для «${current.title}»") }
            if (backgrounds[current.name] != null) {
                TextButton(onClick = { vm.clearCustomBackground(current) }, modifier = btn) {
                    Text("Повернути стандартний фон")
                }
            }
        }
        Text(
            "Фото зберігається лише на цьому пристрої, зменшується й затемнюється, щоб текст читався. " +
                "Під час перегляду каналу фон не показується — плеєр не навантажується.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

@Composable
private fun EditPlaylistDialog(p: PlaylistSource, onSave: (String, String) -> Unit, onDismiss: () -> Unit) {
    var name by remember(p.id) { mutableStateOf(p.name) }
    var epg by remember(p.id) { mutableStateOf(p.epgUrl) }
    val btn = Modifier.focusHighlight(RoundedCornerShape(20.dp))
    androidx.compose.material3.AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Плейлист «${p.name}»") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Назва") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().dpadEscape(),
                )
                OutlinedTextField(
                    value = epg,
                    onValueChange = { epg = it },
                    label = { Text("Телепрограма XMLTV (.xml або .xml.gz)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().dpadEscape(),
                )
                Text(
                    "Порожньо — використати програму, вказану в самому плейлисті (url-tvg). " +
                        "Після збереження програма завантажиться заново.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        },
        confirmButton = {
            TextButton(onClick = { onSave(name, epg) }, modifier = btn) { Text("Зберегти") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss, modifier = btn) { Text("Скасувати") }
        },
    )
}

/** Загальні налаштування в одному блоці: вигляд списку й батьківський контроль. */
@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun SettingsCard(vm: AppViewModel, onBackup: () -> Unit, onRestore: () -> Unit) {
    val viewMode by vm.viewMode.collectAsStateWithLifecycle()
    val parental by vm.parentalOn.collectAsStateWithLifecycle()
    val unlocked by vm.adultUnlocked.collectAsStateWithLifecycle()
    val st by vm.state.collectAsStateWithLifecycle()
    var pinMode by remember { mutableStateOf(0) } // 1 — новий PIN, 2 — підтвердження, 3 — вимкнути
    var firstPin by remember { mutableStateOf("") }
    var restoreAsk by remember { mutableStateOf(false) }
    val btn = Modifier.focusHighlight(RoundedCornerShape(20.dp))

    when (pinMode) {
        1 -> PinDialog(
            title = "Новий PIN",
            hint = "Придумайте 4 цифри. PIN знадобиться, щоб відкрити канали 18+ або вимкнути контроль.",
            confirm = "Далі",
            onSubmit = { p ->
                firstPin = p
                pinMode = 2
            },
            onDismiss = { pinMode = 0 },
        )
        2 -> PinDialog(
            title = "Повторіть PIN",
            hint = "",
            confirm = "Увімкнути",
            onSubmit = { p ->
                if (p == firstPin) {
                    vm.enableParental(p)
                    pinMode = 0
                } else {
                    firstPin = ""
                    pinMode = 1
                }
            },
            onDismiss = { pinMode = 0 },
        )
        3 -> PinDialog(
            title = "Вимкнути контроль",
            hint = "Введіть поточний PIN.",
            confirm = "Вимкнути",
            onSubmit = { p -> if (vm.disableParental(p)) pinMode = 0 },
            onDismiss = { pinMode = 0 },
        )
        4 -> PinDialog(
            title = "Відновлення налаштувань",
            hint = "Увімкнено батьківський контроль — введіть PIN.",
            confirm = "Далі",
            onSubmit = { p ->
                if (vm.checkPin(p)) {
                    pinMode = 0
                    restoreAsk = true
                }
            },
            onDismiss = { pinMode = 0 },
        )
    }

    if (restoreAsk) {
        androidx.compose.material3.AlertDialog(
            onDismissRequest = { restoreAsk = false },
            title = { Text("Відновити з копії?") },
            text = {
                Text(
                    "Поточні плейлисти, обране, групи, джерела, скін і PIN буде замінено тими, що збережені в копії. " +
                        "Радимо спершу зберегти копію поточних налаштувань.",
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        restoreAsk = false
                        onRestore()
                    },
                    modifier = btn,
                ) { Text("Вибрати файл копії") }
            },
            dismissButton = {
                TextButton(onClick = { restoreAsk = false }, modifier = btn) { Text("Скасувати") }
            },
        )
    }

    Column(
        Modifier
            .widthIn(max = 720.dp)
            .fillMaxWidth()
            .clip(RoundedCornerShape(LocalSkin.current.cornerL))
            .background(MaterialTheme.colorScheme.surface)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Text("Налаштування", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)

        Text("Вигляд головного екрана", style = MaterialTheme.typography.labelLarge)
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("☰ Список", "▦ Плитки ×2", "▦▦ Плитки ×4").forEachIndexed { i, label ->
                if (i == viewMode) {
                    Button(onClick = {}, modifier = btn) { Text("✓ $label") }
                } else {
                    OutlinedButton(onClick = { vm.setViewMode(i) }, modifier = btn) { Text(label) }
                }
            }
        }

        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Батьківський контроль (18+)", style = MaterialTheme.typography.labelLarge)
                Text(
                    when {
                        !parental -> "Канали для дорослих ховаються за PIN-кодом. Визначаються автоматично за назвою й групою; " +
                            "будь-яку вкладку можна позначити як 18+ вручну (затиснути вкладку → «Позначити як 18+»)."
                        unlocked -> "Увімкнено. Канали 18+ зараз відкриті до перезапуску Ефіру."
                        st.lockedCount > 0 -> "Увімкнено. Заблоковано каналів: ${st.lockedCount} (вкладка «🔒 18+»)."
                        else -> "Увімкнено. Каналів 18+ у поточному плейлисті не знайдено."
                    },
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            androidx.compose.material3.Switch(
                checked = parental,
                onCheckedChange = { on -> pinMode = if (on) 1 else 3 },
            )
        }
        if (parental && unlocked) {
            OutlinedButton(onClick = { vm.lockAdult() }, modifier = btn) { Text("🔒 Заблокувати знову") }
        }

        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("Резервна копія", style = MaterialTheme.typography.labelLarge)
            Text(
                "Один файл .json з усім: плейлисти (і вміст тих, що з файлів), телепрограма, обране, групи та їх порядок, " +
                    "видалені канали, вибрані джерела, скін і власні фони, батьківський контроль. " +
                    "Збережіть на флешку чи ПК — і відновіть на іншому пристрої або після перевстановлення.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = onBackup, modifier = btn) { Text("💾 Зберегти копію…") }
                OutlinedButton(
                    onClick = { if (parental) pinMode = 4 else restoreAsk = true },
                    modifier = btn,
                ) { Text("♻ Відновити з копії…") }
            }
        }
    }
}
