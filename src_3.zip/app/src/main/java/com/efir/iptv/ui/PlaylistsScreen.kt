package com.efir.iptv.ui

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.efir.iptv.AppViewModel
import com.efir.iptv.data.PlaylistSource

private const val SAMPLE_URL = "https://iptv-org.github.io/iptv/countries/ua.m3u"

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun PlaylistsScreen(vm: AppViewModel, isTv: Boolean) {
    val s by vm.state.collectAsStateWithLifecycle()
    val context = LocalContext.current
    var name by rememberSaveable { mutableStateOf("") }
    var url by rememberSaveable { mutableStateOf("") }
    var epg by rememberSaveable { mutableStateOf("") }
    var browser by remember { mutableStateOf<BrowseMode?>(null) }

    fun applyPickedFile(uri: Uri, fileName: String?) {
        url = uri.toString()
        if (name.isBlank()) {
            name = fileName?.substringAfterLast('/')?.substringBeforeLast('.')?.takeIf { it.isNotBlank() } ?: "Файл"
        }
    }

    // Системний вибір файлу (телефони, планшети)
    val openDoc = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try {
                context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (e: Exception) {
            }
            applyPickedFile(uri, uri.lastPathSegment)
        }
    }
    // Системне збереження файлу
    val createDoc = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("audio/x-mpegurl")) { uri ->
        if (uri != null) vm.exportToUri(uri)
    }

    fun openFromDevice() {
        if (isTv) {
            browser = BrowseMode.OpenPlaylist
        } else {
            try {
                openDoc.launch(arrayOf("*/*"))
            } catch (e: Exception) {
                browser = BrowseMode.OpenPlaylist
            }
        }
    }

    fun saveToDisk() {
        if (isTv) {
            browser = BrowseMode.SaveToFolder
        } else {
            try {
                createDoc.launch(vm.suggestedFileName())
            } catch (e: Exception) {
                browser = BrowseMode.SaveToFolder
            }
        }
    }

    val mode = browser
    if (mode != null) {
        FileBrowser(
            mode = mode,
            isTv = isTv,
            onPickFile = { f ->
                applyPickedFile(Uri.fromFile(f), f.name)
                browser = null
            },
            onPickFolder = { dir ->
                vm.exportToDir(dir)
                browser = null
            },
            onClose = { browser = null },
        )
        return
    }

    BackHandler(enabled = s.playlists.isNotEmpty()) { vm.screen.value = AppViewModel.Screen.Home }

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = if (isTv) 48.dp else 16.dp, vertical = if (isTv) 28.dp else 12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (s.playlists.isNotEmpty()) {
                    IconBtn(Icons.AutoMirrored.Filled.ArrowBack, "Назад") {
                        vm.screen.value = AppViewModel.Screen.Home
                    }
                    Spacer(Modifier.width(4.dp))
                }
                Text(
                    "Плейлисти  ${s.playlists.size}/${AppViewModel.MAX_PLAYLISTS}",
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold,
                )
            }
        }

        if (s.playlists.isEmpty()) {
            item {
                Text(
                    "Додайте M3U-плейлист від свого IPTV-провайдера: посиланням, файлом із пам'яті пристрою або з флешки.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }

        items(s.playlists, key = { it.id }) { p ->
            val selected = p.id == s.selectedId
            PlaylistCard(
                p = p,
                selected = selected,
                channelCount = if (selected) s.channels.size else null,
                hiddenCount = if (selected) s.hiddenCount else 0,
                onSelect = { vm.selectPlaylist(p.id) },
                onRefresh = { vm.refreshPlaylist(p.id) },
                onSave = { saveToDisk() },
                onRestore = { vm.restoreHidden() },
                onDelete = { vm.deletePlaylist(p.id) },
            )
        }

        item {
            Column(
                Modifier
                    .widthIn(max = 720.dp)
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(MaterialTheme.colorScheme.surface)
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                val full = s.playlists.size >= AppViewModel.MAX_PLAYLISTS
                Text("Новий плейлист", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                if (full) {
                    Text(
                        "Збережено максимум — ${AppViewModel.MAX_PLAYLISTS} плейлистів. Видаліть непотрібний, щоб додати новий.",
                        color = Color(0xFFFF8A80),
                        style = MaterialTheme.typography.bodySmall,
                    )
                }
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Назва") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .dpadEscape(),
                )
                OutlinedTextField(
                    value = url,
                    onValueChange = { url = it },
                    label = { Text("Посилання на M3U / M3U8 або файл") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .dpadEscape(),
                )
                OutlinedTextField(
                    value = epg,
                    onValueChange = { epg = it },
                    label = { Text("Телепрограма XMLTV (необовʼязково)") },
                    supportingText = { Text("Якщо порожньо — візьмемо з плейлиста (url-tvg), якщо він її вказує") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .dpadEscape(),
                )
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    Button(
                        onClick = {
                            vm.addPlaylist(name, url, epg)
                            name = ""
                            url = ""
                            epg = ""
                        },
                        enabled = url.isNotBlank() && !full,
                        modifier = Modifier.focusHighlight(RoundedCornerShape(20.dp)),
                    ) { Text("Додати") }
                    OutlinedButton(
                        onClick = { openFromDevice() },
                        modifier = Modifier.focusHighlight(RoundedCornerShape(20.dp)),
                    ) { Text("Файл з пристрою") }
                    OutlinedButton(
                        onClick = { browser = BrowseMode.OpenPlaylist },
                        modifier = Modifier.focusHighlight(RoundedCornerShape(20.dp)),
                    ) { Text("Пам'ять / флешка") }
                }
                TextButton(
                    onClick = {
                        name = "Україна (iptv-org)"
                        url = SAMPLE_URL
                        epg = ""
                    },
                    modifier = Modifier.focusHighlight(RoundedCornerShape(20.dp)),
                ) { Text("Підставити відкритий тестовий плейлист") }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun PlaylistCard(
    p: PlaylistSource,
    selected: Boolean,
    channelCount: Int?,
    hiddenCount: Int,
    onSelect: () -> Unit,
    onRefresh: () -> Unit,
    onSave: () -> Unit,
    onRestore: () -> Unit,
    onDelete: () -> Unit,
) {
    var confirmDelete by remember { mutableStateOf(false) }
    val colors = MaterialTheme.colorScheme
    val btn = Modifier.focusHighlight(RoundedCornerShape(20.dp))
    Column(
        Modifier
            .widthIn(max = 720.dp)
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(if (selected) colors.secondaryContainer else colors.surface)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (selected) {
                Icon(Icons.Filled.CheckCircle, contentDescription = null, tint = colors.primary)
                Spacer(Modifier.width(8.dp))
            }
            Text(p.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
        }
        Text(
            p.url,
            style = MaterialTheme.typography.bodySmall,
            color = colors.onSurfaceVariant,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
        if (p.epgUrl.isNotBlank()) {
            Text(
                "EPG: ${p.epgUrl}",
                style = MaterialTheme.typography.bodySmall,
                color = colors.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
        if (channelCount != null) {
            Text(
                buildString {
                    append("Каналів: $channelCount")
                    if (hiddenCount > 0) append(" · видалено: $hiddenCount")
                },
                style = MaterialTheme.typography.bodySmall,
                color = colors.onSurfaceVariant,
            )
        }
        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            if (!selected) {
                TextButton(onClick = onSelect, modifier = btn) { Text("Відкрити") }
            }
            TextButton(onClick = onRefresh, modifier = btn) { Text("Оновити") }
            if (selected) {
                TextButton(onClick = onSave, modifier = btn) { Text("Зберегти у файл") }
                if (hiddenCount > 0) {
                    TextButton(onClick = onRestore, modifier = btn) { Text("Повернути видалені ($hiddenCount)") }
                }
            }
            TextButton(
                onClick = { if (confirmDelete) onDelete() else confirmDelete = true },
                modifier = btn,
            ) {
                Text(if (confirmDelete) "Точно видалити?" else "Видалити", color = Color(0xFFFF8A80))
            }
        }
    }
}
