package com.efir.iptv.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.URLEncoder

/**
 * Xtream Codes: вхід за сервером, логіном і паролем.
 * Канали й групи беремо з player_api.php і перетворюємо на M3U з атрибутами архіву —
 * далі все працює так само, як зі звичайним плейлистом.
 */
object Xtream {
    private const val PREFIX = "xtream|"

    data class Account(val server: String, val user: String, val pass: String)

    fun isXtream(url: String) = url.startsWith(PREFIX)

    fun encode(server: String, user: String, pass: String): String =
        PREFIX + normalizeServer(server) + "|" + user.trim() + "|" + pass.trim()

    fun decode(url: String): Account? {
        if (!isXtream(url)) return null
        val p = url.removePrefix(PREFIX).split('|')
        if (p.size < 3) return null
        return Account(p[0], p[1], p.drop(2).joinToString("|"))
    }

    fun normalizeServer(s: String): String {
        var v = s.trim().trimEnd('/')
        if (!v.startsWith("http://", true) && !v.startsWith("https://", true)) v = "http://$v"
        return v
    }

    private fun enc(v: String) = URLEncoder.encode(v, "UTF-8")

    fun epgUrl(a: Account) = "${a.server}/xmltv.php?username=${enc(a.user)}&password=${enc(a.pass)}"

    /** Повертає текст M3U. Кидає IOException з зрозумілим поясненням. */
    fun loadAsM3u(ctx: Context, a: Account): String {
        val api = "${a.server}/player_api.php?username=${enc(a.user)}&password=${enc(a.pass)}"
        val info = JSONObject(Net.readText(ctx, api))
        val user = info.optJSONObject("user_info") ?: throw IOException("сервер не схожий на Xtream Codes")
        if (user.optInt("auth", 0) != 1) throw IOException("невірний логін або пароль")
        val status = user.optString("status")
        if (status.isNotBlank() && !status.equals("Active", true)) throw IOException("обліковий запис: $status")
        val tz = info.optJSONObject("server_info")?.optString("timezone").orEmpty()

        val cats = HashMap<String, String>()
        JSONArray(Net.readText(ctx, "$api&action=get_live_categories")).let { arr ->
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                cats[o.optString("category_id")] = o.optString("category_name")
            }
        }
        val streams = JSONArray(Net.readText(ctx, "$api&action=get_live_streams"))
        fun q(v: String) = v.replace('"', '\'')
        val sb = StringBuilder()
        sb.append("#EXTM3U url-tvg=\"").append(epgUrl(a)).append("\"\n")
        for (i in 0 until streams.length()) {
            val o = streams.getJSONObject(i)
            val id = o.optString("stream_id")
            if (id.isBlank()) continue
            val name = o.optString("name").ifBlank { "Канал $id" }.replace("\n", " ")
            sb.append("#EXTINF:-1")
            sb.append(" tvg-id=\"").append(q(o.optString("epg_channel_id"))).append('"')
            sb.append(" tvg-name=\"").append(q(name)).append('"')
            sb.append(" tvg-logo=\"").append(q(o.optString("stream_icon"))).append('"')
            sb.append(" group-title=\"").append(q(cats[o.optString("category_id")].orEmpty())).append('"')
            if (o.optInt("tv_archive", 0) == 1) {
                val days = o.optInt("tv_archive_duration", 3).coerceAtLeast(1)
                sb.append(" catchup=\"default\" catchup-days=\"").append(days).append('"')
                sb.append(" catchup-source=\"").append(a.server).append("/timeshift/")
                    .append(enc(a.user)).append('/').append(enc(a.pass))
                    .append("/{duration_min}/{Y}-{m}-{d}:{H}-{M}/").append(id).append(".ts\"")
                if (tz.isNotBlank()) sb.append(" catchup-tz=\"").append(tz).append('"')
            }
            sb.append(',').append(name).append('\n')
            sb.append(a.server).append("/live/").append(enc(a.user)).append('/').append(enc(a.pass))
                .append('/').append(id).append(".ts\n")
        }
        if (streams.length() == 0) throw IOException("на сервері немає каналів")
        return sb.toString()
    }
}
