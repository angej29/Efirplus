package com.efir.iptv.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.remember
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import kotlin.random.Random

val Accent = Color(0xFF4F8CFF)
val Gold = Color(0xFFFFC857)
val Bg = Color(0xFF0E1116)

/** Скіни оформлення. Лише кольори, форми й шрифти — без анімацій і картинок, щоб не навантажувати плеєр. */
enum class Skin(val title: String, val hint: String) {
    CLASSIC("Класік", "Стандартний темний"),
    MOVIE("Муві", "Кінозал: чорний і золото"),
    CARTOON("Мульт", "Яскравий і округлий"),
    SPACE("Спейс", "Глибокий космос і зорі"),
    NANO("Нано", "Неонове футуристичне"),
}

data class SkinSpec(
    val scheme: ColorScheme,
    /** Колір акцентів у плеєрі (прогрес, підписи). */
    val accent: Color,
    /** Рамка елемента у фокусі (пульт). */
    val focus: Color,
    /** Заокруглення карток і дрібних елементів. */
    val cornerL: Dp,
    val cornerS: Dp,
    val background: Brush,
    val titleFont: FontFamily?,
    val titleWeight: FontWeight? = null,
    val stars: Boolean = false,
)

fun skinSpec(skin: Skin): SkinSpec = when (skin) {
    Skin.CLASSIC -> SkinSpec(
        scheme = darkColorScheme(
            primary = Accent,
            onPrimary = Color.White,
            secondary = Color(0xFF7AE0B8),
            background = Bg,
            onBackground = Color(0xFFE6EAF0),
            surface = Color(0xFF161B22),
            onSurface = Color(0xFFE6EAF0),
            surfaceVariant = Color(0xFF1F2630),
            onSurfaceVariant = Color(0xFF9AA4B2),
            secondaryContainer = Color(0xFF243B63),
            onSecondaryContainer = Color.White,
            outline = Color(0xFF3A4452),
        ),
        accent = Accent,
        focus = Color.White,
        cornerL = 14.dp,
        cornerS = 8.dp,
        background = Brush.verticalGradient(listOf(Bg, Bg)),
        titleFont = null,
    )
    Skin.MOVIE -> SkinSpec(
        scheme = darkColorScheme(
            primary = Color(0xFFE0B04A),
            onPrimary = Color(0xFF1A1206),
            secondary = Color(0xFFB3312C),
            background = Color(0xFF0B0A08),
            onBackground = Color(0xFFF2E8D5),
            surface = Color(0xFF17130F),
            onSurface = Color(0xFFF2E8D5),
            surfaceVariant = Color(0xFF241E17),
            onSurfaceVariant = Color(0xFFB8A88F),
            secondaryContainer = Color(0xFF5A1E1C),
            onSecondaryContainer = Color(0xFFFFE9C2),
            outline = Color(0xFF4A3F30),
        ),
        accent = Color(0xFFE0B04A),
        focus = Color(0xFFE0B04A),
        cornerL = 6.dp,
        cornerS = 4.dp,
        background = Brush.verticalGradient(listOf(Color(0xFF1A140E), Color(0xFF0B0A08), Color(0xFF0B0A08))),
        titleFont = FontFamily.Serif,
    )
    Skin.CARTOON -> SkinSpec(
        // Під фон «кінопроектор і мультгерої»: теплий промінь лампи + блакитне сяйво
        scheme = darkColorScheme(
            primary = Color(0xFFFFB547),
            onPrimary = Color(0xFF2B1600),
            secondary = Color(0xFF3EC7F5),
            background = Color(0xFF0E0D0D),
            onBackground = Color(0xFFFFF3E2),
            surface = Color(0xFF1E1712),
            onSurface = Color(0xFFFFF3E2),
            surfaceVariant = Color(0xFF2E241C),
            onSurfaceVariant = Color(0xFFD9C3A8),
            secondaryContainer = Color(0xFF613931),
            onSecondaryContainer = Color(0xFFFFE3C2),
            outline = Color(0xFF5A4636),
        ),
        accent = Color(0xFFFFB547),
        focus = Color(0xFF3EC7F5),
        cornerL = 24.dp,
        cornerS = 18.dp,
        background = Brush.verticalGradient(listOf(Color(0xFF28130C), Color(0xFF0E0D0D))),
        titleFont = FontFamily.SansSerif,
        titleWeight = FontWeight.ExtraBold,
    )
    Skin.SPACE -> SkinSpec(
        // Під фон «галактика»: глибокий синій + теплий акцент ядра галактики
        scheme = darkColorScheme(
            primary = Color(0xFF7FB2FF),
            onPrimary = Color(0xFF001A40),
            secondary = Color(0xFFFFC27A),
            background = Color(0xFF020921),
            onBackground = Color(0xFFE6EDFF),
            surface = Color(0xFF09183D),
            onSurface = Color(0xFFE6EDFF),
            surfaceVariant = Color(0xFF203064),
            onSurfaceVariant = Color(0xFF9FB0DA),
            secondaryContainer = Color(0xFF355096),
            onSecondaryContainer = Color.White,
            outline = Color(0xFF2E3F7A),
        ),
        accent = Color(0xFFFFC27A),
        focus = Color(0xFFFFC27A),
        cornerL = 16.dp,
        cornerS = 10.dp,
        background = Brush.verticalGradient(listOf(Color(0xFF062B6E), Color(0xFF020921), Color(0xFF01020D))),
        titleFont = null,
        titleWeight = FontWeight.Light,
        stars = true,
    )
    Skin.NANO -> SkinSpec(
        // Під фон «ДНК / наномолекули»: електричний синій, холодне сяйво
        scheme = darkColorScheme(
            primary = Color(0xFF4DB8FF),
            onPrimary = Color(0xFF00122E),
            secondary = Color(0xFF7FE7FF),
            background = Color(0xFF00061E),
            onBackground = Color(0xFFD8ECFF),
            surface = Color(0xFF061436),
            onSurface = Color(0xFFD8ECFF),
            surfaceVariant = Color(0xFF0F2A5E),
            onSurfaceVariant = Color(0xFF7FA8D9),
            secondaryContainer = Color(0xFF0F4298),
            onSecondaryContainer = Color(0xFFE3F3FF),
            outline = Color(0xFF1F61C1),
        ),
        accent = Color(0xFF4DB8FF),
        focus = Color(0xFF7FE7FF),
        cornerL = 2.dp,
        cornerS = 2.dp,
        background = Brush.verticalGradient(listOf(Color(0xFF062E75), Color(0xFF00061E))),
        titleFont = FontFamily.Monospace,
    )
}

/** Вбудовані фото-фони скінів (можна гортати). «Муві» — намальований кінозал або своє фото. */
fun bundledBackgrounds(skin: Skin): List<Int> = when (skin) {
    Skin.CLASSIC -> emptyList()
    Skin.MOVIE -> emptyList()
    Skin.CARTOON -> listOf(com.efir.iptv.R.drawable.bg_cartoon)
    Skin.SPACE -> listOf(com.efir.iptv.R.drawable.bg_space, com.efir.iptv.R.drawable.bg_city)
    Skin.NANO -> listOf(com.efir.iptv.R.drawable.bg_nano, com.efir.iptv.R.drawable.bg_city)
}

val LocalSkin = staticCompositionLocalOf { skinSpec(Skin.CLASSIC) }

private fun typographyFor(spec: SkinSpec): Typography {
    val t = Typography()
    val f = spec.titleFont
    val w = spec.titleWeight
    if (f == null && w == null) return t
    fun s(style: androidx.compose.ui.text.TextStyle) = style.copy(
        fontFamily = f ?: style.fontFamily,
        fontWeight = w ?: style.fontWeight,
    )
    return t.copy(
        headlineSmall = s(t.headlineSmall),
        titleLarge = s(t.titleLarge),
        titleMedium = s(t.titleMedium),
        titleSmall = s(t.titleSmall),
        labelLarge = s(t.labelLarge),
    )
}

@Composable
fun EfirTheme(skin: Skin = Skin.CLASSIC, content: @Composable () -> Unit) {
    val spec = remember(skin) { skinSpec(skin) }
    val typography = remember(skin) { typographyFor(spec) }
    CompositionLocalProvider(LocalSkin provides spec) {
        MaterialTheme(colorScheme = spec.scheme, typography = typography, content = content)
    }
}

/**
 * Фон скіна: власне фото користувача (зменшене й затемнене) або вбудована
 * оригінальна ілюстрація, намальована один раз — без анімацій.
 */
@Composable
fun SkinBackground(skin: Skin, customImage: String?, bundledIndex: Int, content: @Composable () -> Unit) {
    val spec = LocalSkin.current
    Box(
        Modifier
            .fillMaxSize()
            .background(spec.background),
    ) {
        if (customImage != null) {
            coil.compose.AsyncImage(
                model = java.io.File(customImage),
                contentDescription = null,
                contentScale = androidx.compose.ui.layout.ContentScale.Crop,
                modifier = Modifier.fillMaxSize(),
            )
            // Затемнення, щоб текст лишався читабельним
            Box(
                Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.55f)),
            )
        } else {
            val res = bundledBackgrounds(skin).getOrNull(bundledIndex)
            if (res != null) {
                coil.compose.AsyncImage(
                    model = res,
                    contentDescription = null,
                    contentScale = androidx.compose.ui.layout.ContentScale.Crop,
                    modifier = Modifier.fillMaxSize(),
                )
                Box(
                    Modifier
                        .fillMaxSize()
                        .background(Color.Black.copy(alpha = 0.45f)),
                )
            } else {
                SkinArt(skin)
            }
        }
        content()
    }
}

@Composable
private fun SkinArt(skin: Skin) {
    val seed = remember(skin) { Random(skin.ordinal * 31 + 7) }
    val pts = remember(skin) { List(90) { Triple(seed.nextFloat(), seed.nextFloat(), seed.nextFloat()) } }
    val m = Modifier.fillMaxSize()
    when (skin) {
        Skin.CLASSIC -> {}
        Skin.MOVIE -> androidx.compose.foundation.Canvas(m) { drawMovie(pts) }
        Skin.CARTOON -> androidx.compose.foundation.Canvas(m) { drawCartoon(pts) }
        Skin.SPACE -> androidx.compose.foundation.Canvas(m) { drawSpace(pts) }
        Skin.NANO -> androidx.compose.foundation.Canvas(m) { drawNano(pts) }
    }
}

private typealias DS = androidx.compose.ui.graphics.drawscope.DrawScope

/** Кінозал: промені прожекторів, плівка внизу, віньєтка. */
private fun DS.drawMovie(pts: List<Triple<Float, Float, Float>>) {
    val w = size.width
    val h = size.height
    val gold = Color(0xFFE0B04A)
    // Промені прожекторів з верхніх кутів
    for ((x0, dir) in listOf(0f to 1f, w to -1f)) {
        val path = androidx.compose.ui.graphics.Path().apply {
            moveTo(x0, 0f)
            lineTo(x0 + dir * w * 0.62f, h)
            lineTo(x0 + dir * w * 0.30f, h)
            close()
        }
        drawPath(
            path,
            Brush.verticalGradient(listOf(gold.copy(alpha = 0.16f), Color.Transparent)),
        )
    }
    // Пилинки в променях
    for ((x, y, r) in pts.take(40)) {
        drawCircle(gold.copy(alpha = 0.10f + r * 0.15f), radius = (0.6f + r) * density, center = Offset(x * w, y * h * 0.8f))
    }
    // Кіноплівка
    val bandH = h * 0.09f
    val top = h - bandH - h * 0.04f
    drawRect(Color(0xFF050403).copy(alpha = 0.85f), Offset(0f, top), androidx.compose.ui.geometry.Size(w, bandH))
    val hole = bandH * 0.18f
    var x = hole
    while (x < w) {
        for (yy in listOf(top + hole * 0.6f, top + bandH - hole * 1.6f)) {
            drawRoundRect(
                gold.copy(alpha = 0.22f),
                Offset(x, yy),
                androidx.compose.ui.geometry.Size(hole * 1.3f, hole),
                androidx.compose.ui.geometry.CornerRadius(hole * 0.25f),
            )
        }
        x += hole * 2.6f
    }
    // Кадри на плівці
    var fx = hole * 2f
    while (fx < w) {
        drawRect(
            gold.copy(alpha = 0.06f),
            Offset(fx, top + hole * 2f),
            androidx.compose.ui.geometry.Size(bandH * 1.2f, bandH - hole * 4.2f),
        )
        fx += bandH * 1.5f
    }
    // Віньєтка
    drawRect(
        Brush.radialGradient(
            listOf(Color.Transparent, Color.Black.copy(alpha = 0.6f)),
            center = center,
            radius = maxOf(w, h) * 0.75f,
        ),
    )
}

/** Мульт: різнокольорові бульбашки, зірочки й хмаринки. */
private fun DS.drawCartoon(pts: List<Triple<Float, Float, Float>>) {
    val w = size.width
    val h = size.height
    val colors = listOf(Color(0xFFFFC93C), Color(0xFFFF6FB5), Color(0xFF7CF29C), Color(0xFF6FD3FF), Color(0xFFB794FF))
    pts.take(26).forEachIndexed { i, (x, y, r) ->
        drawCircle(colors[i % colors.size].copy(alpha = 0.10f), radius = (18f + r * 60f) * density, center = Offset(x * w, y * h))
    }
    pts.drop(26).take(14).forEachIndexed { i, (x, y, r) ->
        drawStar(Offset(x * w, y * h), (6f + r * 10f) * density, colors[(i + 2) % colors.size].copy(alpha = 0.35f))
    }
    // Хмаринки внизу
    val cloud = Color.White.copy(alpha = 0.06f)
    var cx = -40f * density
    var k = 0
    while (cx < w + 60f * density) {
        val base = h - 30f * density
        val r = (50f + (k % 3) * 18f) * density
        drawCircle(cloud, r, Offset(cx, base))
        drawCircle(cloud, r * 0.7f, Offset(cx + r * 0.9f, base - r * 0.3f))
        cx += r * 1.8f
        k++
    }
}

private fun DS.drawStar(c: Offset, r: Float, color: Color) {
    val path = androidx.compose.ui.graphics.Path()
    for (i in 0 until 10) {
        val a = Math.PI / 5 * i - Math.PI / 2
        val rr = if (i % 2 == 0) r else r * 0.45f
        val px = c.x + (rr * kotlin.math.cos(a)).toFloat()
        val py = c.y + (rr * kotlin.math.sin(a)).toFloat()
        if (i == 0) path.moveTo(px, py) else path.lineTo(px, py)
    }
    path.close()
    drawPath(path, color)
}

/** Космос: зорі, туманність, планета з кільцем. */
private fun DS.drawSpace(pts: List<Triple<Float, Float, Float>>) {
    val w = size.width
    val h = size.height
    drawRect(
        Brush.radialGradient(
            listOf(Color(0xFF6A3FD6).copy(alpha = 0.22f), Color.Transparent),
            center = Offset(w * 0.25f, h * 0.3f),
            radius = maxOf(w, h) * 0.45f,
        ),
    )
    drawRect(
        Brush.radialGradient(
            listOf(Color(0xFF2FA9D9).copy(alpha = 0.16f), Color.Transparent),
            center = Offset(w * 0.7f, h * 0.15f),
            radius = maxOf(w, h) * 0.35f,
        ),
    )
    for ((x, y, r) in pts) {
        drawCircle(
            Color.White.copy(alpha = 0.25f + r * 0.6f),
            radius = (0.5f + r * 1.5f) * density,
            center = Offset(x * w, y * h),
        )
    }
    // Планета
    val pr = minOf(w, h) * 0.22f
    val pc = Offset(w * 0.86f, h * 0.88f)
    drawCircle(
        Brush.radialGradient(
            listOf(Color(0xFF7FD4FF).copy(alpha = 0.55f), Color(0xFF1A2150).copy(alpha = 0.9f)),
            center = Offset(pc.x - pr * 0.4f, pc.y - pr * 0.4f),
            radius = pr * 1.4f,
        ),
        radius = pr,
        center = pc,
    )
    drawOval(
        Color(0xFFB794FF).copy(alpha = 0.35f),
        topLeft = Offset(pc.x - pr * 1.7f, pc.y - pr * 0.35f),
        size = androidx.compose.ui.geometry.Size(pr * 3.4f, pr * 0.7f),
        style = androidx.compose.ui.graphics.drawscope.Stroke(width = 3f * density),
    )
}

/** Нано: сітка й неонові «доріжки» мікросхеми. */
private fun DS.drawNano(pts: List<Triple<Float, Float, Float>>) {
    val w = size.width
    val h = size.height
    val neon = Color(0xFF4DB8FF)
    val step = 48f * density
    var x = 0f
    while (x < w) {
        drawLine(neon.copy(alpha = 0.05f), Offset(x, 0f), Offset(x, h), 1f)
        x += step
    }
    var y = 0f
    while (y < h) {
        drawLine(neon.copy(alpha = 0.05f), Offset(0f, y), Offset(w, y), 1f)
        y += step
    }
    // Доріжки: з вузла горизонтально, потім по діагоналі
    for ((i, p) in pts.take(18).withIndex()) {
        val (px, py, r) = p
        val sx = (px * w / step).toInt() * step
        val sy = (py * h / step).toInt() * step
        val len = (2 + (r * 5).toInt()) * step
        val dir = if (i % 2 == 0) 1f else -1f
        val mid = Offset(sx + dir * len, sy)
        val end = Offset(mid.x + dir * step, sy + step)
        val c = (if (i % 3 == 0) Color(0xFF00E5FF) else neon).copy(alpha = 0.22f)
        drawLine(c, Offset(sx, sy), mid, 2f * density)
        drawLine(c, mid, end, 2f * density)
        drawCircle(c.copy(alpha = 0.5f), 3.5f * density, Offset(sx, sy))
        drawCircle(c.copy(alpha = 0.5f), 3.5f * density, end)
    }
    drawRect(
        Brush.verticalGradient(listOf(Color.Transparent, neon.copy(alpha = 0.06f))),
    )
}
