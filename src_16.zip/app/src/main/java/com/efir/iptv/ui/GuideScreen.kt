package com.efir.iptv.ui

import android.view.KeyEvent
import android.view.ViewGroup
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.media3.ui.PlayerView
import com.efir.iptv.AppViewModel
import com.efir.iptv.data.Catchup
import com.efir.iptv.data.Channel
import com.efir.iptv.data.HOUR
import com.efir.iptv.data.Programme
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

private const val HALF_HOUR = 30 * 60_000L
private val dayFormat = SimpleDateFormat("EEE, d MMM", Locale("uk"))

private fun floorHalfHour(t: Long): Long = t - Math.floorMod(t, HALF_HOUR)

private fun dayStart(t: Long): Long = Calendar.getInstance().apply {
    timeInMillis = t
    set(Calendar.HOUR_OF_DAY, 0)
    set(Calendar.MINUTE, 0)
    set(Calendar.SECOND, 0)
    set(Calendar.MILLISECOND, 0)
}.timeInMillis

/** Сітка телепрограми: канали × час. Минулі передачі з архівом можна дивитися. */
@Composable
fun GuideScreen(vm: AppViewModel, isTv: Boolean) {
    val s by vm.state.collectAsStateWithLifecycle()
    val group by vm.selectedGroup.collectAsStateWithLifecycle()
    val current by vm.current.collectAsStateWithLifecycle()
    val now = rememberNow()
    val channels = remember(s.channels, s.favorites, s.recents, group) { AppViewModel.filter(s, group, "") }
    val windowLen = if (isTv) 3 * HOUR else 2 * HOUR
    var winStart by remember { mutableLongStateOf(floorHalfHour(System.currentTimeMillis() - HALF_HOUR)) }
    val winEnd = winStart + windowLen
    var details by remember { mutableStateOf<Pair<Channel, Programme>?>(null) }
    val firstCell = remember { FocusRequester() }
    val maxPastDays = (channels.maxOfOrNull { it.catchupDays } ?: 0).coerceIn(1, 7)
    val today = dayStart(now)

    BackHandler { vm.closeGuide() }
    LaunchedEffect(group) {
        delay(150)
        try {
            firstCell.requestFocus()
        } catch (e: Exception) {
        }
    }

    Column(
        Modifier
            .fillMaxSize()
            .padding(horizontal = if (isTv) 32.dp else 8.dp, vertical = if (isTv) 20.dp else 6.dp),
    ) {
        // Заголовок
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconBtn(Icons.AutoMirrored.Filled.ArrowBack, "Назад") { vm.closeGuide() }
            Column(Modifier.weight(1f)) {
                Text("Програма", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Text(
                    "$group · ${dayFormat.format(Date(winStart))}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            if (current != null) MiniPreview(vm)
        }

        // Дні та навігація по часу
        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            contentPadding = PaddingValues(vertical = 6.dp),
        ) {
            item { NavChip("◀ 1 год") { winStart -= HOUR } }
            item { NavChip("Зараз", selected = now in winStart until winEnd) { winStart = floorHalfHour(now - HALF_HOUR) } }
            item { NavChip("1 год ▶") { winStart += HOUR } }
            items((-maxPastDays..1).toList()) { offset ->
                val d = today + offset * 24 * HOUR
                val label = when (offset) {
                    -1 -> "Вчора"
                    0 -> "Сьогодні"
                    1 -> "Завтра"
                    else -> dayFormat.format(Date(d))
                }
                NavChip(label, selected = winStart in d until d + 24 * HOUR) {
                    winStart = if (offset == 0) floorHalfHour(now - HALF_HOUR) else d + 18 * HOUR
                }
            }
        }
        // Групи
        val chips = AppViewModel.SPECIAL_GROUPS + s.groups
        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp), contentPadding = PaddingValues(bottom = 6.dp)) {
            items(chips) { g -> NavChip(g, selected = g == group) { vm.selectedGroup.value = g } }
        }

        val nameW = if (isTv) 200.dp else 120.dp
        // Шкала часу
        Row(Modifier.fillMaxWidth()) {
            Spacer(Modifier.width(nameW))
            Row(Modifier.weight(1f)) {
                var t = winStart
                while (t < winEnd) {
                    Text(
                        hm(t),
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.weight(1f).padding(start = 4.dp),
                    )
                    t += HALF_HOUR
                }
            }
        }
        Spacer(Modifier.height(4.dp))

        if (channels.isEmpty()) {
            CenterMessage("Немає каналів", "У цій групі немає каналів")
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(3.dp), modifier = Modifier.fillMaxSize()) {
                itemsIndexed(channels, key = { _, c -> c.key }) { i, c ->
                    GuideRow(
                        c = c,
                        programmes = s.epg[c.key].orEmpty(),
                        winStart = winStart,
                        winEnd = winEnd,
                        now = now,
                        nameW = nameW,
                        focusReq = if (i == 0) firstCell else null,
                        onChannel = { vm.play(c, channels) },
                        onProgramme = { p -> details = c to p },
                        onShift = { d -> winStart += d },
                    )
                }
            }
        }
    }

    details?.let { (c, p) ->
        ProgrammeDialog(
            c = c,
            p = p,
            now = now,
            onLive = {
                details = null
                vm.play(c, channels)
            },
            onArchive = {
                details = null
                vm.playArchive(c, p.start, p.stop, p.title)
            },
            onDismiss = { details = null },
        )
    }
}

@Composable
private fun NavChip(label: String, selected: Boolean = false, onClick: () -> Unit) {
    val shape = RoundedCornerShape(LocalSkin.current.cornerS)
    val colors = MaterialTheme.colorScheme
    Text(
        label,
        maxLines = 1,
        style = MaterialTheme.typography.labelLarge,
        color = if (selected) colors.onSecondaryContainer else colors.onSurface,
        modifier = Modifier
            .focusHighlight(shape)
            .clip(shape)
            .background(if (selected) colors.secondaryContainer else colors.surface)
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 7.dp),
    )
}

private sealed class Cell(val weight: Float) {
    class Prog(val p: Programme, w: Float) : Cell(w)
    class Gap(w: Float) : Cell(w)
}

@Composable
private fun GuideRow(
    c: Channel,
    programmes: List<Programme>,
    winStart: Long,
    winEnd: Long,
    now: Long,
    nameW: androidx.compose.ui.unit.Dp,
    focusReq: FocusRequester?,
    onChannel: () -> Unit,
    onProgramme: (Programme) -> Unit,
    onShift: (Long) -> Unit,
) {
    val skin = LocalSkin.current
    val colors = MaterialTheme.colorScheme
    val len = (winEnd - winStart).toFloat()
    // Розбиваємо вікно на клітинки передач і проміжки
    val cells = remember(programmes, winStart, winEnd) {
        val out = ArrayList<Cell>()
        var t = winStart
        for (p in programmes) {
            if (p.stop <= winStart || p.start >= winEnd) continue
            val a = maxOf(p.start, winStart)
            val b = minOf(p.stop, winEnd)
            if (a > t) out += Cell.Gap((a - t) / len)
            if (b > a) out += Cell.Prog(p, (b - a) / len)
            t = maxOf(t, b)
        }
        if (t < winEnd) out += Cell.Gap((winEnd - t) / len)
        out
    }
    val progCells = cells.filterIsInstance<Cell.Prog>()
    val focusIdx = progCells.indexOfFirst { now in it.p.start until it.p.stop }.coerceAtLeast(0)
    val hasArchive = Catchup.archiveSource(c) != null

    Row(
        Modifier
            .fillMaxWidth()
            .height(54.dp),
    ) {
        // Канал
        Row(
            Modifier
                .width(nameW)
                .fillMaxHeight()
                .padding(end = 3.dp)
                .focusHighlight(RoundedCornerShape(skin.cornerS))
                .clip(RoundedCornerShape(skin.cornerS))
                .background(colors.surface)
                .clickable(onClick = onChannel)
                .padding(horizontal = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            ChannelLogo(c, 34.dp)
            Spacer(Modifier.width(6.dp))
            Text(
                (if (hasArchive) "⟲ " else "") + c.name,
                style = MaterialTheme.typography.labelLarge,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
            )
        }
        // Передачі
        Row(
            Modifier
                .weight(1f)
                .fillMaxHeight()
                .drawWithContent {
                    drawContent()
                    if (now in winStart until winEnd) {
                        val x = size.width * ((now - winStart) / len)
                        drawLine(skin.accent, Offset(x, 0f), Offset(x, size.height), 2f * density)
                    }
                },
        ) {
            if (progCells.isEmpty()) {
                Box(
                    Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .clip(RoundedCornerShape(skin.cornerS))
                        .background(colors.surface.copy(alpha = 0.5f))
                        .then(if (focusReq != null) Modifier.focusRequester(focusReq) else Modifier)
                        .focusHighlight(RoundedCornerShape(skin.cornerS))
                        .clickable(onClick = onChannel)
                        .padding(horizontal = 8.dp),
                    contentAlignment = Alignment.CenterStart,
                ) {
                    Text("Немає програми", style = MaterialTheme.typography.bodySmall, color = colors.onSurfaceVariant)
                }
            }
            var pi = 0
            for (cell in cells) {
                when (cell) {
                    is Cell.Gap -> if (progCells.isNotEmpty()) Spacer(Modifier.weight(cell.weight.coerceAtLeast(0.001f)))
                    is Cell.Prog -> {
                        val idx = pi++
                        val p = cell.p
                        val live = now in p.start until p.stop
                        val past = p.stop <= now
                        val archive = past && Catchup.canPlay(c, p.start, now)
                        val shape = RoundedCornerShape(skin.cornerS)
                        Column(
                            Modifier
                                .weight(cell.weight.coerceAtLeast(0.001f))
                                .fillMaxHeight()
                                .padding(horizontal = 1.dp)
                                .then(if (focusReq != null && idx == focusIdx) Modifier.focusRequester(focusReq) else Modifier)
                                .onPreviewKeyEvent { e ->
                                    if (e.type != KeyEventType.KeyDown) return@onPreviewKeyEvent false
                                    when {
                                        e.nativeKeyEvent.keyCode == KeyEvent.KEYCODE_DPAD_LEFT && idx == 0 -> {
                                            onShift(-HOUR)
                                            true
                                        }
                                        e.nativeKeyEvent.keyCode == KeyEvent.KEYCODE_DPAD_RIGHT && idx == progCells.lastIndex -> {
                                            onShift(HOUR)
                                            true
                                        }
                                        else -> false
                                    }
                                }
                                .focusHighlight(shape)
                                .clip(shape)
                                .background(
                                    when {
                                        live -> colors.secondaryContainer
                                        past -> colors.surface.copy(alpha = 0.55f)
                                        else -> colors.surface
                                    },
                                )
                                .clickable { onProgramme(p) }
                                .padding(horizontal = 6.dp, vertical = 4.dp),
                            verticalArrangement = Arrangement.Center,
                        ) {
                            Text(
                                (if (archive) "⟲ " else "") + p.title.ifBlank { "Без назви" },
                                style = MaterialTheme.typography.bodySmall,
                                fontWeight = if (live) FontWeight.SemiBold else FontWeight.Normal,
                                color = if (live) colors.onSecondaryContainer else colors.onSurface.copy(alpha = if (past && !archive) 0.6f else 1f),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                            )
                            Text(
                                "${hm(p.start)}–${hm(p.stop)}",
                                style = MaterialTheme.typography.labelSmall,
                                color = colors.onSurfaceVariant,
                                maxLines = 1,
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ProgrammeDialog(
    c: Channel,
    p: Programme,
    now: Long,
    onLive: () -> Unit,
    onArchive: () -> Unit,
    onDismiss: () -> Unit,
) {
    val live = now in p.start until p.stop
    val past = p.stop <= now
    val canArchive = (past || live) && Catchup.canPlay(c, p.start, now)
    val btn = Modifier.focusHighlight(RoundedCornerShape(20.dp))
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(p.title.ifBlank { "Без назви" }, maxLines = 3, overflow = TextOverflow.Ellipsis) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(
                    "${c.name} · ${dayFormat.format(Date(p.start))}, ${hm(p.start)}–${hm(p.stop)}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                if (live) Text("Зараз в ефірі", color = LocalSkin.current.accent, style = MaterialTheme.typography.labelLarge)
                if (p.desc.isNotBlank()) Text(p.desc, style = MaterialTheme.typography.bodyMedium, maxLines = 8, overflow = TextOverflow.Ellipsis)
                if (past && !canArchive) {
                    Text(
                        "Передача вже пройшла, а архіву для цього каналу немає.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                if (!past && !live) {
                    Text(
                        "Передача ще не почалась.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        },
        confirmButton = {
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                if (canArchive) {
                    TextButton(onClick = onArchive, modifier = btn) { Text(if (live) "З початку" else "Дивитися з архіву") }
                }
                TextButton(onClick = onLive, modifier = btn) { Text("Канал наживо") }
            }
        },
        dismissButton = { TextButton(onClick = onDismiss, modifier = btn) { Text("Закрити") } },
    )
}

/** Маленьке вікно поточного каналу в сітці програми. */
@Composable
private fun MiniPreview(vm: AppViewModel) {
    val context = LocalContext.current
    val view = remember {
        PlayerView(context).apply {
            layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
            useController = false
            setShutterBackgroundColor(android.graphics.Color.BLACK)
            isFocusable = false
            descendantFocusability = ViewGroup.FOCUS_BLOCK_DESCENDANTS
        }
    }
    DisposableEffect(view) {
        view.player = vm.player
        onDispose { view.player = null }
    }
    Box(
        Modifier
            .size(width = 160.dp, height = 90.dp)
            .clip(RoundedCornerShape(LocalSkin.current.cornerS))
            .background(Color.Black)
            .clickable { vm.closeGuide() },
    ) {
        AndroidView(factory = { view }, modifier = Modifier.fillMaxSize())
    }
}
