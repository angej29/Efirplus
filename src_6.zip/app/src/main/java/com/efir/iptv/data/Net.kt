package com.efir.iptv.data

import android.content.Context
import android.net.Uri
import java.io.BufferedInputStream
import java.io.File
import java.io.IOException
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.zip.GZIPInputStream

object Net {
    const val USER_AGENT = "VLC/3.0.20 LibVLC/3.0.20"

    /** Відкриває http(s)-посилання або файл (content://), без розпакування gzip. */
    fun openRaw(ctx: Context, url: String): InputStream {
        val u = url.trim()
        if (u.startsWith("content://") || u.startsWith("file://")) {
            return ctx.contentResolver.openInputStream(Uri.parse(u))
                ?: throw IOException("Не вдалося відкрити файл")
        }
        var current = u
        repeat(6) {
            val conn = URL(current).openConnection() as HttpURLConnection
            conn.connectTimeout = 20_000
            conn.readTimeout = 60_000
            conn.instanceFollowRedirects = true
            conn.setRequestProperty("User-Agent", USER_AGENT)
            conn.setRequestProperty("Accept-Encoding", "gzip")
            val code = conn.responseCode
            if (code in 300..399) {
                val loc = conn.getHeaderField("Location")
                conn.disconnect()
                if (loc.isNullOrBlank()) throw IOException("HTTP $code")
                current = URL(URL(current), loc).toString()
                return@repeat
            }
            if (code !in 200..299) {
                conn.disconnect()
                throw IOException("HTTP $code")
            }
            return conn.inputStream
        }
        throw IOException("Забагато перенаправлень")
    }

    /**
     * Швидка перевірка, чи живий потік: запит із заголовками каналу,
     * успішна відповідь і хоч якісь дані протягом кількох секунд.
     */
    fun probe(c: Channel): Boolean {
        var url = c.url
        val ua = c.headers["User-Agent"] ?: USER_AGENT
        repeat(5) {
            val conn = try {
                URL(url).openConnection() as HttpURLConnection
            } catch (e: Exception) {
                return false
            }
            try {
                conn.connectTimeout = 6_000
                conn.readTimeout = 6_000
                conn.instanceFollowRedirects = true
                conn.setRequestProperty("User-Agent", ua)
                for ((k, v) in c.headers) if (k != "User-Agent") conn.setRequestProperty(k, v)
                val code = conn.responseCode
                if (code in 300..399) {
                    val loc = conn.getHeaderField("Location") ?: return false
                    url = URL(URL(url), loc).toString()
                    return@repeat
                }
                if (code !in 200..299) return false
                val buf = ByteArray(512)
                return conn.inputStream.read(buf) > 0
            } catch (e: Exception) {
                return false
            } finally {
                conn.disconnect()
            }
        }
        return false
    }

    /** Чи доступний плейлист (посилання відповідає або файл читається). */
    fun probePlaylist(ctx: Context, url: String): Boolean = try {
        openRaw(ctx, url).use { it.read() >= 0 }
    } catch (e: Exception) {
        false
    }

    fun maybeGunzip(input: BufferedInputStream): InputStream {
        input.mark(4)
        val b1 = input.read()
        val b2 = input.read()
        input.reset()
        return if (b1 == 0x1f && b2 == 0x8b) GZIPInputStream(input, 65536) else input
    }

    fun readText(ctx: Context, url: String): String =
        maybeGunzip(BufferedInputStream(openRaw(ctx, url), 65536)).use {
            it.readBytes().toString(Charsets.UTF_8)
        }

    fun download(ctx: Context, url: String, dest: File) {
        val tmp = File(dest.path + ".tmp")
        openRaw(ctx, url).use { input ->
            tmp.outputStream().use { out -> input.copyTo(out, 65536) }
        }
        if (dest.exists()) dest.delete()
        if (!tmp.renameTo(dest)) throw IOException("Не вдалося зберегти файл")
    }
}
