package com.efir.iptv.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.remember
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import kotlin.random.Random

val Accent = Color(0xFF4F8CFF)
val Gold = Color(0xFFFFC857)
val Bg = Color(0xFF0E1116)

/** Скіни оформлення. Лише кольори, форми й шрифти — без анімацій і картинок, щоб не навантажувати плеєр. */
enum class Skin(val title: String, val hint: String) {
    CLASSIC("Класік", "Стандартний темний"),
    MOVIE("Муві", "Кінозал: чорний і золото"),
    CARTOON("Мульт", "Яскравий і округлий"),
    SPACE("Спейс", "Глибокий космос і зорі"),
    NANO("Нано", "Неонове футуристичне"),
}

data class SkinSpec(
    val scheme: ColorScheme,
    /** Колір акцентів у плеєрі (прогрес, підписи). */
    val accent: Color,
    /** Рамка елемента у фокусі (пульт). */
    val focus: Color,
    /** Заокруглення карток і дрібних елементів. */
    val cornerL: Dp,
    val cornerS: Dp,
    val background: Brush,
    val titleFont: FontFamily?,
    val titleWeight: FontWeight? = null,
    val stars: Boolean = false,
)

fun skinSpec(skin: Skin): SkinSpec = when (skin) {
    Skin.CLASSIC -> SkinSpec(
        scheme = darkColorScheme(
            primary = Accent,
            onPrimary = Color.White,
            secondary = Color(0xFF7AE0B8),
            background = Bg,
            onBackground = Color(0xFFE6EAF0),
            surface = Color(0xFF161B22),
            onSurface = Color(0xFFE6EAF0),
            surfaceVariant = Color(0xFF1F2630),
            onSurfaceVariant = Color(0xFF9AA4B2),
            secondaryContainer = Color(0xFF243B63),
            onSecondaryContainer = Color.White,
            outline = Color(0xFF3A4452),
        ),
        accent = Accent,
        focus = Color.White,
        cornerL = 14.dp,
        cornerS = 8.dp,
        background = Brush.verticalGradient(listOf(Bg, Bg)),
        titleFont = null,
    )
    Skin.MOVIE -> SkinSpec(
        scheme = darkColorScheme(
            primary = Color(0xFFE0B04A),
            onPrimary = Color(0xFF1A1206),
            secondary = Color(0xFFB3312C),
            background = Color(0xFF0B0A08),
            onBackground = Color(0xFFF2E8D5),
            surface = Color(0xFF17130F),
            onSurface = Color(0xFFF2E8D5),
            surfaceVariant = Color(0xFF241E17),
            onSurfaceVariant = Color(0xFFB8A88F),
            secondaryContainer = Color(0xFF5A1E1C),
            onSecondaryContainer = Color(0xFFFFE9C2),
            outline = Color(0xFF4A3F30),
        ),
        accent = Color(0xFFE0B04A),
        focus = Color(0xFFE0B04A),
        cornerL = 6.dp,
        cornerS = 4.dp,
        background = Brush.verticalGradient(listOf(Color(0xFF1A140E), Color(0xFF0B0A08), Color(0xFF0B0A08))),
        titleFont = FontFamily.Serif,
    )
    Skin.CARTOON -> SkinSpec(
        scheme = darkColorScheme(
            primary = Color(0xFFFFC93C),
            onPrimary = Color(0xFF2B1B00),
            secondary = Color(0xFFFF6FB5),
            background = Color(0xFF1B1446),
            onBackground = Color(0xFFFFF7E6),
            surface = Color(0xFF2A2160),
            onSurface = Color(0xFFFFF7E6),
            surfaceVariant = Color(0xFF3A2E80),
            onSurfaceVariant = Color(0xFFC9C0FF),
            secondaryContainer = Color(0xFFFF6FB5),
            onSecondaryContainer = Color(0xFF2A0B1C),
            outline = Color(0xFF6A5BD6),
        ),
        accent = Color(0xFFFFC93C),
        focus = Color(0xFF7CF29C),
        cornerL = 24.dp,
        cornerS = 18.dp,
        background = Brush.verticalGradient(listOf(Color(0xFF2E1F78), Color(0xFF1B1446))),
        titleFont = FontFamily.SansSerif,
        titleWeight = FontWeight.ExtraBold,
    )
    Skin.SPACE -> SkinSpec(
        scheme = darkColorScheme(
            primary = Color(0xFF7FD4FF),
            onPrimary = Color(0xFF00202E),
            secondary = Color(0xFFB794FF),
            background = Color(0xFF05060F),
            onBackground = Color(0xFFE3E8FF),
            surface = Color(0xFF0E1330),
            onSurface = Color(0xFFE3E8FF),
            surfaceVariant = Color(0xFF1A2150),
            onSurfaceVariant = Color(0xFF9AA3D6),
            secondaryContainer = Color(0xFF2B2F7A),
            onSecondaryContainer = Color.White,
            outline = Color(0xFF2E3570),
        ),
        accent = Color(0xFF7FD4FF),
        focus = Color(0xFFB794FF),
        cornerL = 16.dp,
        cornerS = 10.dp,
        background = Brush.verticalGradient(listOf(Color(0xFF141A45), Color(0xFF05060F), Color(0xFF0A0420))),
        titleFont = null,
        titleWeight = FontWeight.Light,
        stars = true,
    )
    Skin.NANO -> SkinSpec(
        scheme = darkColorScheme(
            primary = Color(0xFF00FFA3),
            onPrimary = Color(0xFF00140C),
            secondary = Color(0xFF00E5FF),
            background = Color(0xFF020806),
            onBackground = Color(0xFFCFFFEA),
            surface = Color(0xFF07140F),
            onSurface = Color(0xFFCFFFEA),
            surfaceVariant = Color(0xFF0D2219),
            onSurfaceVariant = Color(0xFF5FBF98),
            secondaryContainer = Color(0xFF003D2A),
            onSecondaryContainer = Color(0xFF00FFA3),
            outline = Color(0xFF0F5C40),
        ),
        accent = Color(0xFF00FFA3),
        focus = Color(0xFF00E5FF),
        cornerL = 2.dp,
        cornerS = 2.dp,
        background = Brush.verticalGradient(listOf(Color(0xFF04201A), Color(0xFF020806))),
        titleFont = FontFamily.Monospace,
    )
}

val LocalSkin = staticCompositionLocalOf { skinSpec(Skin.CLASSIC) }

private fun typographyFor(spec: SkinSpec): Typography {
    val t = Typography()
    val f = spec.titleFont
    val w = spec.titleWeight
    if (f == null && w == null) return t
    fun s(style: androidx.compose.ui.text.TextStyle) = style.copy(
        fontFamily = f ?: style.fontFamily,
        fontWeight = w ?: style.fontWeight,
    )
    return t.copy(
        headlineSmall = s(t.headlineSmall),
        titleLarge = s(t.titleLarge),
        titleMedium = s(t.titleMedium),
        titleSmall = s(t.titleSmall),
        labelLarge = s(t.labelLarge),
    )
}

@Composable
fun EfirTheme(skin: Skin = Skin.CLASSIC, content: @Composable () -> Unit) {
    val spec = remember(skin) { skinSpec(skin) }
    val typography = remember(skin) { typographyFor(spec) }
    CompositionLocalProvider(LocalSkin provides spec) {
        MaterialTheme(colorScheme = spec.scheme, typography = typography, content = content)
    }
}

/** Фон скіна. Зорі «Спейс» малюються один раз статично — без анімації. */
@Composable
fun SkinBackground(content: @Composable () -> Unit) {
    val spec = LocalSkin.current
    val stars = remember(spec.stars) {
        if (!spec.stars) {
            emptyList()
        } else {
            val r = Random(7)
            List(70) { Triple(r.nextFloat(), r.nextFloat(), 0.6f + r.nextFloat() * 1.6f) }
        }
    }
    Box(
        Modifier
            .fillMaxSize()
            .background(spec.background)
            .then(
                if (stars.isEmpty()) {
                    Modifier
                } else {
                    Modifier.drawBehind {
                        for ((x, y, rad) in stars) {
                            drawCircle(
                                Color.White.copy(alpha = 0.25f + (rad / 2.2f) * 0.5f),
                                radius = rad * density,
                                center = Offset(x * size.width, y * size.height),
                            )
                        }
                    }
                },
            ),
    ) {
        content()
    }
}
