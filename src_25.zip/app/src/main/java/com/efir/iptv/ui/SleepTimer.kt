package com.efir.iptv.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.efir.iptv.AppViewModel
import com.efir.iptv.SleepControl
import kotlinx.coroutines.delay

/** Вибір таймера сну: вимкнено / 15 хв … 3 год, плюс дозвіл вимикати екран. */
@Composable
fun SleepTimerDialog(vm: AppViewModel, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val sleepAt by vm.sleepAt.collectAsStateWithLifecycle()
    var admin by remember { mutableStateOf(SleepControl.isAdmin(ctx)) }
    // Після повернення із системного вікна дозволу — оновити стан
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { admin = SleepControl.isAdmin(ctx) }
    val first = remember { FocusRequester() }
    LaunchedEffect(Unit) {
        delay(100)
        try {
            first.requestFocus()
        } catch (e: Exception) {
        }
    }
    val btn = Modifier.focusHighlight(RoundedCornerShape(20.dp))
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Таймер сну") },
        text = {
            Column(
                Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                if (sleepAt > 0L) {
                    Text(
                        "Заведено: вимкнення о ${hm(sleepAt)}",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.padding(bottom = 4.dp),
                    )
                }
                SleepOption(
                    if (sleepAt > 0L) "Вимкнути таймер" else "✓  Не вимикати",
                    if (sleepAt > 0L) Modifier.focusRequester(first) else Modifier,
                ) {
                    vm.setSleepTimer(0)
                    onDismiss()
                }
                AppViewModel.SLEEP_OPTIONS.forEachIndexed { i, m ->
                    SleepOption(
                        "Через ${AppViewModel.sleepLabel(m)}",
                        if (sleepAt == 0L && i == 0) Modifier.focusRequester(first) else Modifier,
                    ) {
                        vm.setSleepTimer(m)
                        onDismiss()
                    }
                }
                Text(
                    if (admin) {
                        "✓ Коли час вийде, Ефір вимкне екран (ТВ піде в режим сну)."
                    } else {
                        "Без дозволу Ефір лише зупинить відтворення і вийде на головний екран, " +
                            "а ТВ засне за власним налаштуванням. Щоб вимикати екран одразу, дайте дозвіл:"
                    },
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(top = 6.dp),
                )
                if (admin) {
                    TextButton(onClick = {
                        SleepControl.removeAdmin(ctx)
                        admin = false
                    }, modifier = btn) { Text("Забрати дозвіл вимикати екран") }
                    Text(
                        "Поки дозвіл увімкнено, Ефір не можна видалити — спершу заберіть дозвіл тут.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                } else {
                    TextButton(onClick = { SleepControl.requestAdmin(ctx) }, modifier = btn) {
                        Text("Дозволити вимикати екран")
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss, modifier = btn) { Text("Закрити") }
        },
    )
}

@Composable
private fun SleepOption(text: String, modifier: Modifier, onClick: () -> Unit) {
    val shape = RoundedCornerShape(12.dp)
    Text(
        text,
        style = MaterialTheme.typography.bodyLarge,
        color = MaterialTheme.colorScheme.onSurface,
        modifier = modifier
            .fillMaxWidth()
            .focusHighlight(shape)
            .clip(shape)
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 10.dp),
    )
}

/** Попередження за хвилину до вимкнення: OK — ще 30 хв. */
@Composable
fun SleepWarningDialog(vm: AppViewModel) {
    val sleepAt by vm.sleepAt.collectAsStateWithLifecycle()
    val secondsLeft by produceState(60, sleepAt) {
        while (true) {
            value = (((sleepAt - System.currentTimeMillis()) + 999) / 1000).toInt().coerceAtLeast(0)
            delay(500)
        }
    }
    val extend = remember { FocusRequester() }
    LaunchedEffect(Unit) {
        delay(100)
        try {
            extend.requestFocus()
        } catch (e: Exception) {
        }
    }
    val btn = Modifier.focusHighlight(RoundedCornerShape(20.dp))
    AlertDialog(
        // «Назад» — скасувати таймер і дивитися далі
        onDismissRequest = { vm.setSleepTimer(0) },
        title = { Text("Таймер сну") },
        text = {
            Text(
                "Ефір вимкнеться через $secondsLeft с",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold,
            )
        },
        confirmButton = {
            TextButton(
                onClick = { vm.setSleepTimer(30) },
                modifier = btn.focusRequester(extend),
            ) { Text("Ще 30 хв") }
        },
        dismissButton = {
            TextButton(onClick = { vm.sleepImmediately() }, modifier = btn) { Text("Вимкнути зараз") }
        },
    )
}
