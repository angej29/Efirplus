package com.efir.iptv.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

class Storage(context: Context) {
    private val prefs = context.getSharedPreferences("efir", Context.MODE_PRIVATE)
    private val dir = File(context.filesDir, "playlists").apply { mkdirs() }

    fun loadPlaylists(): List<PlaylistSource> = try {
        val arr = JSONArray(prefs.getString("playlists", null) ?: "[]")
        (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            PlaylistSource(
                id = o.getString("id"),
                name = o.optString("name"),
                url = o.optString("url"),
                epgUrl = o.optString("epg"),
            )
        }
    } catch (e: Exception) {
        emptyList()
    }

    fun savePlaylists(list: List<PlaylistSource>) {
        val arr = JSONArray()
        for (p in list) {
            arr.put(
                JSONObject()
                    .put("id", p.id)
                    .put("name", p.name)
                    .put("url", p.url)
                    .put("epg", p.epgUrl)
            )
        }
        prefs.edit().putString("playlists", arr.toString()).apply()
    }

    var selectedId: String?
        get() = prefs.getString("selected", null)
        set(value) {
            prefs.edit().putString("selected", value).apply()
        }

    fun favorites(): Set<String> = prefs.getStringSet("favorites", null)?.toSet() ?: emptySet()

    fun saveFavorites(set: Set<String>) {
        prefs.edit().putStringSet("favorites", HashSet(set)).apply()
    }

    fun recents(): List<String> = try {
        val arr = JSONArray(prefs.getString("recents", null) ?: "[]")
        (0 until arr.length()).map { arr.getString(it) }
    } catch (e: Exception) {
        emptyList()
    }

    fun saveRecents(list: List<String>) {
        val arr = JSONArray()
        list.forEach { arr.put(it) }
        prefs.edit().putString("recents", arr.toString()).apply()
    }

    fun hidden(id: String): Set<String> = prefs.getStringSet("hidden_$id", null)?.toSet() ?: emptySet()

    fun saveHidden(id: String, set: Set<String>) {
        prefs.edit().putStringSet("hidden_$id", HashSet(set)).apply()
    }

    fun clearHidden(id: String) {
        prefs.edit().remove("hidden_$id").apply()
    }

    /** Ручні переміщення каналів між групами: ключ каналу → нова група. */
    fun groupOverrides(id: String): Map<String, String> = try {
        val o = JSONObject(prefs.getString("groups_$id", null) ?: "{}")
        o.keys().asSequence().associateWith { o.getString(it) }
    } catch (e: Exception) {
        emptyMap()
    }

    fun saveGroupOverrides(id: String, map: Map<String, String>) {
        val o = JSONObject()
        for ((k, v) in map) o.put(k, v)
        prefs.edit().putString("groups_$id", o.toString()).apply()
    }

    fun clearGroupOverrides(id: String) {
        prefs.edit().remove("groups_$id").apply()
    }

    fun playlistFile(id: String) = File(dir, "$id.m3u")
    fun epgFile(id: String) = File(dir, "$id.epg")
}
