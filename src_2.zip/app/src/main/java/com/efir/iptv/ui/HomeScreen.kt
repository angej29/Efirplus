package com.efir.iptv.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.efir.iptv.AppViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(vm: AppViewModel, isTv: Boolean) {
    val s by vm.state.collectAsStateWithLifecycle()
    val group by vm.selectedGroup.collectAsStateWithLifecycle()
    val query by vm.query.collectAsStateWithLifecycle()
    val now = rememberNow()
    val list = remember(s.channels, s.favorites, s.recents, group, query) {
        AppViewModel.filter(s, group, query)
    }
    val source = s.playlists.firstOrNull { it.id == s.selectedId }
    var searchOpen by rememberSaveable { mutableStateOf(false) }

    Column(
        Modifier
            .fillMaxSize()
            .padding(horizontal = if (isTv) 40.dp else 12.dp, vertical = if (isTv) 24.dp else 8.dp),
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column(Modifier.weight(1f)) {
                Text(
                    "Ефір",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary,
                )
                Text(
                    buildString {
                        append(source?.name ?: "")
                        if (s.channels.isNotEmpty()) append(" · ${s.channels.size} каналів")
                    },
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
            if (searchOpen) {
                SearchField(query, { vm.query.value = it }, Modifier.weight(1.4f))
            }
            IconBtn(Icons.Filled.Search, "Пошук") {
                searchOpen = !searchOpen
                if (!searchOpen) vm.query.value = ""
            }
            IconBtn(Icons.Filled.Refresh, "Оновити плейлист") { vm.load(force = true) }
            IconBtn(Icons.Filled.Settings, "Плейлисти") { vm.screen.value = AppViewModel.Screen.Playlists }
        }

        if (s.loading || s.epgLoading) {
            LinearProgressIndicator(
                Modifier
                    .fillMaxWidth()
                    .height(2.dp),
            )
        }

        val chips = AppViewModel.SPECIAL_GROUPS + s.groups
        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            contentPadding = PaddingValues(vertical = 8.dp),
        ) {
            items(chips) { g ->
                FilterChip(
                    selected = g == group,
                    onClick = { vm.selectedGroup.value = g },
                    label = { Text(g, maxLines = 1) },
                    modifier = Modifier.focusHighlight(RoundedCornerShape(8.dp)),
                )
            }
        }

        val err = s.error
        when {
            err != null && s.channels.isEmpty() -> CenterMessage("Помилка", err) {
                Button(onClick = { vm.load(force = true) }, modifier = Modifier.focusHighlight()) {
                    Text("Спробувати ще раз")
                }
            }
            s.channels.isEmpty() && s.loading -> CenterMessage("Завантаження…", "Отримую список каналів")
            list.isEmpty() -> CenterMessage(
                "Тут порожньо",
                when {
                    query.isNotBlank() -> "Нічого не знайдено за запитом «$query»"
                    group == AppViewModel.GROUP_FAV -> "Утримуйте палець на каналі (на пульті — утримуйте OK), щоб додати його в обране"
                    group == AppViewModel.GROUP_RECENT -> "Тут зʼявляться канали, які ви дивились"
                    else -> "У цій групі немає каналів"
                },
            )
            else -> LazyVerticalGrid(
                columns = GridCells.Adaptive(if (isTv) 380.dp else 320.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                contentPadding = PaddingValues(top = 4.dp, bottom = 24.dp),
                modifier = Modifier.fillMaxSize(),
            ) {
                items(list, key = { it.key }) { c ->
                    ChannelRow(
                        c = c,
                        favorite = c.key in s.favorites,
                        programme = nowProgramme(s.epg[c.key], now),
                        now = now,
                        onLongClick = { vm.toggleFavorite(c) },
                        onClick = { vm.play(c, list) },
                    )
                }
            }
        }
    }
}

@Composable
private fun SearchField(value: String, onChange: (String) -> Unit, modifier: Modifier) {
    val fm = LocalFocusManager.current
    val req = remember { FocusRequester() }
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        modifier = modifier
            .focusRequester(req)
            .dpadEscape(),
        singleLine = true,
        placeholder = { Text("Пошук каналу") },
        leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
        keyboardActions = KeyboardActions(onSearch = { fm.clearFocus() }),
    )
    LaunchedEffect(Unit) {
        try {
            req.requestFocus()
        } catch (e: Exception) {
        }
    }
}
