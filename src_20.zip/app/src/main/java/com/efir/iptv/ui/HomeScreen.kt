package com.efir.iptv.ui

import androidx.compose.foundation.background
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.zIndex
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.border
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.OutlinedButton
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.focus.focusProperties
import kotlinx.coroutines.launch
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.TextButton
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.ExperimentalComposeUiApi
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.efir.iptv.AppViewModel
import com.efir.iptv.data.Channel
import kotlinx.coroutines.delay

@OptIn(ExperimentalMaterial3Api::class, ExperimentalComposeUiApi::class)
@Composable
fun HomeScreen(vm: AppViewModel, isTv: Boolean) {
    val s by vm.state.collectAsStateWithLifecycle()
    val group by vm.selectedGroup.collectAsStateWithLifecycle()
    val query by vm.query.collectAsStateWithLifecycle()
    val statuses by vm.streamStatus.collectAsStateWithLifecycle()
    val cleanup by vm.cleanup.collectAsStateWithLifecycle()
    val plStatus by vm.playlistStatus.collectAsStateWithLifecycle()
    var tabMenu by remember { mutableStateOf<String?>(null) }
    var confirmCleanup by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val now = rememberNow()
    val list = remember(s.channels, s.favorites, s.recents, group, query) {
        AppViewModel.filter(s, group, query)
    }
    val source = s.playlists.firstOrNull { it.id == s.selectedId }
    var searchOpen by rememberSaveable { mutableStateOf(false) }
    var menuFor by remember { mutableStateOf<Channel?>(null) }
    var playlistMenu by remember { mutableStateOf(false) }
    var moveFor by remember { mutableStateOf<Channel?>(null) }
    var dial by remember { mutableStateOf("") }
    LaunchedEffect(dial) {
        if (dial.isNotEmpty()) {
            delay(1800)
            val n = dial.toIntOrNull()
            dial = ""
            if (n != null) vm.playNumber(n)
        }
    }
    // Повернення до списку: прокрутка й фокус на каналі, який дивились останнім
    val lastKey by vm.lastChannelKey.collectAsStateWithLifecycle()
    val gridState = rememberLazyGridState()
    val lastReq = remember { FocusRequester() }
    LaunchedEffect(group, list.size) {
        val idx = list.indexOfFirst { it.key == lastKey }
        if (idx >= 0) {
            gridState.scrollToItem((idx - 1).coerceAtLeast(0))
            if (isTv) {
                delay(120)
                try {
                    lastReq.requestFocus()
                } catch (e: Exception) {
                }
            }
        }
    }

    Box(
        Modifier
            .fillMaxSize()
            .onPreviewKeyEvent { e ->
                // Набір номера каналу цифрами (коли не відкритий пошук)
                val d = digitOfKey(e.nativeKeyEvent.keyCode)
                if (d != null && !searchOpen) {
                    if (e.type == KeyEventType.KeyDown && dial.length < 4) dial += d.toString()
                    true
                } else {
                    false
                }
            },
    ) {
    Column(
        Modifier
            .fillMaxSize()
            .padding(horizontal = if (isTv) 40.dp else 12.dp, vertical = if (isTv) 24.dp else 8.dp),
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Box(Modifier.weight(1f)) {
                Column(
                    Modifier
                        .focusHighlight(RoundedCornerShape(10.dp))
                        .clip(RoundedCornerShape(10.dp))
                        .clickable { playlistMenu = true }
                        .padding(horizontal = 6.dp, vertical = 2.dp),
                ) {
                    Text(
                        "Ефір",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary,
                    )
                    Text(
                        buildString {
                            append(source?.name ?: if (s.selectedId == AppViewModel.ALL_ID) AppViewModel.ALL_NAME else "")
                            if (s.channels.isNotEmpty()) append(" · ${s.channels.size} каналів")
                            if (s.playlists.size > 1) append("  ▾")
                        },
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
                LaunchedEffect(playlistMenu) { if (playlistMenu) vm.checkPlaylists() }
                DropdownMenu(expanded = playlistMenu, onDismissRequest = { playlistMenu = false }) {
                    if (s.playlists.size > 1) {
                        DropdownMenuItem(
                            text = {
                                Text(
                                    (if (s.selectedId == AppViewModel.ALL_ID) "✓  " else "     ") +
                                        "${AppViewModel.ALL_NAME} (об'єднано)",
                                    fontWeight = FontWeight.SemiBold,
                                )
                            },
                            onClick = {
                                playlistMenu = false
                                if (s.selectedId != AppViewModel.ALL_ID) vm.selectPlaylist(AppViewModel.ALL_ID)
                            },
                        )
                    }
                    s.playlists.forEach { p ->
                        DropdownMenuItem(
                            text = {
                                PlaylistTitle(
                                    (if (p.id == s.selectedId) "✓  " else "") + p.name,
                                    plStatus[p.id],
                                    MaterialTheme.typography.bodyLarge,
                                )
                            },
                            onClick = {
                                playlistMenu = false
                                if (p.id != s.selectedId) vm.selectPlaylist(p.id)
                            },
                        )
                    }
                    DropdownMenuItem(
                        text = { Text("Керувати плейлистами (${s.playlists.size}/${AppViewModel.MAX_PLAYLISTS})…") },
                        onClick = {
                            playlistMenu = false
                            vm.screen.value = AppViewModel.Screen.Playlists
                        },
                    )
                }
            }
            if (searchOpen) {
                SearchField(query, { vm.query.value = it }, Modifier.weight(1.4f))
            }
            IconBtn(Icons.Filled.Search, "Пошук") {
                searchOpen = !searchOpen
                if (!searchOpen) vm.query.value = ""
            }
            IconBtn(Icons.Filled.DateRange, "Програма передач") { vm.openGuide() }
            IconBtn(Icons.Filled.Delete, "Видалити неактивні канали") { confirmCleanup = true }
            IconBtn(Icons.Filled.Refresh, "Оновити плейлист") { vm.load(force = true) }
            IconBtn(Icons.Filled.Settings, "Плейлисти") { vm.screen.value = AppViewModel.Screen.Playlists }
        }

        if (s.loading || s.epgLoading) {
            LinearProgressIndicator(
                Modifier
                    .fillMaxWidth()
                    .height(2.dp),
            )
        }
        cleanup?.let { (done, total) ->
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Column(Modifier.weight(1f)) {
                    Text(
                        "Перевіряю канали: $done з $total",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    Spacer(Modifier.height(4.dp))
                    LinearProgressIndicator(
                        progress = { if (total == 0) 0f else done.toFloat() / total },
                        modifier = Modifier.fillMaxWidth(),
                    )
                }
                TextButton(
                    onClick = { vm.cancelCleanup() },
                    modifier = Modifier.focusHighlight(RoundedCornerShape(20.dp)),
                ) { Text("Зупинити") }
            }
        }

        val chips = AppViewModel.SPECIAL_GROUPS + s.groups
        val tabsState = rememberLazyListState()
        // Вкладка вибраної групи завжди в полі зору
        LaunchedEffect(group, chips.size) {
            val i = chips.indexOf(group)
            if (i > 0) tabsState.scrollToItem((i - 1).coerceAtLeast(0))
        }
        val spacingPx = with(LocalDensity.current) { 8.dp.toPx() }
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconBtn(
                Icons.AutoMirrored.Filled.KeyboardArrowLeft,
                "На початок",
                tint = if (tabsState.canScrollBackward) MaterialTheme.colorScheme.onSurface
                else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.25f),
            ) { scope.launch { tabsState.animateScrollToItem(0) } }
            LazyRow(
                state = tabsState,
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                contentPadding = PaddingValues(vertical = 8.dp),
                modifier = Modifier.weight(1f),
            ) {
                itemsIndexed(chips, key = { i, g -> "$i|$g" }) { i, g ->
                    GroupTab(
                        label = g,
                        selected = g == group,
                        // Крайні вкладки: пульт не «вилітає» за межі ряду
                        modifier = Modifier.focusProperties {
                            if (i == 0) left = FocusRequester.Cancel
                            if (i == chips.lastIndex) right = FocusRequester.Cancel
                        },
                        onLongClick = if (g in AppViewModel.SPECIAL_GROUPS) null else ({ tabMenu = g }),
                        onDragEnd = if (g in AppViewModel.SPECIAL_GROUPS) {
                            null
                        } else {
                            { dx, w ->
                                val steps = kotlin.math.round(dx / (w + spacingPx)).toInt()
                                if (steps != 0) vm.moveGroupTo(g, s.groups.indexOf(g) + steps)
                            }
                        },
                        onClick = { vm.chooseGroup(g) },
                    )
                }
            }
            IconBtn(
                Icons.AutoMirrored.Filled.KeyboardArrowRight,
                "В кінець",
                tint = if (tabsState.canScrollForward) MaterialTheme.colorScheme.onSurface
                else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.25f),
            ) { scope.launch { tabsState.animateScrollToItem(chips.lastIndex.coerceAtLeast(0)) } }
        }

        val err = s.error
        when {
            err != null && s.channels.isEmpty() -> CenterMessage("Помилка", err) {
                Button(onClick = { vm.load(force = true) }, modifier = Modifier.focusHighlight()) {
                    Text("Спробувати ще раз")
                }
            }
            s.channels.isEmpty() && s.loading -> CenterMessage("Завантаження…", "Отримую список каналів")
            list.isEmpty() -> CenterMessage(
                "Тут порожньо",
                when {
                    query.isNotBlank() -> "Нічого не знайдено за запитом «$query»"
                    group == AppViewModel.GROUP_FAV -> "Утримуйте палець на каналі (на пульті — утримуйте OK) і виберіть «Додати в обране»"
                    group == AppViewModel.GROUP_RECENT -> "Тут зʼявляться канали, які ви дивились"
                    else -> "У цій групі немає каналів"
                },
            )
            else -> LazyVerticalGrid(
                columns = GridCells.Adaptive(if (isTv) 380.dp else 320.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                contentPadding = PaddingValues(top = 4.dp, bottom = 24.dp),
                state = gridState,
                modifier = Modifier.fillMaxSize(),
            ) {
                items(list, key = { it.key }) { c ->
                    LaunchedEffect(c.key) { vm.checkStream(c) }
                    ChannelRow(
                        c = c,
                        modifier = if (c.key == lastKey) Modifier.focusRequester(lastReq) else Modifier,
                        favorite = c.key in s.favorites,
                        programme = nowProgramme(s.epg[c.key], now),
                        now = now,
                        status = statuses[c.key],
                        onLongClick = { menuFor = c },
                        onMenu = if (isTv) null else ({ menuFor = c }),
                        onClick = { vm.play(c, list) },
                    )
                }
            }
        }
    }
    NumberDialOverlay(dial, Modifier.align(Alignment.TopEnd))
    }

    menuFor?.let { c ->
        ChannelMenu(
            c = c,
            favorite = c.key in s.favorites,
            onFavorite = {
                vm.toggleFavorite(c)
                menuFor = null
            },
            onHide = {
                vm.hideChannel(c)
                menuFor = null
            },
            onHideGroup = {
                vm.hideGroup(c.group)
                menuFor = null
            },
            onMove = {
                moveFor = c
                menuFor = null
            },
            onDismiss = { menuFor = null },
        )
    }

    tabMenu?.let { g ->
        GroupMenu(
            group = g,
            index = s.groups.indexOf(g),
            count = s.groups.size,
            channels = s.channels.count { it.group == g },
            onRename = { n ->
                vm.renameGroup(g, n)
                tabMenu = null
            },
            onMove = { d -> vm.moveGroup(g, d) },
            onMoveTo = { t -> vm.moveGroupTo(g, t) },
            onDismiss = { tabMenu = null },
        )
    }

    if (confirmCleanup) {
        AlertDialog(
            onDismissRequest = { confirmCleanup = false },
            title = { Text("Видалити неактивні канали?") },
            text = {
                Text(
                    "Перевірю всі ${s.channels.size} каналів поточного списку і видалю ті, що не відповідають. " +
                        "Це може зайняти кілька хвилин. Видалене можна повернути: Плейлисти → «Повернути видалені».",
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        confirmCleanup = false
                        vm.cleanupInactive()
                    },
                    modifier = Modifier.focusHighlight(RoundedCornerShape(20.dp)),
                ) { Text("Перевірити й видалити") }
            },
            dismissButton = {
                TextButton(
                    onClick = { confirmCleanup = false },
                    modifier = Modifier.focusHighlight(RoundedCornerShape(20.dp)),
                ) { Text("Скасувати") }
            },
        )
    }

    moveFor?.let { c ->
        MoveDialog(
            c = c,
            groups = s.groups,
            onMove = { g ->
                vm.moveToGroup(c, g)
                moveFor = null
            },
            onDismiss = { moveFor = null },
        )
    }
}

@Composable
internal fun MoveDialog(
    c: Channel,
    groups: List<String>,
    onMove: (String) -> Unit,
    onDismiss: () -> Unit,
) {
    var newGroup by remember { mutableStateOf("") }
    val first = remember { FocusRequester() }
    val targets = groups.filter { it != c.group }
    LaunchedEffect(Unit) {
        delay(100)
        try {
            first.requestFocus()
        } catch (e: Exception) {
        }
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Перемістити «${c.name}»", maxLines = 2, overflow = TextOverflow.Ellipsis) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    "Зараз у групі «${c.group}». Виберіть нову:",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                LazyColumn(
                    Modifier.heightIn(max = 320.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                    itemsIndexed(targets) { i, g ->
                        MenuItem(g, if (i == 0) Modifier.focusRequester(first) else Modifier, { onMove(g) })
                    }
                }
                OutlinedTextField(
                    value = newGroup,
                    onValueChange = { newGroup = it },
                    label = { Text("Або нова група") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .dpadEscape()
                        .then(if (targets.isEmpty()) Modifier.focusRequester(first) else Modifier),
                )
            }
        },
        confirmButton = {
            TextButton(
                onClick = { onMove(newGroup) },
                enabled = newGroup.isNotBlank(),
                modifier = Modifier.focusHighlight(RoundedCornerShape(20.dp)),
            ) { Text("Створити й перемістити") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss, modifier = Modifier.focusHighlight(RoundedCornerShape(20.dp))) {
                Text("Скасувати")
            }
        },
    )
}

@Composable
internal fun ChannelMenu(
    c: Channel,
    favorite: Boolean,
    onFavorite: () -> Unit,
    onHide: () -> Unit,
    onHideGroup: () -> Unit,
    onMove: () -> Unit,
    onDismiss: () -> Unit,
) {
    val first = remember { FocusRequester() }
    LaunchedEffect(Unit) {
        delay(100)
        try {
            first.requestFocus()
        } catch (e: Exception) {
        }
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(c.name, maxLines = 2, overflow = TextOverflow.Ellipsis) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                MenuItem(
                    if (favorite) "Прибрати з обраного" else "★  Додати в обране",
                    Modifier.focusRequester(first),
                    onFavorite,
                )
                MenuItem("Перемістити в іншу групу…", Modifier, onMove)
                MenuItem("Видалити канал", Modifier, onHide, danger = true)
                MenuItem("Видалити всю групу «${c.group}»", Modifier, onHideGroup, danger = true)
                Text(
                    "Видалені канали можна повернути: Плейлисти → «Повернути видалені».",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(top = 4.dp),
                )
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss, modifier = Modifier.focusHighlight(RoundedCornerShape(20.dp))) {
                Text("Скасувати")
            }
        },
    )
}

@Composable
private fun MenuItem(text: String, modifier: Modifier, onClick: () -> Unit, danger: Boolean = false) {
    val shape = RoundedCornerShape(12.dp)
    Text(
        text,
        color = if (danger) Color(0xFFFF8A80) else MaterialTheme.colorScheme.onSurface,
        style = MaterialTheme.typography.bodyLarge,
        modifier = modifier
            .fillMaxWidth()
            .focusHighlight(shape)
            .clip(shape)
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 12.dp),
    )
}

@Composable
private fun SearchField(value: String, onChange: (String) -> Unit, modifier: Modifier) {
    val fm = LocalFocusManager.current
    val req = remember { FocusRequester() }
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        modifier = modifier
            .focusRequester(req)
            .dpadEscape(),
        singleLine = true,
        placeholder = { Text("Пошук каналу") },
        leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
        keyboardActions = KeyboardActions(onSearch = { fm.clearFocus() }),
    )
    LaunchedEffect(Unit) {
        try {
            req.requestFocus()
        } catch (e: Exception) {
        }
    }
}

@Composable
private fun GroupTab(
    label: String,
    selected: Boolean,
    modifier: Modifier,
    onLongClick: (() -> Unit)?,
    /** Перетягування: (зсув по X у пікселях, ширина вкладки) — після довгого натискання. */
    onDragEnd: ((Float, Float) -> Unit)?,
    onClick: () -> Unit,
) {
    val shape = RoundedCornerShape(LocalSkin.current.cornerS)
    val colors = MaterialTheme.colorScheme
    var dragX by remember { mutableFloatStateOf(0f) }
    var dragging by remember { mutableStateOf(false) }
    val slop = with(LocalDensity.current) { 12.dp.toPx() }
    Text(
        label,
        maxLines = 1,
        style = MaterialTheme.typography.labelLarge,
        color = if (selected || dragging) colors.onSecondaryContainer else colors.onSurface,
        modifier = modifier
            .zIndex(if (dragging) 1f else 0f)
            .graphicsLayer {
                translationX = dragX
                val sc = if (dragging) 1.08f else 1f
                scaleX = sc
                scaleY = sc
            }
            .then(
                if (onDragEnd == null) {
                    Modifier
                } else {
                    Modifier.pointerInput(label) {
                        detectDragGesturesAfterLongPress(
                            onDragStart = {
                                dragging = true
                                dragX = 0f
                            },
                            onDrag = { change, d ->
                                change.consume()
                                dragX += d.x
                            },
                            onDragEnd = {
                                val moved = dragX
                                dragging = false
                                dragX = 0f
                                // Затиснули й відпустили без руху — меню вкладки
                                if (kotlin.math.abs(moved) < slop) onLongClick?.invoke()
                                else onDragEnd(moved, size.width.toFloat())
                            },
                            onDragCancel = {
                                dragging = false
                                dragX = 0f
                            },
                        )
                    }
                },
            )
            // Пульт: утримати OK або клавіша Menu — меню вкладки
            .onPreviewKeyEvent { e ->
                val code = e.nativeKeyEvent.keyCode
                if (onLongClick != null && e.type == KeyEventType.KeyDown && (
                        code == android.view.KeyEvent.KEYCODE_MENU ||
                            ((code == android.view.KeyEvent.KEYCODE_DPAD_CENTER || code == android.view.KeyEvent.KEYCODE_ENTER) &&
                                e.nativeKeyEvent.repeatCount == 1)
                        )
                ) {
                    onLongClick()
                    true
                } else {
                    false
                }
            }
            .focusHighlight(shape)
            .clip(shape)
            .background(if (selected || dragging) colors.secondaryContainer else Color.Transparent)
            .border(1.dp, if (selected || dragging) colors.secondaryContainer else colors.outline, shape)
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 8.dp),
    )
}

@Composable
private fun GroupMenu(
    group: String,
    index: Int,
    count: Int,
    channels: Int,
    onRename: (String) -> Unit,
    onMove: (Int) -> Unit,
    onMoveTo: (Int) -> Unit,
    onDismiss: () -> Unit,
) {
    var name by remember(group) { mutableStateOf(group) }
    val btn = Modifier.focusHighlight(RoundedCornerShape(20.dp))
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Вкладка «$group»", maxLines = 2, overflow = TextOverflow.Ellipsis) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    "Каналів: $channels · позиція ${index + 1} з $count",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { onMoveTo(0) }, enabled = index > 0, modifier = btn) { Text("⏮ На початок") }
                    OutlinedButton(onClick = { onMoveTo(count - 1) }, enabled = index in 0 until count - 1, modifier = btn) {
                        Text("В кінець ⏭")
                    }
                }
                Text(
                    "Порада: вкладку можна затиснути й перетягнути мишкою чи пальцем.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { onMove(-1) }, enabled = index > 0, modifier = btn) { Text("◀ Вліво") }
                    OutlinedButton(onClick = { onMove(1) }, enabled = index in 0 until count - 1, modifier = btn) {
                        Text("Вправо ▶")
                    }
                }
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Назва вкладки") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .dpadEscape(),
                )
                Text(
                    "Якщо назвати так само, як іншу вкладку, вони об'єднаються.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        },
        confirmButton = {
            TextButton(
                onClick = { onRename(name) },
                enabled = name.isNotBlank() && name.trim() != group,
                modifier = btn,
            ) { Text("Перейменувати") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss, modifier = btn) { Text("Готово") }
        },
    )
}
