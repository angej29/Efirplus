package com.efir.iptv

import android.app.Application
import android.content.Context
import android.net.Uri
import android.widget.Toast
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.Format
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.Tracks
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.hls.DefaultHlsExtractorFactory
import androidx.media3.exoplayer.hls.HlsMediaSource
import androidx.media3.extractor.DefaultExtractorsFactory
import androidx.media3.extractor.ts.DefaultTsPayloadReaderFactory
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import com.efir.iptv.data.Channel
import com.efir.iptv.data.EpgParser
import com.efir.iptv.data.HOUR
import com.efir.iptv.data.M3uParser
import com.efir.iptv.data.Net
import com.efir.iptv.data.ParsedPlaylist
import com.efir.iptv.data.PlaylistSource
import com.efir.iptv.data.Programme
import com.efir.iptv.data.Storage
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import java.io.BufferedInputStream
import java.io.File
import java.io.FileInputStream
import java.io.IOException
import java.util.Locale
import java.util.UUID

class AppViewModel(app: Application) : AndroidViewModel(app) {

    enum class Screen { Home, Player, Playlists }

    data class State(
        val playlists: List<PlaylistSource> = emptyList(),
        val selectedId: String? = null,
        val channels: List<Channel> = emptyList(),
        val groups: List<String> = emptyList(),
        val loading: Boolean = false,
        val error: String? = null,
        val favorites: Set<String> = emptySet(),
        val recents: List<String> = emptyList(),
        val epg: Map<String, List<Programme>> = emptyMap(),
        val epgLoading: Boolean = false,
        val hiddenCount: Int = 0,
    )

    data class Playback(val buffering: Boolean = false, val error: String? = null)

    enum class StreamStatus { Checking, Online, Offline }

    data class AudioTrack(
        val group: Int,
        val index: Int,
        val label: String,
        val selected: Boolean,
        val supported: Boolean,
    )

    private val ctx: Context = app.applicationContext
    private val storage = Storage(ctx)

    private val _state = MutableStateFlow(State())
    val state: StateFlow<State> = _state.asStateFlow()

    val screen = MutableStateFlow(Screen.Home)
    val selectedGroup = MutableStateFlow(GROUP_ALL)
    val query = MutableStateFlow("")
    val inPip = MutableStateFlow(false)

    val current = MutableStateFlow<Channel?>(null)
    val queue = MutableStateFlow<List<Channel>>(emptyList())
    val playback = MutableStateFlow(Playback())

    /** Стан потоків: перевіряються лише канали, видимі на екрані. */
    val streamStatus = MutableStateFlow<Map<String, StreamStatus>>(emptyMap())
    private val checkedAt = HashMap<String, Long>()
    private val probeLimit = Semaphore(6)

    val audioTracks = MutableStateFlow<List<AudioTrack>>(emptyList())
    private var audioGroups: List<Tracks.Group> = emptyList()

    // FFmpeg-декодер має пріоритет для звуку: однаково працює на всіх пристроях,
    // включно з MP2 та AC3, яких часто немає в системних декодерах телефонів.
    private val renderers = DefaultRenderersFactory(ctx)
        .setExtensionRendererMode(DefaultRenderersFactory.EXTENSION_RENDERER_MODE_PREFER)
        .setEnableDecoderFallback(true)

    private val extractors = DefaultExtractorsFactory()
        .setTsExtractorFlags(TS_FLAGS)
        .setConstantBitrateSeekingEnabled(true)

    val player: ExoPlayer = ExoPlayer.Builder(ctx, renderers)
        .setAudioAttributes(
            AudioAttributes.Builder()
                .setUsage(C.USAGE_MEDIA)
                .setContentType(C.AUDIO_CONTENT_TYPE_MOVIE)
                .build(),
            true,
        )
        .build()

    private var allChannels: List<Channel> = emptyList()
    private var hidden: Set<String> = emptySet()
    private var playlistEpg = ""

    private var triedHls = false
    private var retries = 0
    private var loadJob: Job? = null
    private var epgJob: Job? = null
    private var retryJob: Job? = null

    init {
        player.playWhenReady = true
        player.trackSelectionParameters = player.trackSelectionParameters.buildUpon()
            .setPreferredAudioLanguages("uk", "en")
            .build()
        player.addListener(object : Player.Listener {
            override fun onPlaybackStateChanged(playbackState: Int) {
                playback.update { it.copy(buffering = playbackState == Player.STATE_BUFFERING) }
                if (playbackState == Player.STATE_READY) {
                    current.value?.let { markStatus(it.key, StreamStatus.Online) }
                    retries = 0
                    playback.update { it.copy(error = null) }
                }
                if (playbackState == Player.STATE_ENDED) scheduleRestart(1000)
            }

            override fun onPlayerError(error: PlaybackException) = handleError(error)

            override fun onTracksChanged(tracks: Tracks) = updateAudioTracks(tracks)
        })

        val list = storage.loadPlaylists()
        val sel = storage.selectedId?.takeIf { id -> list.any { it.id == id } } ?: list.firstOrNull()?.id
        _state.update {
            it.copy(
                playlists = list,
                selectedId = sel,
                favorites = storage.favorites(),
                recents = storage.recents(),
            )
        }
        if (sel != null) hidden = storage.hidden(sel)
        if (sel == null) screen.value = Screen.Playlists else load(force = false)
    }

    // ---------------- Плейлисти ----------------

    private fun currentSource(): PlaylistSource? =
        _state.value.playlists.firstOrNull { it.id == _state.value.selectedId }

    fun load(force: Boolean) {
        val src = currentSource() ?: return
        if (force) clearStatuses()
        loadJob?.cancel()
        loadJob = viewModelScope.launch {
            _state.update { it.copy(loading = true, error = null) }
            val file = storage.playlistFile(src.id)
            var parsed: ParsedPlaylist? = null
            if (!force && file.exists()) {
                parsed = withContext(Dispatchers.IO) {
                    try {
                        M3uParser.parse(file.readText())
                    } catch (e: Exception) {
                        null
                    }
                }
                if (parsed != null && parsed.channels.isNotEmpty()) applyChannels(parsed) else parsed = null
            }
            val stale = !file.exists() || System.currentTimeMillis() - file.lastModified() > 6 * HOUR
            if (force || parsed == null || stale) {
                try {
                    val text = withContext(Dispatchers.IO) { Net.readText(ctx, src.url) }
                    val fresh = withContext(Dispatchers.Default) { M3uParser.parse(text) }
                    if (fresh.channels.isEmpty()) throw IOException("плейлист порожній або має невідомий формат")
                    withContext(Dispatchers.IO) { file.writeText(text) }
                    parsed = fresh
                    applyChannels(fresh)
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    if (parsed == null) {
                        _state.update {
                            it.copy(error = "Не вдалося завантажити плейлист: ${e.message ?: e.javaClass.simpleName}")
                        }
                    }
                }
            }
            _state.update { it.copy(loading = false) }
            val result = parsed
            if (result != null) loadEpg(src, result, force)
        }
    }

    private fun applyChannels(p: ParsedPlaylist) {
        allChannels = p.channels
        playlistEpg = p.epgUrl
        recompute()
    }

    /** Застосовує список видалених (прихованих) каналів до повного плейлиста. */
    private fun recompute() {
        val visible = allChannels.filter { it.key !in hidden }
        val groups = visible.map { it.group }.distinct()
        _state.update {
            it.copy(
                channels = visible,
                groups = groups,
                error = null,
                hiddenCount = allChannels.size - visible.size,
            )
        }
        val g = selectedGroup.value
        if (g !in SPECIAL_GROUPS && g !in groups) selectedGroup.value = GROUP_ALL
    }

    // ---------------- Перевірка потоків ----------------

    suspend fun checkStream(c: Channel) {
        if (!c.url.startsWith("http", ignoreCase = true)) return
        val now = System.currentTimeMillis()
        val last = checkedAt[c.key]
        if (last != null && now - last < STATUS_TTL) return
        checkedAt[c.key] = now
        if (streamStatus.value[c.key] == null) setStatus(c.key, StreamStatus.Checking)
        try {
            val ok = probeLimit.withPermit { withContext(Dispatchers.IO) { Net.probe(c) } }
            setStatus(c.key, if (ok) StreamStatus.Online else StreamStatus.Offline)
        } catch (e: CancellationException) {
            // Канал прокрутили з екрана до завершення перевірки — перевіримо пізніше
            checkedAt.remove(c.key)
            if (streamStatus.value[c.key] == StreamStatus.Checking) streamStatus.update { it - c.key }
            throw e
        }
    }

    private fun markStatus(key: String, st: StreamStatus) {
        checkedAt[key] = System.currentTimeMillis()
        setStatus(key, st)
    }

    private fun setStatus(key: String, st: StreamStatus) {
        streamStatus.update { it + (key to st) }
    }

    private fun clearStatuses() {
        checkedAt.clear()
        streamStatus.value = emptyMap()
    }

    // ---------------- Видалення каналів ----------------

    fun hideChannel(c: Channel) {
        val id = _state.value.selectedId ?: return
        hidden = hidden + c.key
        storage.saveHidden(id, hidden)
        recompute()
        toast("Канал «${c.name}» видалено. Повернути можна в розділі «Плейлисти».")
    }

    fun hideGroup(group: String) {
        val id = _state.value.selectedId ?: return
        val keys = allChannels.filter { it.group == group }.map { it.key }
        hidden = hidden + keys
        storage.saveHidden(id, hidden)
        recompute()
        toast("Групу «$group» видалено (${keys.size} каналів).")
    }

    fun restoreHidden() {
        val id = _state.value.selectedId ?: return
        hidden = emptySet()
        storage.clearHidden(id)
        recompute()
        toast("Видалені канали повернуто")
    }

    // ---------------- Збереження плейлиста у файл ----------------

    fun suggestedFileName(): String {
        val name = currentSource()?.name ?: "playlist"
        return name.replace(Regex("[\\\\/:*?\"<>|]"), "_").trim().ifBlank { "playlist" } + ".m3u"
    }

    private fun buildM3u(): String {
        fun q(v: String) = v.replace('"', '\'')
        val sb = StringBuilder()
        val epg = currentSource()?.epgUrl?.takeIf { it.isNotBlank() } ?: playlistEpg
        sb.append("#EXTM3U")
        if (epg.isNotBlank()) sb.append(" url-tvg=\"").append(q(epg)).append('"')
        sb.append('\n')
        for (c in _state.value.channels) {
            sb.append("#EXTINF:-1")
            if (c.tvgId.isNotBlank()) sb.append(" tvg-id=\"").append(q(c.tvgId)).append('"')
            if (c.tvgName.isNotBlank()) sb.append(" tvg-name=\"").append(q(c.tvgName)).append('"')
            if (c.logo.isNotBlank()) sb.append(" tvg-logo=\"").append(q(c.logo)).append('"')
            if (c.group != M3uParser.NO_GROUP) sb.append(" group-title=\"").append(q(c.group)).append('"')
            sb.append(',').append(c.name).append('\n')
            c.headers["User-Agent"]?.let { sb.append("#EXTVLCOPT:http-user-agent=").append(it).append('\n') }
            c.headers["Referer"]?.let { sb.append("#EXTVLCOPT:http-referrer=").append(it).append('\n') }
            sb.append(c.url).append('\n')
        }
        return sb.toString()
    }

    fun exportToUri(uri: Uri) {
        val text = buildM3u()
        viewModelScope.launch {
            try {
                withContext(Dispatchers.IO) {
                    val out = ctx.contentResolver.openOutputStream(uri, "wt")
                        ?: throw IOException("не вдалося відкрити файл")
                    out.use { it.write(text.toByteArray(Charsets.UTF_8)) }
                }
                toast("Плейлист збережено (${_state.value.channels.size} каналів)")
            } catch (e: Exception) {
                toast("Не вдалося зберегти: ${e.message ?: e.javaClass.simpleName}")
            }
        }
    }

    fun exportToDir(dir: File) {
        val text = buildM3u()
        viewModelScope.launch {
            try {
                val f = withContext(Dispatchers.IO) {
                    val base = suggestedFileName().removeSuffix(".m3u")
                    var file = File(dir, "$base.m3u")
                    var n = 2
                    while (file.exists()) file = File(dir, "$base ($n).m3u").also { n++ }
                    file.writeText(text, Charsets.UTF_8)
                    file
                }
                toast("Збережено: ${f.absolutePath}")
            } catch (e: Exception) {
                toast("Не вдалося зберегти: ${e.message ?: e.javaClass.simpleName}")
            }
        }
    }

    private fun toast(msg: String) {
        Toast.makeText(ctx, msg, Toast.LENGTH_LONG).show()
    }

    private fun loadEpg(src: PlaylistSource, p: ParsedPlaylist, force: Boolean) {
        val url = src.epgUrl.ifBlank { p.epgUrl }
        epgJob?.cancel()
        if (url.isBlank()) {
            _state.update { it.copy(epg = emptyMap(), epgLoading = false) }
            return
        }
        epgJob = viewModelScope.launch {
            _state.update { it.copy(epgLoading = true) }
            try {
                val f = storage.epgFile(src.id)
                val map = withContext(Dispatchers.IO) {
                    val stale = !f.exists() || System.currentTimeMillis() - f.lastModified() > 12 * HOUR
                    if (force || stale) {
                        try {
                            Net.download(ctx, url, f)
                        } catch (e: Exception) {
                            if (!f.exists()) throw e
                        }
                    }
                    Net.maybeGunzip(BufferedInputStream(FileInputStream(f), 65536)).use {
                        EpgParser.parse(it, p.channels)
                    }
                }
                _state.update { it.copy(epg = map) }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                // Телепрограма необовʼязкова — просто працюємо без неї
            } finally {
                _state.update { it.copy(epgLoading = false) }
            }
        }
    }

    fun addPlaylist(name: String, url: String, epg: String) {
        if (_state.value.playlists.size >= MAX_PLAYLISTS) {
            toast("Можна зберегти до $MAX_PLAYLISTS плейлистів. Видаліть непотрібний, щоб додати новий.")
            return
        }
        val src = PlaylistSource(
            id = UUID.randomUUID().toString(),
            name = name.trim().ifBlank { "Плейлист" },
            url = url.trim(),
            epgUrl = epg.trim(),
        )
        val list = _state.value.playlists + src
        storage.savePlaylists(list)
        _state.update { it.copy(playlists = list) }
        selectPlaylist(src.id)
    }

    fun selectPlaylist(id: String) {
        clearStatuses()
        storage.selectedId = id
        hidden = storage.hidden(id)
        allChannels = emptyList()
        _state.update {
            it.copy(
                selectedId = id,
                channels = emptyList(),
                groups = emptyList(),
                epg = emptyMap(),
                error = null,
                hiddenCount = 0,
            )
        }
        selectedGroup.value = GROUP_ALL
        query.value = ""
        screen.value = Screen.Home
        load(force = false)
    }

    fun refreshPlaylist(id: String) {
        if (_state.value.selectedId != id) {
            storage.playlistFile(id).delete()
            storage.epgFile(id).delete()
            selectPlaylist(id)
        } else {
            screen.value = Screen.Home
            load(force = true)
        }
    }

    fun deletePlaylist(id: String) {
        val list = _state.value.playlists.filter { it.id != id }
        storage.savePlaylists(list)
        storage.playlistFile(id).delete()
        storage.epgFile(id).delete()
        storage.clearHidden(id)
        _state.update { it.copy(playlists = list) }
        if (_state.value.selectedId == id) {
            val next = list.firstOrNull()
            if (next != null) {
                selectPlaylist(next.id)
                screen.value = Screen.Playlists
            } else {
                loadJob?.cancel()
                epgJob?.cancel()
                storage.selectedId = null
                allChannels = emptyList()
                hidden = emptySet()
                _state.update {
                    it.copy(selectedId = null, channels = emptyList(), groups = emptyList(), epg = emptyMap())
                }
            }
        }
    }

    // ---------------- Обране / недавні ----------------

    fun toggleFavorite(c: Channel) {
        val f = _state.value.favorites.toMutableSet()
        if (!f.add(c.key)) f.remove(c.key)
        storage.saveFavorites(f)
        _state.update { it.copy(favorites = f) }
    }

    private fun addRecent(c: Channel) {
        val r = (listOf(c.key) + _state.value.recents.filter { it != c.key }).take(30)
        storage.saveRecents(r)
        _state.update { it.copy(recents = r) }
    }

    // ---------------- Відтворення ----------------

    fun play(c: Channel, list: List<Channel>) {
        queue.value = list.ifEmpty { listOf(c) }
        screen.value = Screen.Player
        start(c)
    }

    fun start(c: Channel) {
        triedHls = false
        retries = 0
        addRecent(c)
        startStream(c, hls = false)
    }

    private fun startStream(c: Channel, hls: Boolean) {
        retryJob?.cancel()
        current.value = c
        playback.value = Playback(buffering = true)

        val headers = HashMap(c.headers)
        val ua = headers.remove("User-Agent") ?: Net.USER_AGENT
        val http = DefaultHttpDataSource.Factory()
            .setUserAgent(ua)
            .setAllowCrossProtocolRedirects(true)
            .setConnectTimeoutMs(15_000)
            .setReadTimeoutMs(20_000)
            .setDefaultRequestProperties(headers)
        val dataSource = DefaultDataSource.Factory(ctx, http)

        val isHls = hls || looksHls(c.url)
        val item = MediaItem.Builder().setUri(c.url)
        if (isHls) item.setMimeType(MimeTypes.APPLICATION_M3U8)
        val mediaItem = item.build()

        val source = if (isHls) {
            HlsMediaSource.Factory(dataSource)
                .setExtractorFactory(DefaultHlsExtractorFactory(TS_FLAGS, true))
                .createMediaSource(mediaItem)
        } else {
            DefaultMediaSourceFactory(dataSource, extractors).createMediaSource(mediaItem)
        }
        // Новий канал — скидаємо ручний вибір звукової доріжки
        player.trackSelectionParameters = player.trackSelectionParameters.buildUpon()
            .clearOverridesOfType(C.TRACK_TYPE_AUDIO)
            .build()
        audioTracks.value = emptyList()
        player.setMediaSource(source)
        player.prepare()
        player.play()
    }

    private fun updateAudioTracks(tracks: Tracks) {
        val groups = tracks.groups.filter { it.type == C.TRACK_TYPE_AUDIO }
        audioGroups = groups
        val list = ArrayList<AudioTrack>()
        groups.forEachIndexed { gi, g ->
            for (ti in 0 until g.length) {
                list += AudioTrack(
                    group = gi,
                    index = ti,
                    label = describeAudio(g.getTrackFormat(ti), list.size + 1),
                    selected = g.isTrackSelected(ti),
                    supported = g.isTrackSupported(ti),
                )
            }
        }
        audioTracks.value = list
    }

    fun selectAudio(t: AudioTrack) {
        val g = audioGroups.getOrNull(t.group) ?: return
        player.trackSelectionParameters = player.trackSelectionParameters.buildUpon()
            .setOverrideForType(TrackSelectionOverride(g.mediaTrackGroup, t.index))
            .build()
    }

    private fun describeAudio(f: Format, n: Int): String {
        val lang = f.language
            ?.takeIf { it.isNotBlank() && it != "und" }
            ?.let { code ->
                Locale.forLanguageTag(code).getDisplayLanguage(Locale.forLanguageTag("uk"))
                    .ifBlank { code }
                    .replaceFirstChar { it.uppercase() }
            }
        val label = f.label?.takeIf { it.isNotBlank() }
        val parts = ArrayList<String>()
        parts += label ?: lang ?: "Доріжка $n"
        if (label != null && lang != null) parts += lang
        val codec = when (f.sampleMimeType) {
            MimeTypes.AUDIO_AAC -> "AAC"
            MimeTypes.AUDIO_AC3 -> "AC3 (Dolby)"
            MimeTypes.AUDIO_E_AC3, MimeTypes.AUDIO_E_AC3_JOC -> "E-AC3 (Dolby)"
            MimeTypes.AUDIO_MPEG, MimeTypes.AUDIO_MPEG_L2 -> "MPEG"
            MimeTypes.AUDIO_DTS -> "DTS"
            MimeTypes.AUDIO_OPUS -> "Opus"
            null -> null
            else -> f.sampleMimeType?.substringAfter('/')?.uppercase()
        }
        if (codec != null) parts += codec
        when (f.channelCount) {
            Format.NO_VALUE, 0 -> {}
            1 -> parts += "моно"
            2 -> parts += "стерео"
            6 -> parts += "5.1"
            8 -> parts += "7.1"
            else -> parts += "${f.channelCount} кан."
        }
        return parts.joinToString(" · ")
    }

    private fun looksHls(url: String): Boolean {
        val u = url.lowercase().substringBefore('?')
        return u.endsWith(".m3u8") || u.endsWith(".m3u") || url.lowercase().contains("m3u8")
    }

    private fun handleError(e: PlaybackException) {
        val c = current.value ?: return
        if (screen.value != Screen.Player) return
        if (e.errorCode == PlaybackException.ERROR_CODE_BEHIND_LIVE_WINDOW) {
            player.seekToDefaultPosition()
            player.prepare()
            return
        }
        // Невідомий формат — пробуємо як HLS (часто посилання без розширення .m3u8)
        if (!triedHls && !looksHls(c.url) && e.errorCode in 3000..3999) {
            triedHls = true
            startStream(c, hls = true)
            return
        }
        if (retries < 3) {
            retries++
            scheduleRestart(1500L * retries)
            return
        }
        markStatus(c.key, StreamStatus.Offline)
        playback.value = Playback(buffering = false, error = describe(e))
    }

    private fun scheduleRestart(delayMs: Long) {
        val c = current.value ?: return
        if (screen.value != Screen.Player) return
        retryJob?.cancel()
        retryJob = viewModelScope.launch {
            delay(delayMs)
            if (current.value?.key == c.key && screen.value == Screen.Player) startStream(c, triedHls)
        }
    }

    private fun describe(e: PlaybackException): String = when (e.errorCode) {
        PlaybackException.ERROR_CODE_IO_BAD_HTTP_STATUS ->
            "Сервер відхилив запит (канал недоступний або потрібна авторизація)"
        PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_FAILED,
        PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_TIMEOUT ->
            "Немає зʼєднання з сервером каналу"
        in 3000..3999 -> "Невідомий формат потоку"
        in 4000..4999 -> "Пристрій не може декодувати це відео"
        else -> "Помилка відтворення (${e.errorCodeName})"
    }

    fun step(delta: Int) {
        val c = current.value ?: return
        val q = queue.value
        if (q.isEmpty()) return
        val i = q.indexOfFirst { it.key == c.key }.coerceAtLeast(0)
        val n = ((i + delta) % q.size + q.size) % q.size
        start(q[n])
    }

    fun retry() {
        current.value?.let { start(it) }
    }

    fun togglePause() {
        if (player.isPlaying) player.pause() else {
            if (player.playbackState == Player.STATE_IDLE) player.prepare()
            player.seekToDefaultPosition()
            player.play()
        }
    }

    fun stopPlayer() {
        retryJob?.cancel()
        player.stop()
        player.clearMediaItems()
        current.value = null
        playback.value = Playback()
        screen.value = Screen.Home
    }

    fun onForeground() {
        if (screen.value == Screen.Player && current.value != null) {
            if (player.playbackState == Player.STATE_IDLE) player.prepare()
            player.seekToDefaultPosition()
            player.play()
        }
    }

    fun onBackground() {
        player.pause()
    }

    override fun onCleared() {
        player.release()
        super.onCleared()
    }

    companion object {
        const val GROUP_FAV = "★ Обране"
        const val GROUP_RECENT = "Недавні"
        const val GROUP_ALL = "Усі канали"
        val SPECIAL_GROUPS = listOf(GROUP_FAV, GROUP_RECENT, GROUP_ALL)
        const val MAX_PLAYLISTS = 10
        private const val STATUS_TTL = 10 * 60_000L

        private val TS_FLAGS = DefaultTsPayloadReaderFactory.FLAG_ALLOW_NON_IDR_KEYFRAMES or
            DefaultTsPayloadReaderFactory.FLAG_DETECT_ACCESS_UNITS or
            DefaultTsPayloadReaderFactory.FLAG_ENABLE_HDMV_DTS_AUDIO_STREAMS

        fun filter(s: State, group: String, query: String): List<Channel> {
            val base = when (group) {
                GROUP_FAV -> s.channels.filter { it.key in s.favorites }
                GROUP_RECENT -> {
                    val byKey = s.channels.associateBy { it.key }
                    s.recents.mapNotNull { byKey[it] }
                }
                GROUP_ALL -> s.channels
                else -> s.channels.filter { it.group == group }
            }
            val q = query.trim().lowercase()
            if (q.isEmpty()) return base
            return base.filter { it.name.lowercase().contains(q) }
        }
    }
}
