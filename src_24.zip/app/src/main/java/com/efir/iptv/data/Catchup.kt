package com.efir.iptv.data

import java.util.Calendar
import java.util.TimeZone

/** Побудова адреси архіву (catch-up) для передачі, що вже йшла або йде зараз. */
object Catchup {

    /** Найкраще джерело з архівом: сам канал або одне з резервних. */
    fun archiveSource(c: Channel): Channel? =
        if (c.hasArchive) c else c.sources.firstOrNull { it.hasArchive }

    fun canPlay(c: Channel, start: Long, now: Long = System.currentTimeMillis()): Boolean {
        val src = archiveSource(c) ?: return false
        return start < now && start > now - src.catchupDays * 24 * HOUR
    }

    /**
     * @param start початок (мс), @param end кінець (мс, може бути в майбутньому — тоді до «зараз»).
     */
    fun buildUrl(src: Channel, start: Long, end: Long, now: Long = System.currentTimeMillis()): String {
        val endC = minOf(end, now).coerceAtLeast(start + 60_000)
        val type = src.catchupType
        val tpl = src.catchupSource
        val base = src.url
        return when {
            type == "flussonic" || type == "fs" || type == "flussonic-hls" || type == "flussonic-ts" -> flussonic(base, start, endC)
            (type == "shift" || type == "timeshift") && tpl.isBlank() -> {
                val sep = if (base.contains('?')) "&" else "?"
                base + sep + "utc=" + start / 1000 + "&lutc=" + now / 1000
            }
            type == "append" -> base + fill(tpl, src, start, endC, now)
            tpl.isNotBlank() -> {
                val filled = fill(tpl, src, start, endC, now)
                if (filled.startsWith("http", ignoreCase = true)) filled else base + filled
            }
            else -> {
                val sep = if (base.contains('?')) "&" else "?"
                base + sep + "utc=" + start / 1000 + "&lutc=" + now / 1000
            }
        }
    }

    private fun flussonic(url: String, start: Long, end: Long): String {
        val dur = (end - start) / 1000
        val s = start / 1000
        val q = url.substringAfter('?', "")
        val path = url.substringBefore('?')
        val dir = path.substringBeforeLast('/')
        val file = path.substringAfterLast('/')
        val newFile = when {
            file.endsWith(".m3u8") -> {
                val prefix = file.removeSuffix(".m3u8").removeSuffix("index").removeSuffix("video").removeSuffix("mono")
                "${prefix}archive-$s-$dur.m3u8".replace("--", "-")
            }
            file == "mpegts" || file.endsWith(".ts") -> "timeshift_abs-$s.ts"
            else -> "$file/archive-$s-$dur.m3u8"
        }
        return "$dir/$newFile" + if (q.isNotEmpty()) "?$q" else ""
    }

    /** Заповнення плейсхолдерів у стилі Kodi / TiviMate / Xtream. */
    private fun fill(tpl: String, src: Channel, start: Long, end: Long, now: Long): String {
        val tz = if (src.catchupTz.isNotBlank()) TimeZone.getTimeZone(src.catchupTz) else TimeZone.getTimeZone("UTC")
        val cal = Calendar.getInstance(tz).apply { timeInMillis = start }
        fun two(v: Int) = v.toString().padStart(2, '0')
        val y = cal.get(Calendar.YEAR).toString()
        val mo = two(cal.get(Calendar.MONTH) + 1)
        val d = two(cal.get(Calendar.DAY_OF_MONTH))
        val h = two(cal.get(Calendar.HOUR_OF_DAY))
        val mi = two(cal.get(Calendar.MINUTE))
        val se = two(cal.get(Calendar.SECOND))
        val startS = (start / 1000).toString()
        val endS = (end / 1000).toString()
        val nowS = (now / 1000).toString()
        val durS = ((end - start) / 1000).toString()
        val durMin = ((end - start) / 60_000).toString()
        val offS = ((now - start) / 1000).toString()
        var r = tpl
        val map = linkedMapOf(
            "{utc}" to startS, "\${start}" to startS, "{start}" to startS, "{timestamp}" to startS, "\${timestamp}" to startS,
            "{utcend}" to endS, "\${end}" to endS, "{end}" to endS,
            "{lutc}" to nowS, "\${now}" to nowS, "{now}" to nowS,
            "{duration}" to durS, "\${duration}" to durS, "{duration_min}" to durMin,
            "{offset}" to offS, "\${offset}" to offS,
            "{Y}" to y, "{m}" to mo, "{d}" to d, "{H}" to h, "{M}" to mi, "{S}" to se,
        )
        for ((k, v) in map) r = r.replace(k, v)
        return r
    }
}
