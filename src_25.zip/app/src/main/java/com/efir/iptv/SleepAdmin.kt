package com.efir.iptv

import android.app.Activity
import android.app.admin.DeviceAdminReceiver
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.Toast

/**
 * Дозвіл «вимикати екран» (device admin з єдиною політикою force-lock).
 * Потрібен лише таймеру сну: без нього Ефір просто зупиняє відтворення
 * й виходить на головний екран, а ТВ засинає за власним налаштуванням.
 */
class SleepAdmin : DeviceAdminReceiver()

object SleepControl {

    private fun component(ctx: Context) = ComponentName(ctx, SleepAdmin::class.java)

    private fun dpm(ctx: Context) = ctx.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager

    fun isAdmin(ctx: Context): Boolean = try {
        dpm(ctx).isAdminActive(component(ctx))
    } catch (e: Exception) {
        false
    }

    /** Відкриває системне вікно «Активувати адміністратора пристрою». */
    fun requestAdmin(ctx: Context) {
        val intent = Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN)
            .putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, component(ctx))
            .putExtra(
                DevicePolicyManager.EXTRA_ADD_EXPLANATION,
                "Ефір вимикатиме екран, коли спрацює таймер сну. Інших дій цей дозвіл не дає.",
            )
        if (ctx !is Activity) intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try {
            ctx.startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(ctx, "Цей пристрій не дозволяє програмам вимикати екран", Toast.LENGTH_LONG).show()
        }
    }

    /** Забирає дозвіл (потрібно, наприклад, щоб видалити Ефір). */
    fun removeAdmin(ctx: Context) {
        try {
            dpm(ctx).removeActiveAdmin(component(ctx))
        } catch (e: Exception) {
        }
    }

    /** Вимикає екран, якщо є дозвіл. Повертає false, якщо не вийшло. */
    fun lockNow(ctx: Context): Boolean {
        if (!isAdmin(ctx)) return false
        return try {
            dpm(ctx).lockNow()
            true
        } catch (e: Exception) {
            false
        }
    }
}
