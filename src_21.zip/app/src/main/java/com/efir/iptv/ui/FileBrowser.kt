package com.efir.iptv.ui

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.Settings
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import kotlinx.coroutines.delay
import java.io.File

enum class BrowseMode { OpenPlaylist, SaveToFolder, OpenImage }

private val PLAYLIST_EXT = setOf("m3u", "m3u8", "txt")
private val IMAGE_EXT = setOf("jpg", "jpeg", "png", "webp")

object StorageAccess {
    fun hasAccess(ctx: Context, write: Boolean): Boolean {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) return Environment.isExternalStorageManager()
        val read = ContextCompat.checkSelfPermission(ctx, Manifest.permission.READ_EXTERNAL_STORAGE) ==
            PackageManager.PERMISSION_GRANTED
        if (!write) return read
        return read && ContextCompat.checkSelfPermission(ctx, Manifest.permission.WRITE_EXTERNAL_STORAGE) ==
            PackageManager.PERMISSION_GRANTED
    }

    /** Відкриває системний екран «Доступ до всіх файлів» (Android 11+). */
    fun openAllFilesSettings(ctx: Context): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) return false
        val intents = listOf(
            Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:${ctx.packageName}")),
            Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION),
            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${ctx.packageName}")),
        )
        for (i in intents) {
            try {
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                ctx.startActivity(i)
                return true
            } catch (e: Exception) {
            }
        }
        return false
    }

    /** Внутрішня пам'ять + усі підключені флешки й карти пам'яті. */
    fun roots(): List<Pair<String, File>> {
        val out = ArrayList<Pair<String, File>>()
        val seen = HashSet<String>()
        fun add(label: String, f: File) {
            val path = try {
                f.canonicalPath
            } catch (e: Exception) {
                f.absolutePath
            }
            if (f.isDirectory && seen.add(path)) out += label to f
        }
        // Спільні папки з ПК в емуляторах (LDPlayer: Misc → Завантаження Windows, Pictures → Картинки)
        File("/mnt/shared").listFiles()
            ?.filter { it.isDirectory }
            ?.sortedBy { it.name }
            ?.forEach { add("💻 Папка на ПК (${it.name})", it) }
        add("Внутрішня пам'ять", Environment.getExternalStorageDirectory())
        File("/storage").listFiles()
            ?.filter { it.isDirectory && it.name != "emulated" && it.name != "self" && it.name != "sdcard0" }
            ?.sortedBy { it.name }
            ?.forEach { add("Флешка / карта пам'яті (${it.name})", it) }
                for (base in listOf("/mnt/media_rw", "/mnt/usb_storage", "/mnt/usb", "/mnt/udisk")) {
            File(base).listFiles()
                ?.filter { it.isDirectory && it.canRead() }
                ?.forEach { add("USB (${it.name})", it) }
        }
        return out
    }
}

private data class Entry(val label: String, val file: File?, val isDir: Boolean, val isUp: Boolean = false)

/**
 * Вбудований провідник: працює й на телевізорах, де немає системного вибору файлів.
 * OpenPlaylist — вибрати файл плейлиста; SaveToFolder — вибрати папку для збереження.
 */
@Composable
fun FileBrowser(
    mode: BrowseMode,
    isTv: Boolean,
    onPickFiles: (List<File>) -> Unit,
    onPickFolder: (File) -> Unit,
    onClose: () -> Unit,
) {
    val context = LocalContext.current
    val write = mode == BrowseMode.SaveToFolder
    var granted by remember { mutableStateOf(StorageAccess.hasAccess(context, write)) }
    var current by remember { mutableStateOf<File?>(null) }
    var rootsList by remember { mutableStateOf(StorageAccess.roots()) }
    var refresh by remember { mutableIntStateOf(0) }
    var picked by remember { mutableStateOf<Set<String>>(emptySet()) }

    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        granted = StorageAccess.hasAccess(context, write)
        rootsList = StorageAccess.roots()
        refresh++
    }

    // Після повернення з налаштувань перевіряємо дозвіл ще раз
    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner) {
        val obs = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                granted = StorageAccess.hasAccess(context, write)
                rootsList = StorageAccess.roots()
                refresh++
            }
        }
        lifecycleOwner.lifecycle.addObserver(obs)
        onDispose { lifecycleOwner.lifecycle.removeObserver(obs) }
    }

    fun requestAccess() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            StorageAccess.openAllFilesSettings(context)
        } else {
            val perms = if (write) {
                arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE)
            } else {
                arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
            }
            permLauncher.launch(perms)
        }
    }

    val cur = current
    val entries: List<Entry> = remember(cur, refresh, rootsList) {
        if (cur == null) {
            rootsList.map { (label, f) -> Entry(label, f, true) }
        } else {
            val list = ArrayList<Entry>()
            list += Entry(".. Вгору", null, true, isUp = true)
            val children = cur.listFiles()?.filter { !it.name.startsWith(".") } ?: emptyList()
            children.filter { it.isDirectory }
                .sortedBy { it.name.lowercase() }
                .forEach { list += Entry(it.name, it, true) }
            if (mode != BrowseMode.SaveToFolder) {
                val exts = if (mode == BrowseMode.OpenImage) IMAGE_EXT else PLAYLIST_EXT
                children.filter { it.isFile && it.extension.lowercase() in exts }
                    .sortedBy { it.name.lowercase() }
                    .forEach { list += Entry(it.name, it, false) }
            }
            list
        }
    }

    fun goUp() {
        val c = current ?: run {
            onClose()
            return
        }
        val isRoot = rootsList.any { it.second.absolutePath == c.absolutePath }
        current = if (isRoot) null else c.parentFile
    }

    BackHandler { goUp() }

    val firstReq = remember { FocusRequester() }
    LaunchedEffect(cur, entries.size) {
        delay(80)
        try {
            firstReq.requestFocus()
        } catch (e: Exception) {
        }
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(horizontal = if (isTv) 48.dp else 16.dp, vertical = if (isTv) 28.dp else 12.dp),
    ) {
        Column(Modifier.fillMaxSize()) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(
                        when (mode) {
                            BrowseMode.OpenPlaylist -> "Відкрити плейлист з пристрою"
                            BrowseMode.OpenImage -> "Виберіть фото для фону"
                            BrowseMode.SaveToFolder -> "Куди зберегти плейлист"
                        },
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                    )
                    Text(
                        cur?.absolutePath ?: "Оберіть сховище",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
                if (mode == BrowseMode.OpenPlaylist && cur != null) {
                    val inFolder = entries.filter { !it.isDir && it.file != null }.map { it.file!!.absolutePath }
                    if (inFolder.isNotEmpty()) {
                        val all = picked.containsAll(inFolder)
                        TextButton(
                            onClick = { picked = if (all) picked - inFolder.toSet() else picked + inFolder },
                            modifier = Modifier.focusHighlight(RoundedCornerShape(20.dp)),
                        ) { Text(if (all) "Зняти всі" else "Вибрати всі") }
                        Spacer(Modifier.width(4.dp))
                    }
                }
                if (mode == BrowseMode.OpenPlaylist && picked.isNotEmpty()) {
                    Button(
                        onClick = { onPickFiles(picked.sorted().map { File(it) }) },
                        modifier = Modifier.focusHighlight(RoundedCornerShape(20.dp)),
                    ) { Text("Додати (${picked.size})") }
                    Spacer(Modifier.width(8.dp))
                }
                if (mode == BrowseMode.SaveToFolder && cur != null) {
                    Button(
                        onClick = { onPickFolder(cur) },
                        modifier = Modifier.focusHighlight(RoundedCornerShape(20.dp)),
                    ) { Text("Зберегти тут") }
                    Spacer(Modifier.width(8.dp))
                }
                IconBtn(Icons.Filled.Close, "Закрити") { onClose() }
            }
            Spacer(Modifier.height(10.dp))

            if (!granted) {
                Column(
                    Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .background(MaterialTheme.colorScheme.secondaryContainer)
                        .padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    Text(
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                            "Щоб бачити файли у пам'яті та на флешці, дозвольте Ефіру «Доступ до всіх файлів»."
                        } else {
                            "Щоб бачити файли у пам'яті та на флешці, дозвольте Ефіру доступ до сховища."
                        },
                        style = MaterialTheme.typography.bodyMedium,
                    )
                    Button(
                        onClick = { requestAccess() },
                        modifier = Modifier.focusHighlight(RoundedCornerShape(20.dp)),
                    ) { Text("Надати доступ") }
                }
                Spacer(Modifier.height(10.dp))
            }

            if (entries.isEmpty() || (cur != null && entries.size == 1)) {
                Text(
                    if (cur == null) "Сховищ не знайдено. Підключіть флешку або надайте доступ."
                    else if (mode == BrowseMode.OpenPlaylist) "Тут немає папок і файлів .m3u / .m3u8"
                    else if (mode == BrowseMode.OpenImage) "Тут немає папок і зображень .jpg / .png / .webp"
                    else "Тут немає вкладених папок — можна зберегти сюди",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(vertical = 8.dp),
                )
            }

            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(6.dp),
                contentPadding = PaddingValues(bottom = 24.dp),
            ) {
                itemsIndexed(entries, key = { i, e -> "$i|${e.file?.absolutePath}|${e.label}" }) { i, e ->
                    val shape = RoundedCornerShape(12.dp)
                    Row(
                        (if (i == 0) Modifier.focusRequester(firstReq) else Modifier)
                            .fillMaxWidth()
                            .focusHighlight(shape)
                            .clip(shape)
                            .background(MaterialTheme.colorScheme.surface)
                            .clickable {
                                when {
                                    e.isUp -> goUp()
                                    e.isDir -> current = e.file
                                    e.file != null && mode == BrowseMode.OpenImage -> onPickFiles(listOf(e.file))
                                    e.file != null -> {
                                        val path = e.file.absolutePath
                                        picked = if (path in picked) picked - path else picked + path
                                    }
                                }
                            }
                            .padding(horizontal = 14.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text(
                            when {
                                e.isUp -> "⬆"
                                e.isDir -> "📁"
                                mode == BrowseMode.OpenImage -> "🖼"
                                e.file != null && e.file.absolutePath in picked -> "☑"
                                else -> "☐"
                            },
                        )
                        Spacer(Modifier.width(12.dp))
                        Text(
                            e.label,
                            style = MaterialTheme.typography.bodyLarge,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                    }
                }
            }
        }
    }
}
