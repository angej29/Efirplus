package com.efir.iptv.ui

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.clickable
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.efir.iptv.AppViewModel
import com.efir.iptv.data.PlaylistSource

private const val SAMPLE_URL = "https://iptv-org.github.io/iptv/countries/ua.m3u"

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun PlaylistsScreen(vm: AppViewModel, isTv: Boolean) {
    val s by vm.state.collectAsStateWithLifecycle()
    val context = LocalContext.current
    var name by rememberSaveable { mutableStateOf("") }
    var url by rememberSaveable { mutableStateOf("") }
    var epg by rememberSaveable { mutableStateOf("") }
    var xtream by rememberSaveable { mutableStateOf(false) }
    var xServer by rememberSaveable { mutableStateOf("") }
    var xUser by rememberSaveable { mutableStateOf("") }
    var xPass by rememberSaveable { mutableStateOf("") }
    var browser by remember { mutableStateOf<BrowseMode?>(null) }
    val plStatus by vm.playlistStatus.collectAsStateWithLifecycle()
    LaunchedEffect(s.playlists.size) { vm.checkPlaylists() }

    // Системний вибір файлів (телефони, планшети) — можна кілька одразу
    val openDocs = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNotEmpty()) {
            val items = uris.map { uri ->
                try {
                    context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                } catch (e: Exception) {
                }
                playlistNameFromFile(displayName(context, uri) ?: uri.lastPathSegment) to uri.toString()
            }
            vm.addPlaylists(items)
        }
    }
    // Системне збереження файлу
    val createDoc = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("audio/x-mpegurl")) { uri ->
        if (uri != null) vm.exportToUri(uri)
    }

    // Своє фото фоном (телефони)
    val pickImage = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) vm.setCustomBackground(vm.skin.value) { context.contentResolver.openInputStream(uri) }
    }

    fun chooseBackground() {
        if (isTv) {
            browser = BrowseMode.OpenImage
        } else {
            try {
                pickImage.launch("image/*")
            } catch (e: Exception) {
                browser = BrowseMode.OpenImage
            }
        }
    }

    fun openFromDevice() {
        if (isTv) {
            browser = BrowseMode.OpenPlaylist
        } else {
            try {
                openDocs.launch(arrayOf("*/*"))
            } catch (e: Exception) {
                browser = BrowseMode.OpenPlaylist
            }
        }
    }

    fun saveToDisk() {
        if (isTv) {
            browser = BrowseMode.SaveToFolder
        } else {
            try {
                createDoc.launch(vm.suggestedFileName())
            } catch (e: Exception) {
                browser = BrowseMode.SaveToFolder
            }
        }
    }

    val mode = browser
    if (mode != null) {
        FileBrowser(
            mode = mode,
            isTv = isTv,
            onPickFiles = { files ->
                if (mode == BrowseMode.OpenImage) {
                    files.firstOrNull()?.let { f -> vm.setCustomBackground(vm.skin.value) { java.io.FileInputStream(f) } }
                } else {
                    vm.addPlaylists(files.map { playlistNameFromFile(it.name) to Uri.fromFile(it).toString() })
                }
                browser = null
            },
            onPickFolder = { dir ->
                vm.exportToDir(dir)
                browser = null
            },
            onClose = { browser = null },
        )
        return
    }

    BackHandler(enabled = s.playlists.isNotEmpty()) { vm.screen.value = AppViewModel.Screen.Home }

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = if (isTv) 48.dp else 16.dp, vertical = if (isTv) 28.dp else 12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (s.playlists.isNotEmpty()) {
                    IconBtn(Icons.AutoMirrored.Filled.ArrowBack, "Назад") {
                        vm.screen.value = AppViewModel.Screen.Home
                    }
                    Spacer(Modifier.width(4.dp))
                }
                Text(
                    "Плейлисти  ${s.playlists.size}/${AppViewModel.MAX_PLAYLISTS}",
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold,
                )
            }
        }

        item { SkinPicker(vm, onPickImage = { chooseBackground() }) }

        if (s.playlists.isEmpty()) {
            item {
                Text(
                    "Додайте M3U-плейлист від свого IPTV-провайдера: посиланням, файлом із пам'яті пристрою або з флешки.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }

        if (s.selectedId == AppViewModel.ALL_ID) {
            item {
                Column(
                    Modifier
                        .widthIn(max = 720.dp)
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .background(MaterialTheme.colorScheme.secondaryContainer)
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                    Text(
                        "✓  ${AppViewModel.ALL_NAME} (об'єднано)",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold,
                    )
                    Text(
                        buildString {
                            append("Каналів: ${s.channels.size}")
                            if (s.hiddenCount > 0) append(" · видалено: ${s.hiddenCount}")
                        },
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        val btn = Modifier.focusHighlight(RoundedCornerShape(20.dp))
                        TextButton(onClick = { vm.refreshPlaylist(AppViewModel.ALL_ID) }, modifier = btn) {
                            Text("Оновити все")
                        }
                        TextButton(onClick = { saveToDisk() }, modifier = btn) { Text("Зберегти у файл") }
                        if (s.hiddenCount > 0) {
                            TextButton(onClick = { vm.restoreHidden() }, modifier = btn) {
                                Text("Повернути видалені (${s.hiddenCount})")
                            }
                        }
                        if (s.movedCount > 0) {
                            TextButton(onClick = { vm.resetGroups() }, modifier = btn) {
                                Text("Скинути налаштування груп")
                            }
                        }
                    }
                }
            }
        } else if (s.playlists.size > 1) {
            item {
                OutlinedButton(
                    onClick = { vm.selectPlaylist(AppViewModel.ALL_ID) },
                    modifier = Modifier.focusHighlight(RoundedCornerShape(20.dp)),
                ) { Text("Об'єднати всі плейлисти в один список") }
            }
        }

        items(s.playlists, key = { it.id }) { p ->
            val selected = p.id == s.selectedId
            PlaylistCard(
                p = p,
                active = plStatus[p.id],
                selected = selected,
                channelCount = if (selected) s.channels.size else null,
                hiddenCount = if (selected) s.hiddenCount else 0,
                onSelect = { vm.selectPlaylist(p.id) },
                onRefresh = { vm.refreshPlaylist(p.id) },
                onSave = { saveToDisk() },
                onRestore = { vm.restoreHidden() },
                movedCount = if (selected) s.movedCount else 0,
                onResetGroups = { vm.resetGroups() },
                onDelete = { vm.deletePlaylist(p.id) },
            )
        }

        item {
            Column(
                Modifier
                    .widthIn(max = 720.dp)
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(MaterialTheme.colorScheme.surface)
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                val full = s.playlists.size >= AppViewModel.MAX_PLAYLISTS
                Text("Новий плейлист", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                if (full) {
                    Text(
                        "Збережено максимум — ${AppViewModel.MAX_PLAYLISTS} плейлистів. Видаліть непотрібний, щоб додати новий.",
                        color = Color(0xFFFF8A80),
                        style = MaterialTheme.typography.bodySmall,
                    )
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    val tb = Modifier.focusHighlight(RoundedCornerShape(20.dp))
                    if (xtream) {
                        OutlinedButton(onClick = { xtream = false }, modifier = tb) { Text("M3U / файл") }
                        Button(onClick = {}, modifier = tb) { Text("✓ Xtream Codes") }
                    } else {
                        Button(onClick = {}, modifier = tb) { Text("✓ M3U / файл") }
                        OutlinedButton(onClick = { xtream = true }, modifier = tb) { Text("Xtream Codes") }
                    }
                }
                if (xtream) {
                    OutlinedTextField(
                        value = name,
                        onValueChange = { name = it },
                        label = { Text("Назва") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().dpadEscape(),
                    )
                    OutlinedTextField(
                        value = xServer,
                        onValueChange = { xServer = it },
                        label = { Text("Сервер (наприклад http://example.com:8080)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().dpadEscape(),
                    )
                    OutlinedTextField(
                        value = xUser,
                        onValueChange = { xUser = it },
                        label = { Text("Логін") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().dpadEscape(),
                    )
                    OutlinedTextField(
                        value = xPass,
                        onValueChange = { xPass = it },
                        label = { Text("Пароль") },
                        singleLine = true,
                        visualTransformation = androidx.compose.ui.text.input.PasswordVisualTransformation(),
                        modifier = Modifier.fillMaxWidth().dpadEscape(),
                    )
                    Text(
                        "Канали, групи, телепрограма й архів завантажаться з сервера провайдера автоматично.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    Button(
                        onClick = {
                            vm.addXtream(name, xServer, xUser, xPass)
                            name = ""
                            xPass = ""
                        },
                        enabled = xServer.isNotBlank() && xUser.isNotBlank() && !full,
                        modifier = Modifier.focusHighlight(RoundedCornerShape(20.dp)),
                    ) { Text("Підключити") }
                } else {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Назва") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .dpadEscape(),
                )
                OutlinedTextField(
                    value = url,
                    onValueChange = { url = it },
                    label = { Text("Посилання на M3U / M3U8 або файл") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .dpadEscape(),
                )
                OutlinedTextField(
                    value = epg,
                    onValueChange = { epg = it },
                    label = { Text("Телепрограма XMLTV (необовʼязково)") },
                    supportingText = { Text("Якщо порожньо — візьмемо з плейлиста (url-tvg), якщо він її вказує") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .dpadEscape(),
                )
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    Button(
                        onClick = {
                            vm.addPlaylist(name, url, epg)
                            name = ""
                            url = ""
                            epg = ""
                        },
                        enabled = url.isNotBlank() && !full,
                        modifier = Modifier.focusHighlight(RoundedCornerShape(20.dp)),
                    ) { Text("Додати") }
                    OutlinedButton(
                        onClick = { openFromDevice() },
                        modifier = Modifier.focusHighlight(RoundedCornerShape(20.dp)),
                    ) { Text("Файли з пристрою") }
                    OutlinedButton(
                        onClick = { browser = BrowseMode.OpenPlaylist },
                        modifier = Modifier.focusHighlight(RoundedCornerShape(20.dp)),
                    ) { Text("Пам'ять / флешка") }
                }
                Text(
                    "Файли можна вибрати кілька одразу — кожен стане окремим плейлистом із назвою файлу.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                TextButton(
                    onClick = {
                        name = "Україна (iptv-org)"
                        url = SAMPLE_URL
                        epg = ""
                    },
                    modifier = Modifier.focusHighlight(RoundedCornerShape(20.dp)),
                ) { Text("Підставити відкритий тестовий плейлист") }
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun PlaylistCard(
    p: PlaylistSource,
    active: Boolean?,
    selected: Boolean,
    channelCount: Int?,
    hiddenCount: Int,
    onSelect: () -> Unit,
    onRefresh: () -> Unit,
    onSave: () -> Unit,
    onRestore: () -> Unit,
    movedCount: Int,
    onResetGroups: () -> Unit,
    onDelete: () -> Unit,
) {
    var confirmDelete by remember { mutableStateOf(false) }
    val colors = MaterialTheme.colorScheme
    val btn = Modifier.focusHighlight(RoundedCornerShape(20.dp))
    Column(
        Modifier
            .widthIn(max = 720.dp)
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(if (selected) colors.secondaryContainer else colors.surface)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (selected) {
                Icon(Icons.Filled.CheckCircle, contentDescription = null, tint = colors.primary)
                Spacer(Modifier.width(8.dp))
            }
            PlaylistTitle(p.name, active, MaterialTheme.typography.titleMedium, FontWeight.SemiBold)
        }
        Text(
            com.efir.iptv.data.Xtream.decode(p.url)?.let { "Xtream Codes · ${it.server} · ${it.user}" } ?: p.url,
            style = MaterialTheme.typography.bodySmall,
            color = colors.onSurfaceVariant,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
        if (p.epgUrl.isNotBlank()) {
            Text(
                "EPG: ${p.epgUrl}",
                style = MaterialTheme.typography.bodySmall,
                color = colors.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
        if (channelCount != null) {
            Text(
                buildString {
                    append("Каналів: $channelCount")
                    if (hiddenCount > 0) append(" · видалено: $hiddenCount")
                },
                style = MaterialTheme.typography.bodySmall,
                color = colors.onSurfaceVariant,
            )
        }
        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            if (!selected) {
                TextButton(onClick = onSelect, modifier = btn) { Text("Відкрити") }
            }
            TextButton(onClick = onRefresh, modifier = btn) { Text("Оновити") }
            if (selected) {
                TextButton(onClick = onSave, modifier = btn) { Text("Зберегти у файл") }
                if (hiddenCount > 0) {
                    TextButton(onClick = onRestore, modifier = btn) { Text("Повернути видалені ($hiddenCount)") }
                }
                if (movedCount > 0) {
                    TextButton(onClick = onResetGroups, modifier = btn) { Text("Скинути налаштування груп") }
                }
            }
            TextButton(
                onClick = { if (confirmDelete) onDelete() else confirmDelete = true },
                modifier = btn,
            ) {
                Text(if (confirmDelete) "Точно видалити?" else "Видалити", color = Color(0xFFFF8A80))
            }
        }
    }
}

/** "Спорт HD.m3u8" -> "Спорт HD" */
private fun playlistNameFromFile(fileName: String?): String =
    fileName?.substringAfterLast('/')?.substringBeforeLast('.')?.trim()?.takeIf { it.isNotBlank() } ?: "Плейлист"

private fun displayName(context: android.content.Context, uri: Uri): String? = try {
    context.contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)
        ?.use { c -> if (c.moveToFirst()) c.getString(0) else null }
} catch (e: Exception) {
    null
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun SkinPicker(vm: AppViewModel, onPickImage: () -> Unit) {
    val current by vm.skin.collectAsStateWithLifecycle()
    val backgrounds by vm.backgrounds.collectAsStateWithLifecycle()
    val bgIndex by vm.bgIndex.collectAsStateWithLifecycle()
    Column(
        Modifier
            .widthIn(max = 720.dp)
            .fillMaxWidth()
            .clip(RoundedCornerShape(LocalSkin.current.cornerL))
            .background(MaterialTheme.colorScheme.surface)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Text("Оформлення", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
        FlowRow(
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Skin.entries.forEach { sk ->
                val spec = skinSpec(sk)
                val selected = sk == current
                val shape = RoundedCornerShape(spec.cornerL)
                Column(
                    Modifier
                        .width(120.dp)
                        .focusHighlight(shape)
                        .clip(shape)
                        .background(spec.background)
                        .border(if (selected) 2.dp else 1.dp, if (selected) spec.accent else spec.scheme.outline, shape)
                        .clickable { vm.setSkin(sk) }
                        .padding(10.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        listOf(spec.accent, spec.scheme.secondaryContainer, spec.scheme.surfaceVariant).forEach { c ->
                            Box(
                                Modifier
                                    .size(14.dp)
                                    .clip(RoundedCornerShape(spec.cornerS))
                                    .background(c),
                            )
                        }
                    }
                    Text(
                        (if (selected) "✓ " else "") + sk.title,
                        color = spec.scheme.onSurface,
                        fontFamily = spec.titleFont,
                        fontWeight = spec.titleWeight ?: FontWeight.SemiBold,
                    )
                    Text(sk.hint, color = spec.scheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall, maxLines = 2)
                }
            }
        }
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            val btn = Modifier.focusHighlight(RoundedCornerShape(20.dp))
            val bundled = bundledBackgrounds(current).size
            if (bundled > 0 && backgrounds[current.name] == null) {
                val idx = bgIndex[current.name] ?: 0
                OutlinedButton(onClick = { vm.nextBundledBackground(current) }, modifier = btn) {
                    Text(if (idx < bundled) "Інший фон (${idx + 1}/$bundled)" else "Інший фон (без фото)")
                }
            }
            OutlinedButton(onClick = onPickImage, modifier = btn) { Text("Своє фото фоном для «${current.title}»") }
            if (backgrounds[current.name] != null) {
                TextButton(onClick = { vm.clearCustomBackground(current) }, modifier = btn) {
                    Text("Повернути стандартний фон")
                }
            }
        }
        Text(
            "Фото зберігається лише на цьому пристрої, зменшується й затемнюється, щоб текст читався. " +
                "Під час перегляду каналу фон не показується — плеєр не навантажується.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}
